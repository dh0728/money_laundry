# 첫 경보 자금세탁 유형 분류 모델 실행

팀에서 보유한 HI-Large 원장의 `transactions.parquet`와 `kyc.parquet`로 경보를 만들고, 처음 발행된 경보에 여섯 유형의 확률을 계산합니다. 모델 가중치, 특성 계산 코드, 경보 생성에 쓰는 서비스 모델과 보정표를 동봉했습니다.

## 실행

Linux x86_64, Python 3.12, C++17을 지원하는 `g++` 환경에서 아래 명령을 실행하세요. 마지막 명령의 경로를 두 Parquet가 있는 폴더로 바꾸면 됩니다. 한 단계 위의 `parquets` 폴더도 지정할 수 있습니다. 추론은 CPU에서 실행합니다.

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python run_demo.py --data-dir "/path/to/parquets/HI-Large"
```

기본 실행은 검증에 사용한 기간을 재생합니다. 2022년 11월 6일부터 거래 이력을 사용해 11월 12일~12월 12일의 경보를 순서대로 만들고, 11월 25일~12월 12일에 처음 발행된 경보의 유형을 예측합니다. 각 경보에는 해당 날짜의 마감 전에 관측한 거래와 그때까지 공개된 거래 점수만 사용합니다. 동일한 HI-Large 원장이면 각 CSV에 경보 1,086건이 기록됩니다.

## 출력

`output/`에 CSV 네 개가 생성됩니다. 경보 식별자는 `date`, `alert`, `version`이며, `type`은 가장 높은 확률의 유형입니다. `--out`으로 결과 폴더를 지정할 수 있습니다.

| 파일 | 예측 방식 |
|---|---|
| `baseline_326.csv` | 326개 특성을 쓰는 기준 ExtraTrees |
| `first.csv` | 908개 특성을 쓰는 1차 ExtraTrees |
| `followup.csv` | 세 원장으로 학습한 후속 ExtraTrees |
| `combined.csv` | 후속 ExtraTrees와 서비스의 거래별 SALT_R 확률을 결합 |

기준 모델 소스와 가중치는 `baseline326/`, 두 908개 특성 모델과 C++ 특성 계산기는 `alert_type/`, 거래 점수와 경보 생성을 담당하는 코드는 `service/`에 있습니다. 두 908개 특성 모델은 손실 없이 다시 압축했으며, 압축을 풀었을 때의 모델 바이트가 연구에 쓴 가중치와 일치합니다. 서비스 코드 기준 커밋은 `ce5b429`입니다. [GitHub 서비스 소스](https://github.com/dh0728/money_laundry/tree/ce5b429ae74c5f9ccdf13ca72e785353d862dffd)

서비스에서 이미 발행한 경보 묶음이 있다면 `alert_type/classify.py`로 908개 특성 모델을 직접 호출할 수 있습니다. `--alerts`는 `cutoff`와 `alerts` 배열이 있는 JSON이고, 각 경보에는 `alertId`, `version`, `evidence.transactions`가 있어야 합니다. 각 거래의 `txId`와 `role`로 SEED·CONNECTION 거래를 식별합니다. `--available-from`에는 해당 경보 분석 때 사용 가능했던 원장 이력의 시작 시각을 지정하세요.

```bash
python alert_type/classify.py --transactions "/path/to/parquets/HI-Large/transactions.parquet" \
  --alerts "/path/to/alerts.json" --available-from 2022-11-06 \
  --model alert_type/followup.joblib --out followup.csv
```
