"""Classify raw published Alert versions against a frozen service transaction material."""
import argparse
import ctypes
import json
import functools
import subprocess
import tempfile
from pathlib import Path
import duckdb
import joblib
import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from ledger import DT, I, P, CURRENCIES, FORMATS, HERE, minute

ISO=["AUD","BTC","BRL","CAD","EUR","MXN","RUB","INR","SAR","ILS","CHF","GBP","USD","JPY","CNY"]
CURRENCY=dict(zip(ISO,CURRENCIES))


@functools.lru_cache(maxsize=1)
def native_features():
    with tempfile.TemporaryDirectory(prefix="aml-alert-library-") as directory:
        path=Path(directory)/"neighborhood.so"
        subprocess.run(["g++","-O3","-std=c++17","-fPIC","-shared",str(HERE/"neighborhood.cpp"),"-o",str(path)],check=True)
        return ctypes.CDLL(str(path))


def local_timestamp(value):
    value=pd.Timestamp(value)
    return value.tz_convert("Asia/Seoul").tz_localize(None) if value.tzinfo else value


def raw_alerts(batch):
    items=[]
    for row in batch["alerts"]:
        if "evidence" in row:
            members=row["evidence"]["transactions"]
            seeds=[int(m["txId"]) for m in members if m["role"]=="SEED"]
            core=[int(m["txId"]) for m in members if m["role"] in ("SEED","CONNECTION")]
            alert=row["alertId"]
        else:
            seeds=list(map(int,row["seeds"] if "seeds" in row else [row["seed"]]))
            core=list(map(int,row["core"]))
            alert=row["alert"]
        if not seeds or not set(seeds)<=set(core) or len(set(core))!=len(core):
            raise ValueError("Invalid or duplicate core members")
        items.append((alert,row.get("version",1),seeds,core))
    if len({(a,v) for a,v,_,_ in items})!=len(items):
        raise ValueError("Duplicate Alert version")
    return items


def projected(path,items,cutoff,available_from):
    schema=pq.read_schema(path)
    if "tx_id" in schema.names:
        stamp="timezone('Asia/Seoul',occurred_at)"
        if not getattr(schema.field("occurred_at").type,"tz",None):
            raise ValueError("dev occurred_at must include its time zone")
        source="to_json(struct_pack(bank:=from_bank_id,account:=from_account_id))"
        dest="to_json(struct_pack(bank:=to_bank_id,account:=to_account_id))"
        key,paid,received="tx_id","amount_paid","amount_received"
    else:
        key,stamp,source,dest,paid,received="edge_id","ts","src","dst","paid","received"
    conn=duckdb.connect(config={"threads":2,"memory_limit":"2GB"})
    try:
        conn.read_parquet(str(path)).create_view("source_data")
        conn.register("bounds",pd.DataFrame({"lo":[available_from],"hi":[cutoff],"lookback":[cutoff-pd.Timedelta(days=45)]}))
        conn.register("core_keys",pd.DataFrame({"id":sorted({i for _,_,_,core in items for i in core})}))
        conn.execute(f"""CREATE TEMP VIEW seen AS SELECT {key} AS id,{stamp} AS t,{source} AS s,{dest} AS d,
          {paid} AS paid,{received} AS received,payment_format AS fmt,payment_currency AS pc,receiving_currency AS rc
          FROM source_data,bounds WHERE {stamp}>=lo AND {stamp}<hi""")
        cores=conn.execute("SELECT * FROM seen JOIN core_keys USING(id) ORDER BY t,id").df()
        if not cores.id.is_unique or set(cores.id)!={i for _,_,_,core in items for i in core}:
            raise ValueError("A requested core is missing, duplicated or outside the frozen input")
        # All root+rail combinations are included; the native features choose the dominant rail per Alert.
        lookup=cores.set_index("id")
        pairs=set()
        for _,_,_,members in items:
            block=lookup.loc[members]
            accounts=set(block.s)|set(block.d)
            pairs.update((node,fmt) for node in accounts for fmt in set(block.fmt))
        roots=pd.DataFrame(list(pairs),columns=["node","fmt"])
        conn.register("roots",roots)
        conn.execute("""CREATE TEMP TABLE first_legs AS SELECT s,d,fmt FROM seen,bounds WHERE t>=lookback AND
            ((s,fmt) IN (SELECT node,fmt FROM roots) OR (d,fmt) IN (SELECT node,fmt FROM roots))""")
        conn.execute("""CREATE TEMP TABLE touched AS SELECT node,fmt FROM roots UNION SELECT s,fmt FROM first_legs
            UNION SELECT d,fmt FROM first_legs""")
        data=conn.execute("""SELECT id,t,s,d,paid,received,fmt,pc,rc FROM seen,bounds WHERE id IN (SELECT id FROM core_keys) OR
            (t>=lookback AND ((s,fmt) IN (SELECT node,fmt FROM touched) OR (d,fmt) IN (SELECT node,fmt FROM touched)))
            ORDER BY t,id""").df()
    finally:
        conn.close()
    if data.isna().any().any() or not data.id.is_unique or not data.t.lt(cutoff).all():
        raise ValueError("Invalid frozen transactions")
    if not data.t.eq(data.t.dt.floor("min")).all():
        raise ValueError("The dev inference material requires whole-minute transaction times")
    return data


def local_features(data,items,cutoff,available_from,shuffle_nodes=False):
    # Original SQL/Parquet IDs can be UUIDs or 64-bit keys. Native IDs are temporary
    # chronological row numbers, used solely for lookup. Nodes are equality codes.
    size=len(data)
    nodes=pd.Index(pd.unique(pd.concat([data.s,data.d],ignore_index=True)))
    if shuffle_nodes:nodes=nodes.take(np.random.default_rng(148).permutation(len(nodes)))
    tx=np.zeros(size,dtype=DT)
    tx["id"]=np.arange(size,dtype="i4")
    tx["t"]=((data.t-pd.Timestamp("2022-08-01"))//pd.Timedelta(minutes=1)).astype("i4")
    tx["s"],tx["d"]=nodes.get_indexer(data.s),nodes.get_indexer(data.d)
    for k in ("paid","received"):
        tx[k]=data[k].to_numpy(dtype=np.float32)
        if not np.isfinite(tx[k]).all() or (tx[k]<0).any():raise ValueError("Invalid amount")
    for k,valid in (("fmt",FORMATS),("pc",CURRENCIES),("rc",CURRENCIES)):
        vals=data[k] if k=="fmt" else data[k].astype(object).map(lambda v:CURRENCY.get(v,v))
        codes=pd.Categorical(vals,categories=valid).codes
        if (codes<0).any():raise ValueError(f"Unsupported {k} value")
        tx[k]=codes
    offset,indices=[],[]
    for side in ("s","d"):
        keys=tx[side]*7+tx["fmt"]
        order=np.argsort(keys,kind="stable").astype("i4")
        offset.append(np.r_[0,np.cumsum(np.bincount(keys,minlength=len(nodes)*7))].astype("i4"))
        indices.append(order)
    lib=native_features()
    call=lib.features
    call.argtypes=[P,I,P,P,P,P,P,I,I,I,P,I,P]
    call.restype=I
    lib.feature_names.restype=ctypes.c_char_p
    row_map=dict(zip(data.id,tx["id"]))
    cut=minute(cutoff)
    lo=minute(available_from)
    outputs=[]
    for _,_,seeds,core in items:
        seed=max(seeds,key=row_map.__getitem__)
        ids=np.array([row_map[seed],*sorted(row_map[k] for k in core if k!=seed)],dtype="i4")
        buf=np.empty(2048,"f4")
        audit=np.empty(2,"i4")
        n=call(tx.ctypes.data,size,*[a.ctypes.data for a in offset+indices],ids.ctypes.data,len(ids),lo,cut,
               buf.ctypes.data,len(buf),audit.ctypes.data)
        if n<=0 or audit[1]>=cut or audit[0]<lo:raise ValueError("Invalid feature history")
        outputs.append(buf[:n].copy())
    return pd.DataFrame(outputs,columns=lib.feature_names().decode().splitlines())


def alert_features(path, batch, available_from=None):
    cutoff = local_timestamp(batch["cutoff"])
    if cutoff != cutoff.floor("min"):
        raise ValueError("Cutoff must use whole minutes")
    lo = local_timestamp(available_from) if available_from is not None else pd.Timestamp("1900-01-01")
    items = raw_alerts(batch)
    if not items:
        return items, pd.DataFrame()
    table = projected(path, items, cutoff, lo)
    return items, local_features(table, items, cutoff, lo)


def predict_features(items, frame, model, baseline=None):
    types = model["types"]
    if not items:
        return pd.DataFrame(columns=["alert", "version", "type", *types])
    if model["winner"]=="forest":
        cols,clf=model["models"]["forest"]
    elif model["winner"] in ("augmented","blend"):
        cols,clf=model["columns"],model["forest"]
    else:
        raise ValueError("Unrecognized model artifact")
    if list(frame)!=list(cols):raise ValueError("Unexpected feature schema")
    clf.n_jobs=1
    scores=clf.predict_proba(frame.to_numpy(dtype="f4"))
    if model["winner"]=="blend":
        if baseline is None:raise ValueError("This ensemble requires the matching original 326-model probabilities")
        keys=pd.DataFrame([(a,v) for a,v,_,_ in items],columns=["alert","version"])
        joined=keys.merge(baseline[["alert","version",*types]],on=["alert","version"],how="left",validate="one_to_one")
        probs=joined[types].to_numpy(dtype=float)
        if not np.isfinite(probs).all() or (probs<0).any() or not np.allclose(probs.sum(1),1):
            raise ValueError("Missing or invalid baseline probabilities for an Alert version")
        scores=(scores+probs)/2
    out=pd.DataFrame(scores,columns=types)
    out.insert(0,"type",np.asarray(types)[scores.argmax(1)])
    out.insert(0,"version",[v for _,v,_,_ in items])
    out.insert(0,"alert",[a for a,_,_,_ in items])
    return out


def classify(path, batch, model_path, available_from=None, baseline=None):
    items, frame = alert_features(path, batch, available_from)
    return predict_features(items, frame, joblib.load(model_path), baseline)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--transactions",type=Path,required=True)
    parser.add_argument("--alerts",type=Path,required=True)
    parser.add_argument("--model",type=Path,default=HERE/"alert_model.joblib")
    parser.add_argument("--available-from",help="Optional lower bound of the run's available ledger")
    parser.add_argument("--baseline",type=Path,help="326-model probabilities keyed by alert and version for the blend")
    parser.add_argument("--out",type=Path,required=True)
    args=parser.parse_args()
    result=classify(args.transactions,json.loads(args.alerts.read_text()),args.model,args.available_from,pd.read_csv(args.baseline) if args.baseline else None)
    result.to_csv(args.out,index=False)
