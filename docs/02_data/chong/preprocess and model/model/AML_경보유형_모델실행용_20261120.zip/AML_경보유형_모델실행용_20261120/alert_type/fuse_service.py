"""Combine a first Alert's frozen forest probabilities with dev's published transaction type scores."""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from classify import raw_alerts

TYPES=['FAN-OUT','FAN-IN','CYCLE','SC-GA','GA-SC','RANDOM']
SALT=[f'p_{i}' for i in range(9)]
ORDER=[1,2,5,4,3,6]
THRESHOLD=.194997844


def mix(forest,items,scored):
    alerts=pd.DataFrame([(a,v) for a,v,_,_ in items],columns=['alert','version'])
    f=alerts.merge(forest[['alert','version',*TYPES]],on=['alert','version'],how='left',validate='one_to_one')
    if len(f)!=len(forest) or f[TYPES].isna().any().any():raise ValueError('Forest scores must match this batch of Alert versions')
    if scored.tx_id.duplicated().any() or not scored.p_laundering.between(0,1).all():raise ValueError('Invalid frozen transaction scores')
    valid=scored[scored.p_laundering>=THRESHOLD].set_index('tx_id')[SALT]
    w=valid.to_numpy(dtype=float); base=f[TYPES].to_numpy(dtype=float)
    for r in (w,base):
        if not np.isfinite(r).all() or (r<0).any() or not np.allclose(r.sum(axis=1),1,atol=1e-6,rtol=0):raise ValueError('Invalid class probabilities')
    ids={v:i for i,v in enumerate(valid.index)};counts=[];out=base.copy()
    for row,(_,_,_,core) in enumerate(items):
        loc=[ids[t] for t in core if t in ids];counts.append(len(loc))
        if loc:
            q=w[loc].mean(axis=0)[ORDER];out[row]=.5*q+(1-.5*q.sum())*base[row]
    result=f[['alert','version']].copy();result['type']=np.asarray(TYPES)[out.argmax(axis=1)];result['scored_members']=counts
    for i,c in enumerate(TYPES):result[c]=out[:,i]
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for a in ['forest','alerts','type-scores','out']:p.add_argument('--'+a,type=Path,required=True)
    args=p.parse_args();scored=pd.read_csv(args.type_scores)
    out=mix(pd.read_csv(args.forest),raw_alerts(json.loads(args.alerts.read_text())),scored);out.to_csv(args.out,index=False)
