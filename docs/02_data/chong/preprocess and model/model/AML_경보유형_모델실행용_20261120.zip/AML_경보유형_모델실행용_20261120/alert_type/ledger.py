"""Native feature schema and time origin."""
import ctypes
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
ORIGIN = pd.Timestamp("2022-08-01")
CURRENCIES = ["Australian Dollar","Bitcoin","Brazil Real","Canadian Dollar","Euro","Mexican Peso","Ruble","Rupee","Saudi Riyal","Shekel","Swiss Franc","UK Pound","US Dollar","Yen","Yuan"]
FORMATS = ["Reinvestment","Cheque","Cash","Wire","ACH","Credit Card","Bitcoin"]
DT = np.dtype([(k,"<i4") for k in ("id","t","s","d")]+[(k,"<f4") for k in ("paid","received")]+[(k,"u1") for k in ("fmt","pc","rc","pad")])
P = ctypes.c_void_p
I = ctypes.c_int


def minute(stamp):
    return int((pd.Timestamp(stamp)-ORIGIN)//pd.Timedelta(minutes=1))
