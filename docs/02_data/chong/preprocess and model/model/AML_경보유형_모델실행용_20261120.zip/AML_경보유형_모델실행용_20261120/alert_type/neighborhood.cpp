// Structural measurements from the point-in-time, directed payment graph of each raw Alert.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <map>
#include <set>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <stdexcept>
#include <limits>

struct Tx { int32_t id,t,s,d; float paid,received; uint8_t fmt,pc,rc,pad; };
static_assert(sizeof(Tx)==28);
static const double per_usd[]={1.4128,.00008416,5.64649997,1.31930001,.8534,21.1431018,77.80399773,73.44397914,3.75109996,3.37699997,.915,.7742,1,105.39995594,6.6976002};
using Block=std::vector<double>;
using Named=std::vector<std::pair<std::string,double>>;
double lg(double x){return std::log1p(std::max(x,0.0));}
double ratio(double x,double y){return std::log((1.+x)/(1.+y));}
double dollars(const Tx& t,bool at_receiver){return at_receiver?t.received/per_usd[t.rc]:t.paid/per_usd[t.pc];}

struct Index {
    const Tx* tx;
    const int32_t* ptr[2];
    const int32_t* ids[2];
    int n;
    int low,cut,access_max=-1,access_min=2147483647;
    int row(int id) const{
        auto pos=std::lower_bound(tx,tx+n,id,[](const Tx& t,int id){return t.id<id;});
        if(pos==tx+n||pos->id!=id||pos->t<low||pos->t>=cut) throw std::runtime_error("core outside frozen ledger");
        return int(pos-tx);
    }
    std::vector<int> edges(int node,int fmt,int dir,int from,int until,int cap){
        int k=node*7+fmt;
        const int* a=ids[dir]+ptr[dir][k],*b=ids[dir]+ptr[dir][k+1];
        auto cmp=[this](int i,int t){return i<n && tx[i].t<t;};
        a=std::lower_bound(a,b,std::max(low,from),cmp);
        b=std::lower_bound(a,b,std::min(cut,until),cmp);
        const int size=int(b-a),keep=std::min(size,cap);
        std::vector<int> out;out.reserve(keep);
        for(int h=0;h<keep;h++){
            const int at=(size<=cap)?h:int(int64_t(h)*(size-1)/(keep-1));
            const int i=a[at];
            if(tx[i].s==tx[i].d) continue;
            access_min=std::min(access_min,tx[i].t);
            access_max=std::max(access_max,tx[i].t);
            out.push_back(i);
        }
        return out;
    }
};

Block stats(Block v){
    if(v.empty())return {0,0,0,0};
    std::sort(v.begin(),v.end());
    double total=0;for(double x:v)total+=x;
    return {v.front(),total/v.size(),v[v.size()/2],v.back()};
}

struct PathCounts {
    int paths=0,conserved=0,returns=0,peer_with_path=0;
    std::map<int,std::set<int>> ends,conserved_ends;
};

// Explore ordered paths either downstream or upstream. Multiple distinct intermediaries
// leading back to a common account expose scatter/gather evidence outside the Alert core.
Named side(Index& g,int root,int fmt,int dir,int start,const std::vector<int>& incident){
    PathCounts c;
    std::set<int> distinct;
    Block peer_counts,amounts,gaps,nearest_gaps,time_delays;
    double volume=0;
    int earliest=g.cut,latest=start;
    for(int i:incident){
        const auto& edge=g.tx[i];
        const int peer=dir?edge.s:edge.d;
        distinct.insert(peer);
        const double local=dollars(edge,dir), remote=dollars(edge,!dir);
        volume+=local;amounts.push_back(lg(local));earliest=std::min(earliest,edge.t);latest=std::max(latest,edge.t);
        const int lo=dir?start:edge.t+1,hi=dir?edge.t:g.cut;
        auto next=g.edges(peer,fmt,dir,lo,hi,36);
        peer_counts.push_back(lg(next.size()));
        if(!next.empty())c.peer_with_path++;
        double best=40;
        for(int j:next){
            const auto& other=g.tx[j];
            int end=dir?other.s:other.d;
            const double amt=dollars(other,dir);
            const double gap=std::abs(ratio(remote,amt));
            best=std::min(best,gap);gaps.push_back(gap);c.paths++;
            if(end==root)c.returns++;
            else c.ends[end].insert(peer);
            if(gap<=.35){
                c.conserved++;c.conserved_ends[end].insert(peer);
                time_delays.push_back(lg(std::abs(edge.t-other.t)));
            }
        }
        if(!next.empty())nearest_gaps.push_back(best);
    }
    int diamonds=0,best=0,strong=0;
    for(const auto& item:c.ends){int n=item.second.size();if(n>=2)diamonds++;best=std::max(best,n);}
    for(const auto& item:c.conserved_ends)if(item.second.size()>=2)strong++;
    return {{"legs",lg(incident.size())},{"peers",lg(distinct.size())},{"volume",lg(volume)},
            {"span",lg(latest-earliest)},{"age",incident.empty()?0:lg(g.cut-latest)},
            {"peer_path_share",double(c.peer_with_path)/std::max(size_t(1),incident.size())},
            {"paths",lg(c.paths)},{"conserved",lg(c.conserved)},{"returns",lg(c.returns)},
            {"ends",lg(c.ends.size())},{"convergence",lg(diamonds)},{"max_convergence",lg(best)},
            {"conserved_convergence",lg(strong)},{"peer_paths",stats(peer_counts)[1]},
            {"median_size",stats(amounts)[2]},{"range_size",stats(amounts)[3]-stats(amounts)[0]},
            {"best_money_gap",stats(nearest_gaps)[0]},{"mean_best_money_gap",stats(nearest_gaps)[1]},
            {"mean_money_gap",stats(gaps)[1]},{"conserved_delay",stats(time_delays)[2]}};
}

Named point(Index& g,int root,int fmt,int start){
    auto in=g.edges(root,fmt,1,start,g.cut,96);
    auto out=g.edges(root,fmt,0,start,g.cut,96);
    Named fields;
    for(auto kv:side(g,root,fmt,1,start,in))fields.emplace_back("in_"+kv.first,kv.second);
    for(auto kv:side(g,root,fmt,0,start,out))fields.emplace_back("out_"+kv.first,kv.second);
    Block first,last,best_gap,ordered_gap;
    std::map<int,int> first_by_peer,last_by_peer;
    double credit=0,debit=0;
    for(int i:in){
        auto& a=g.tx[i];credit+=dollars(a,true);
        if(!first_by_peer.count(a.s))first_by_peer[a.s]=a.t;
    }
    int funded=0;
    for(int j:out){
        auto& b=g.tx[j];debit+=dollars(b,false);last_by_peer[b.d]=b.t;
        double best=40,ordered=40;
        for(int i:in){
            auto& a=g.tx[i];if(a.s==b.d)continue;
            double gap=std::abs(ratio(dollars(a,true),dollars(b,false)));
            best=std::min(best,gap);
            if(a.t<b.t)ordered=std::min(ordered,gap);
        }
        if(ordered<=.35)funded++;
        best_gap.push_back(best);ordered_gap.push_back(ordered);
    }
    for(auto v:first_by_peer)first.push_back(v.second);
    for(auto v:last_by_peer)last.push_back(v.second);
    std::sort(first.begin(),first.end());std::sort(last.rbegin(),last.rend());
    int paired=0;
    for(size_t k=0;k<std::min(first.size(),last.size());k++)if(first[k]<last[k])paired++;
    int repeated=0;for(auto v:first_by_peer)repeated+=last_by_peer.count(v.first);
    fields.insert(fields.end(),{{"both_sides",lg(std::min(in.size(),out.size()))},
        {"through_peers",lg(paired)},{"returning_peers",lg(repeated)},{"balance",ratio(credit,debit)},
        {"funded",lg(funded)},{"funded_share",double(funded)/std::max(size_t(1),out.size())},
        {"earlier_later_span",lg(first.size()>1&&last.size()>1?last[1]-first[1]:0)},
        {"minimum_gap",stats(best_gap)[0]},{"mean_ordered_gap",stats(ordered_gap)[1]}});
    return fields;
}

Named describe(Index& g,const std::vector<int>& core){
    Named output;
    std::map<int,int> send,receive,rails;
    std::set<std::pair<int,int>> pairs;
    Block money,gaps;
    int first=g.cut,last=g.low,paths=0,returning=0,cross=0,self=0;
    for(int i:core){
        const auto& a=g.tx[i];send[a.s]++;receive[a.d]++;rails[a.fmt]++;pairs.emplace(a.s,a.d);
        self+=a.s==a.d;cross+=a.pc!=a.rc;money.push_back(lg(dollars(a,false)));
        first=std::min(first,a.t);last=std::max(last,a.t);
        for(int j:core){const auto& b=g.tx[j];
            if(a.d==b.s&&a.t<b.t){paths++;returning+=a.s==b.d;gaps.push_back(std::abs(ratio(dollars(a,true),dollars(b,false))));}
        }
    }
    int maxin=0,maxout=0,mixed=0;
    for(auto v:send){maxout=std::max(maxout,v.second);mixed+=receive.count(v.first);}
    for(auto v:receive)maxin=std::max(maxin,v.second);
    output={{"core_size",lg(core.size())},{"senders",lg(send.size())},{"receivers",lg(receive.size())},
            {"pairs",lg(pairs.size())},{"mixed",lg(mixed)},{"fanout",lg(maxout)},{"fanin",lg(maxin)},
            {"chain",lg(paths)},{"return",lg(returning)},{"through_money_gap",stats(gaps)[1]},
            {"self_share",double(self)/core.size()},{"cross_currency",double(cross)/core.size()},
            {"span",lg(last-first)},{"last_age",lg(g.cut-last)},{"rail_count",lg(rails.size())}};
    const auto ms=stats(money);
    for(int i=0;i<4;i++)output.emplace_back("amount_"+std::to_string(i),ms[i]);
    for(int i=0;i<7;i++)output.emplace_back("rail_share_"+std::to_string(i),double(rails[i])/core.size());
    int rail=g.tx[core[0]].fmt;
    for(auto v:rails)if(v.second>rails[rail])rail=v.first;
    // Source and receiver roles remain distinct. Explore the most frequent core hubs;
    // break ties by the original core order, independent of account numbering.
    for(int dir=0;dir<2;dir++){
        const auto& frequencies=dir?receive:send;
        std::vector<int> roots;
        for(int i:core){
            int n=dir?g.tx[i].d:g.tx[i].s;
            if(std::find(roots.begin(),roots.end(),n)==roots.end())roots.push_back(n);
        }
        std::stable_sort(roots.begin(),roots.end(),[&](int a,int b){return frequencies.at(a)>frequencies.at(b);});
        roots.resize(std::min(roots.size(),size_t(5)));
        for(int days:{2,14,45}){
            const int start=std::max(g.low,g.cut-1440*days);
            std::vector<Named> points;
            for(int n:roots)points.push_back(point(g,n,rail,start));
            for(size_t j=0;j<points[0].size();j++){
                Block vals;for(const auto& p:points)vals.push_back(p[j].second);
                std::string name=(dir?"destination_":"source_")+std::to_string(days)+"d_"+points[0][j].first;
                const auto st=stats(vals);
                output.emplace_back(name+"_hub",vals[0]);
                output.emplace_back(name+"_mean",st[1]);
                output.emplace_back(name+"_max",st[3]);
            }
        }
    }
    return output;
}

static std::string names;
extern "C" const char* feature_names(){return names.c_str();}
extern "C" int features(const Tx* tx,int n,const int* p0,const int* p1,const int* i0,const int* i1,
                       const int* core_ids,int size,int low,int cut,float* out,int capacity,int* audit){
    try{
        Index g{tx,{p0,p1},{i0,i1},n,low,cut};
        std::vector<int> core;
        for(int j=0;j<size;j++)core.push_back(g.row(core_ids[j]));
        auto values=describe(g,core);
        if(values.size()>size_t(capacity))return -2;
        if(names.empty())for(auto& kv:values)names+=kv.first+"\n";
        for(size_t j=0;j<values.size();j++)out[j]=float(values[j].second);
        audit[0]=g.access_min;audit[1]=g.access_max;
        return int(values.size());
    } catch(const std::exception&){return -1;}
}
