"""Score the original 326-feature model from the external transaction and KYC files."""
import duckdb
import numpy as np
import pandas as pd
import run_pipeline as pipeline
from et_inference import LABELS, probabilities


def predict(ledger, batch, history_start, artifact):
    start = pd.Timestamp(history_start)
    end = pd.Timestamp(batch["cutoff"])
    path, kpath = str(ledger / "transactions.parquet"), str(ledger / "kyc.parquet")
    alerts = batch["alerts"]
    ids = pd.DataFrame({"edge_id": np.unique(np.concatenate([a["core"] for a in alerts])).astype("i4")})
    with duckdb.connect(config={"threads": 2, "memory_limit": "1600MB"}) as con:
        con.register("requested",ids)
        # Owner-context counts require all accounts with the same static owner as a core endpoint.
        # Every other baseline feature uses core rows or the incident history of their endpoints.
        con.execute("""CREATE TEMP TABLE required_accounts AS WITH endpoints AS (
            SELECT unnest([src,dst]) AS node_id FROM read_parquet(?) JOIN requested USING(edge_id)
            WHERE ts>=? AND ts<?), owners AS (
            SELECT DISTINCT entity_id FROM read_parquet(?) SEMI JOIN endpoints USING(node_id))
            SELECT node_id FROM read_parquet(?) SEMI JOIN owners USING(entity_id)""",[path,start,end,kpath,kpath])
        table=con.sql("""SELECT edge_id,src,dst,ts,paid,received,payment_currency,receiving_currency,payment_format
            FROM read_parquet(?) WHERE ts>=? AND ts<? AND
            (src IN (SELECT node_id FROM required_accounts) OR dst IN (SELECT node_id FROM required_accounts))
            ORDER BY edge_id""", params=[path,start,end]).to_arrow_table()
    raw={}
    for k in ("edge_id","src","dst"):raw[k]=table[k].to_numpy().astype("i4")
    raw["minute"]=((table["ts"].to_numpy()-pipeline.ORIGIN.to_datetime64())/np.timedelta64(1,"m")).astype("i4")
    for k in ("paid","received"):raw[k]=table[k].to_numpy().astype("f8")
    raw["pc"]=pipeline.ordinal(table["payment_currency"],pipeline.CURRENCIES)
    raw["rc"]=pipeline.ordinal(table["receiving_currency"],pipeline.CURRENCIES)
    fmt=pipeline.ordinal(table["payment_format"],pipeline.FORMATS)
    assert np.all(np.diff(raw["edge_id"])>0) and np.all(np.diff(raw["minute"])>=0)
    assert raw["minute"].min()>=int((start - pipeline.ORIGIN) // pd.Timedelta(minutes=1)) and raw["minute"].max()<int((end - pipeline.ORIGIN) // pd.Timedelta(minutes=1))
    frame = pipeline.alert_frame(ledger, batch, artifact["columns"], history=(raw, fmt))
    if frame.alert.tolist() != [a["alert"] for a in alerts]:
        raise ValueError("326개 특성 모델의 경보 순서가 달라졌습니다.")
    scores = probabilities(artifact, frame)
    out = frame[["date", "alert"]].copy()
    out["version"] = [a["version"] for a in alerts]
    out["type"] = np.asarray(LABELS)[scores.argmax(axis=1)]
    out[list(LABELS)] = scores
    return out
