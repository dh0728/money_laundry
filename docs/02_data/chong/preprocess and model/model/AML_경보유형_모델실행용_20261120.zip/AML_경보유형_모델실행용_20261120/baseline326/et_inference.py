"""Use a frozen Extra Trees artifact on a table of as-of Alert features."""
import argparse
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

LABELS = ("FAN-OUT", "FAN-IN", "CYCLE", "SC-GA", "GA-SC", "RANDOM")


def probabilities(artifact, frame):
    columns = artifact["columns"]
    if tuple(artifact["labels"]) != LABELS or frame.columns.has_duplicates or len(set(columns)) != len(columns):
        raise ValueError("Invalid class order or duplicate input columns")
    missing = [name for name in columns if name not in frame]
    if missing:
        raise ValueError(f"Missing {len(missing)} Alert features, starting with {missing[:3]}")
    x = frame[columns].to_numpy(dtype=np.float64)
    if not np.isfinite(x).all():
        raise ValueError("Input contains a non-finite value")
    result = np.zeros((len(frame), len(LABELS)))
    if not len(frame):
        return result
    forest = artifact["forest"]
    result[:, forest.classes_] = forest.predict_proba(x)
    for model in artifact["specialists"]:
        pair = model.classes_
        original = result[:, pair]
        revised = original.sum(axis=1, keepdims=True) * model.predict_proba(x)
        share = artifact["specialist_share"]
        result[:, pair] = (1 - share) * original + share * revised
    if not np.isfinite(result).all() or (result < 0).any() or not np.allclose(result.sum(1), 1):
        raise ValueError("Invalid predicted probabilities")
    return result


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("model", type=Path)
    p.add_argument("features", type=Path)
    args = p.parse_args()
    frame = pd.read_parquet(args.features)
    scores = probabilities(joblib.load(args.model), frame)
    ids = frame[[c for c in ("date","alert") if c in frame]].reset_index(drop=True)
    out = pd.concat([ids, pd.DataFrame(scores, columns=LABELS)], axis=1)
    out["type"] = np.asarray(LABELS)[np.argmax(scores, axis=1)]
    print(out.to_csv(index=False), end="")
