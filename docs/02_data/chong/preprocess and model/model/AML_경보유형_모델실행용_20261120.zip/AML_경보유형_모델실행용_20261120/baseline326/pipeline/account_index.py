import numpy as np

SH = 18


def build_index(sid, did, minute, acc_mask):
    """acc_mask 가 참인 계좌의 거래를 (계좌, 분) 차례로 줄 세움 → (열쇠, 원장 줄 번호)."""
    rs = np.flatnonzero(acc_mask[sid]); rd = np.flatnonzero(acc_mask[did] & (sid != did))
    key = np.r_[(sid[rs].astype(np.int64) << SH) | minute[rs], (did[rd].astype(np.int64) << SH) | minute[rd]]; row = np.r_[rs, rd].astype(np.int32)
    o = np.argsort(key, kind='stable'); return key[o], row[o]
