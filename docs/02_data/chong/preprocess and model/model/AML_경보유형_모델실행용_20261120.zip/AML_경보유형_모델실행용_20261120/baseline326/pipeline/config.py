import pandas as pd

ORIGIN = pd.Timestamp("2022-08-01")
FORMATS = ["Reinvestment", "Cheque", "Cash", "Wire", "ACH", "Credit Card", "Bitcoin"]
CURRENCIES = ['Australian Dollar', 'Bitcoin', 'Brazil Real', 'Canadian Dollar', 'Euro', 'Mexican Peso', 'Ruble', 'Rupee', 'Saudi Riyal', 'Shekel', 'Swiss Franc', 'UK Pound', 'US Dollar', 'Yen', 'Yuan']
RETRIEVAL = {'days': 45, 'recent_per_direction': 96, 'amount_nearest_per_direction': 32}
