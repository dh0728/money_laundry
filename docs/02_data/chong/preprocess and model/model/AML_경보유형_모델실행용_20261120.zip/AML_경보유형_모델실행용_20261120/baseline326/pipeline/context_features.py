"""Alert 핵심 계좌 주변의 시점별 원장 정보. 거래 정답과 사건 ID를 읽지 않는다."""
from collections import Counter

import numpy as np


def core_features(raw, rows):
    s, d = raw["src"][rows], raw["dst"][rows]
    pairs = list(zip(map(int, s), map(int, d)))
    unique_pairs = set(pairs)
    out_count, in_count = Counter(s), Counter(d)
    amounts = list(zip(raw["pc"][rows], raw["paid"][rows]))
    t = raw["minute"][rows]
    return {
        "senders": len(out_count),
        "receivers": len(in_count),
        "both_roles": len(out_count.keys() & in_count.keys()),
        "out_neighbors_max": max(len(set(d[s == n])) for n in out_count),
        "in_neighbors_max": max(len(set(s[d == n])) for n in in_count),
        "reverse_pair_fraction": sum((v, u) in unique_pairs and u != v for u, v in pairs) / len(pairs),
        "identical_amount_fraction": 1 - len(set(amounts)) / len(amounts),
        "currency_kinds": len(set(raw["pc"][rows]) | set(raw["rc"][rows])),
        "span_under_hour": float(t.max() - t.min() < 60),
        "all_same_minute": float(t.max() == t.min()),
        "seed_out_share": out_count[s[0]] / len(rows),
        "seed_in_share": in_count[d[0]] / len(rows),
    }


def shared(sets):
    seen=Counter(node for peers in sets for node in peers)
    top=max(seen.values(),default=0)
    n=len(sets)
    return [np.log1p(top),top/max(n,1),np.log1p(sum(v>=2 for v in seen.values())),
            np.log1p(sum(v-1 for v in seen.values() if v>=2))]


def ledger_context(raw, index, rows, cut):
    key,hist=index
    s,d,t=(raw[n] for n in ("src","dst","minute"))
    src,dst=s[rows],d[rows]
    nodes=set(map(int,np.r_[src,dst]))
    pairs=set(zip(map(int,src),map(int,dst)))
    times=t[rows]
    currencies=np.union1d(raw["pc"][rows],raw["rc"][rows])
    incoming,outgoing={},{}
    temporal_in,temporal_out={},{}
    counts={}
    internal=set()
    for node in nodes:
        base=int(node)<<18
        lo,hi=np.searchsorted(key,[base+max(0,cut-30*1440),base+cut])
        incident=hist[lo:hi]
        # Exclude the Alert itself from the neighborhood history. Ignore self transfers.
        h=incident[(s[incident]!=d[incident]) & ~np.isin(incident,rows)]
        before=times[src==node]
        after=times[dst==node]
        for incoming_role,peers,cc,dest,bound,ordered in [
                (True,s,"rc",incoming,before,temporal_in),(False,d,"pc",outgoing,after,temporal_out)]:
            relevant=h[((d[h]==node) if incoming_role else (s[h]==node)) & np.isin(raw[cc][h],currencies)]
            n_all=len(relevant)
            recent=relevant[-200:]
            other=peers[recent]
            when=t[recent]
            local=other[np.isin(other,list(nodes))]
            for q in local:
                internal.add((int(q),node) if incoming_role else (node,int(q)))
            # All counterparties are represented as sets; financial identifiers never enter model columns.
            dest[node]=set(map(int,other))
            if len(bound):
                causal=(when<=bound.max()) if incoming_role else (when>=bound.min())
                ordered[node]=set(map(int,other[causal]))-nodes
            counts[node,incoming_role]=[np.log1p(n_all),np.log1p(len(dest[node])),
                np.log1p(np.sum(when>=cut-7*1440)),np.log1p(np.sum(when<times.min())),
                np.log1p(np.sum(when>times.max())),np.log1p(len(local))]
    out={}
    for label,group in [("sender",set(map(int,src))),("receiver",set(map(int,dst)))]:
        for inc in [True,False]:
            vals=np.asarray([counts[n,inc] for n in sorted(group)])
            for j,k in enumerate(("count","peers","week","before","after","within_core")):
                stem=f"ctx_{label}_{'in' if inc else 'out'}_{k}"
                out[stem+"_max"]=vals[:,j].max()
                out[stem+"_mean"]=vals[:,j].mean()
    for name,peers in [("senders_share_predecessor",[incoming[n]-nodes for n in sorted(set(src))]),
                       ("receivers_share_successor",[outgoing[n]-nodes for n in sorted(set(dst))]),
                       ("ordered_shared_predecessor",[temporal_in[n] for n in sorted(temporal_in)]),
                       ("ordered_shared_successor",[temporal_out[n] for n in sorted(temporal_out)])]:
        for label,v in zip(("support","fraction","count","excess"),shared(peers)):
            out["ctx_"+name+"_"+label]=v
    for name,vals in [
        ("via_return",[len((outgoing[v]&incoming[u])-nodes) for u,v in pairs]),
        ("via_forward",[len((outgoing[u]&incoming[v])-nodes) for u,v in pairs]),
        ("inout_reciprocal",[len((outgoing[u]&incoming[u])-nodes) for u in nodes])]:
        out["ctx_"+name+"_max"]=np.log1p(max(vals,default=0))
        out["ctx_"+name+"_total"]=np.log1p(sum(vals))
    out["ctx_return_edges"]=np.log1p(sum((v,u) in internal for u,v in pairs))
    out["ctx_new_internal_pairs"]=np.log1p(len(internal-pairs))
    return out
