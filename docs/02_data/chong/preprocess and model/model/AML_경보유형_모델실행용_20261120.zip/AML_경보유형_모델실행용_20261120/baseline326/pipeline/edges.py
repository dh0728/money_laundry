"""Alert 마감 전에 관찰한 거래만으로 같은 흐름의 후보와 거래쌍 피처를 만든다."""
from collections import defaultdict

import numpy as np
import pandas as pd

from . import account_index as E
from .config import FORMATS, ORIGIN, RETRIEVAL


def core_rows(raw, core):
    ids = np.asarray(core, dtype=np.int32)
    rows = np.searchsorted(raw["edge_id"], ids)
    assert np.array_equal(raw["edge_id"][rows], ids)
    return rows


def close_minute(day):
    return ((pd.Timestamp(day)-ORIGIN).days+1)*1440


def account_index(raw, cores):
    rows = core_rows(raw, np.concatenate(list(cores)))
    mask = np.zeros(int(max(raw["src"].max(), raw["dst"].max()))+1, bool)
    mask[raw["src"][rows]] = mask[raw["dst"][rows]] = True
    return E.build_index(raw["src"], raw["dst"], raw["minute"], mask)


def log_amount(a):
    return np.log(np.maximum(np.asarray(a), 1e-8))


def candidates(raw, index, core, cut):
    opts = RETRIEVAL
    key, by_node = index
    s, d = raw["src"], raw["dst"]
    cs, cd = s[core], d[core]
    assert (raw["minute"][core] < cut).all()
    hits = []
    for n in np.unique(np.r_[cs, cd]):
        base = int(n) << 18
        lo, hi = np.searchsorted(key, [base+max(0,cut-opts["days"]*1440), base+cut])
        incident = by_node[lo:hi]
        incident = incident[(s[incident] != d[incident]) & ~np.isin(incident,core)]
        references = defaultdict(list)
        for direction, field, amounts in [(cs, "pc", "paid"), (cd, "rc", "received")]:
            loc = core[direction==n]
            for c, v in zip(raw[field][loc], log_amount(raw[amounts][loc])):
                references[int(c)].append(v)
        for endpoint, cc, amount in [(s, "pc", "paid"), (d, "rc", "received")]:
            r = incident[endpoint[incident] == n]
            if not len(r):
                continue
            hits.append(r[-opts["recent_per_direction"]:])
            currency = raw[cc][r]
            values = log_amount(raw[amount][r])
            diff = np.full(len(r), np.inf)
            for c, targets in references.items():
                use = np.flatnonzero(currency==c)
                if len(use):
                    for v in targets:
                        diff[use] = np.minimum(diff[use], np.abs(values[use]-v))
            valid = np.flatnonzero(np.isfinite(diff))
            order = np.lexsort((-r[valid], diff[valid]))
            hits.append(r[valid[order[:opts["amount_nearest_per_direction"]]]])
    found = np.unique(np.concatenate(hits)) if hits else np.array([], np.int32)
    assert not np.intersect1d(found, core).size
    assert ((raw["minute"][found] < cut) & (raw["minute"][found] >= max(0,cut-opts["days"]*1440))).all()
    return found


def pair_features(raw, fmt, core, rows, cut):
    s, d, time = [raw[k][rows] for k in ("src", "dst", "minute")]
    cs, cd, ct = [raw[k][core] for k in ("src", "dst", "minute")]
    sf, cf = fmt[rows], fmt[core]
    tdiff = time[:, None]-ct
    cols = {
        "age": np.log1p(cut-time),
        "nearest_time": np.log1p(np.abs(tdiff).min(axis=1)),
        "before_core": time < ct.min(),
        "after_core": time > ct.max(),
        "same_minute": (tdiff==0).any(axis=1),
        "same_format_share": (sf[:,None]==cf).mean(axis=1),
        "same_format_seed": sf == cf[0],
        "cross_currency": raw["pc"][rows] != raw["rc"][rows],
        "core_edges": np.full(len(rows), np.log1p(len(core))),
        "core_out_accounts": np.full(len(rows), len(set(cs))),
        "core_in_accounts": np.full(len(rows), len(set(cd))),
        "exact_pair": ((s[:,None]==cs) & (d[:,None]==cd)).any(axis=1),
        "reverse_pair": ((d[:,None]==cs) & (s[:,None]==cd)).any(axis=1),
    }
    for i, fmt_name in enumerate(FORMATS):
        cols["format_"+fmt_name.replace(" ","_")] = sf==i
    for role, endpoint, amount, cc in [("s",s,"paid","pc"), ("d",d,"received","rc")]:
        a = log_amount(raw[amount][rows])
        c = raw[cc][rows]
        for other, e, amt, ccy in [("s",cs,"paid","pc"), ("d",cd,"received","rc")]:
            match = endpoint[:,None] == e
            valid = match & (c[:,None]==raw[ccy][core])
            gap = a[:,None]-log_amount(raw[amt][core])
            stem = role + other
            nearest = np.where(valid,np.abs(gap),40).min(axis=1)
            cols[stem+"_role"] = match.sum(axis=1)
            cols[stem+"_money_gap"] = np.minimum(nearest,20)
            cols[stem+"_equal_amount"] = nearest < 1e-5
            cols[stem+"_earlier"] = (valid & (tdiff < 0)).any(axis=1)
            cols[stem+"_near_time"] = np.log1p(np.where(valid,np.abs(tdiff),100000).min(axis=1))
            total = np.where(valid,raw[amt][core],0).sum(axis=1)
            cols[stem+"_ratio_to_total"] = np.where(total>0,np.clip(a-log_amount(total),-12,12),15)
    return pd.DataFrame(cols, dtype=np.float32)
