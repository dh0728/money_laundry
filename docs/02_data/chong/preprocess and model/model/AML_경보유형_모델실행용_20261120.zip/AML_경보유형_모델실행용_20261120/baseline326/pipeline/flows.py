"""소속 가능성이 높은 후보의 방향, 시간, 신뢰도를 사용해 자금흐름을 요약한다."""
from collections import defaultdict

import numpy as np

from .config import FORMATS


def summarize(out, stem, values):
    x = sorted(values, reverse=True)
    out[stem+"_best"] = x[0] if x else 0.
    out[stem+"_mass"] = np.log1p(sum(x))


def topology(raw, core, rows, p):
    # A repeated transfer in the same direction cannot supply two distinct branches.
    send, receive, times = [raw[k][rows] for k in ("src","dst","minute")]
    incoming, outgoing = defaultdict(list), defaultdict(list)
    pairs = {}
    for u, v, t, w in zip(send.tolist(), receive.tolist(), times.tolist(), p.tolist()):
        if u == v:
            continue
        incoming[v].append((u,t,w))
        outgoing[u].append((v,t,w))
        pairs[u,v] = max(pairs.get((u,v),0.),w)
    fan_out, fan_in, gathers, reciprocals = [], [], [], []
    paths = defaultdict(dict)
    for node in incoming.keys() | outgoing.keys():
        ins, outs = incoming[node], outgoing[node]
        for links, strengths in ((ins,fan_in),(outs,fan_out)):
            peers = {}
            for peer, _, w in links:
                peers[peer] = max(w, peers.get(peer,0.))
            ranks = sorted(peers.values(),reverse=True)
            if len(ranks)>=2:
                strengths.append(ranks[1])
        for u, ti, wi in ins:
            for v, to, wo in outs:
                if ti<=to and u!=v:
                    mids = paths[u,v]
                    mids[node] = max(mids.get(node,0.),min(wi,wo))
        # A gather-scatter needs two earlier payers and two later beneficiaries.
        if len(ins)>=2 and len(outs)>=2:
            best = 0.
            for boundary in {t for _,t,_ in ins}:
                before, after = {}, {}
                for n,t,w in ins:
                    if t<=boundary:
                        before[n] = max(before.get(n,0.),w)
                for n,t,w in outs:
                    if t>=boundary:
                        after[n] = max(after.get(n,0.),w)
                if len(before)>=2 and len(after)>=2:
                    wi = sorted(before.values())[-2]
                    wo = sorted(after.values())[-2]
                    best = max(best,min(wi,wo))
            gathers.append(best)
    scatter_gather, triangles, squares = [], [], []
    for (u,v), mids in paths.items():
        if len(mids)>=2:
            scatter_gather.append(sorted(mids.values())[-2])
        if (v,u) in pairs:
            triangles.append(min(max(mids.values()),pairs[v,u]))
        if u<v and (v,u) in paths:
            closed = [min(w,z) for a,w in mids.items() for b,z in paths[v,u].items() if a!=b]
            if closed:
                squares.append(max(closed))
    for (u,v), w in pairs.items():
        if u<v and (v,u) in pairs:
            reciprocals.append(min(w,pairs[v,u]))
    out = {}
    for stem, vals in [("out",fan_out),("in",fan_in),("gather_scatter",gathers),
                       ("scatter_gather",scatter_gather),("return",reciprocals),
                       ("triangle",triangles),("square",squares)]:
        summarize(out,stem,vals)
    out["weighted_edges"] = np.log1p(sum(pairs.values()))
    out["nodes"] = np.log1p(len(set(send)|set(receive)))
    return out


def evidence(raw, fmt, core, candidates, scores):
    # Investigation and scoring are deterministic at score ties.
    order = np.lexsort((candidates,-scores))[:32]
    top, w = candidates[order], scores[order]
    csrc, cdst = raw["src"][core], raw["dst"][core]
    out = {"log_core_size":np.log1p(len(core)), "core_senders":len(set(csrc)),
           "core_receivers":len(set(cdst)), "core_both_roles":len(set(csrc)&set(cdst))}
    for i,name in enumerate(FORMATS):
        out["core_fmt_"+name.replace(" ","_")] = np.mean(fmt[core]==i)
    cs, cd = raw["src"][top], raw["dst"][top]
    for name, mask in [("all",np.ones(len(top),bool)),("into_senders",np.isin(cd,csrc)),
                       ("from_senders",np.isin(cs,csrc)),("from_receivers",np.isin(cs,cdst)),
                       ("into_receivers",np.isin(cd,cdst))]:
        summarize(out, name, w[mask])
    for k in (4,16,32):
        graph = np.r_[core,top[:k]]
        weights = np.r_[np.ones(len(core)),w[:k]]
        for key, value in topology(raw,core,graph,weights).items():
            out[f"top{k}_{key}"] = value
    return out, top, w
