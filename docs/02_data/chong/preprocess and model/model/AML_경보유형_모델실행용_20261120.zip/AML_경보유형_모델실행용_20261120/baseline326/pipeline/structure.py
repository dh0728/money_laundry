import numpy as np

STRUCT = ["log_edges","log_accounts","log_pairs","log_max_out","log_max_in","log_multi_out","log_multi_in","log_span_minutes"]


def core_structure(raw, rows):
    # Match the eight graph counts and float32 storage in Cases.structure.
    s,d = raw["src"][rows], raw["dst"][rows]
    _, out = np.unique(s, return_counts=True)
    _, inc = np.unique(d, return_counts=True)
    items = [len(rows),len(np.union1d(s,d)),len(set(zip(s,d))),out.max(),inc.max(),
             (out>1).sum(),(inc>1).sum(),np.ptp(raw["minute"][rows])]
    return dict(zip(STRUCT,np.log1p(items).astype(np.float32)))
