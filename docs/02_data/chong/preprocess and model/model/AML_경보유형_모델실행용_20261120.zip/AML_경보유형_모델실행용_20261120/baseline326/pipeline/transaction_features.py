"""거래별 피처 원본 식과 순서."""
import numpy as np
import pandas as pd
from . import account_index as E

ROLES = ("src","dst")
NODE_BASE = ("log_out_count","log_in_count","log_out_neighbors","log_in_neighbors","log_active_days")
OWNER = ("log_entity_observed_accounts","log_entity_out_diversity","log_entity_in_diversity")
TYPES_KYC = ("Corporation","Partnership","Sole Proprietorship","Individual","Country","Direct")
GROUP = {
    "base": ["pair_prior_count","pair_gap_minutes","pair_count_1h","reverse_history_count","sender_count_1h",
             "receiver_count_1h","sender_gap_minutes","receiver_gap_minutes","paid_currency_z",
             "minute_sender_vs_prior_hour","minute_receiver_vs_prior_hour"] +
            [f"{r}_{n}" for n in ("day_ccy_rate_vs_prior",*NODE_BASE) for r in ROLES],
    "A":["src_uniq_dst_1d","dst_uniq_src_1d","src_out_1d"], "B":["hour_sin","hour_cos","weekday"],
    "C":[f"{r}_{n}" for n in OWNER for r in ROLES],
    "D":[f"{r}_type_{t.replace(' ','_')}" for t in TYPES_KYC for r in ROLES]+["same_known_country","both_countries_known"],
    "E":["src_day_ccy_flow_balance","dst_day_ccy_flow_balance","src_day_ccy_log_matching_in_amount",
         "src_prior_ccy_amount_vs_mean","dst_prior_ccy_amount_vs_mean"],
    "F":["src_prior_ccy_amount_seen","dst_prior_ccy_amount_seen","pair_amount_seen_before_day"],
    "G":["pair_age_at_day_start","same_currency","is_self_transfer"]+
        [f"{r}_{n}" for n in ("log_self_count","log_reciprocal_neighbors","mean_paid_currency_z","paid_outlier_fraction","log_currency_count") for r in ROLES],
}
NAMES = sum(GROUP.values(), [])
assert len(NAMES) == len(set(NAMES)) == 70 and len(GROUP["base"])==23
L1 = np.log1p


def first_times(keys, times):
    """각 키의 첫 시각. 입력이 정렬되지 않은 양방향 합계에도 쓸 수 있다."""
    if len(keys) == 0:
        return np.asarray(keys), np.empty(0, np.int32)
    unique, inv = np.unique(keys, return_inverse=True)
    first = np.full(len(unique), np.iinfo(np.int32).max, np.int32)
    np.minimum.at(first,inv,times)
    return unique, first


def seen_before(keys, times, query_keys, boundary):
    unique, first = first_times(keys, times)
    if not len(unique):
        return np.zeros(len(query_keys),bool)
    pos = np.searchsorted(unique,query_keys).clip(max=len(unique)-1)
    return (unique[pos]==query_keys) & (first[pos]<boundary)


def grouped_positions(keys):
    order = np.argsort(keys,kind="stable")
    keys_sorted = keys[order]
    starts = np.r_[0,1+np.flatnonzero(keys_sorted[1:] != keys_sorted[:-1]),len(keys)]
    for a,b in zip(starts[:-1],starts[1:]):
        yield keys_sorted[a], order[a:b]


def sum_before(amount):
    return np.r_[0.,np.cumsum(amount,dtype=np.float64)]


def gap(history, query):
    hi = np.searchsorted(history,query)
    result = np.zeros(len(query))
    ok = hi>0
    result[ok] = np.log(2.0+query[ok]-history[hi[ok]-1])
    return result


def amount_z(amount, ccy, params):
    scale, med, iqr = params[ccy].T
    result = np.zeros(len(amount))
    ok = scale>0
    result[ok] = ((L1(amount[ok]/scale[ok])-med[ok])/iqr[ok]).clip(-8,8)
    return result


def pair_values(L, rows, pos, out, inc, values):
    """현재 송신 계좌의 정방향·역방향 쌍 이력을 조회한다."""
    times, dst, src = (L[k] for k in ("minute","dst","src"))
    for peer, local in grouped_positions(dst[rows[pos]]):
        ix = pos[local]
        target = rows[ix]
        t = times[target]
        day = (t//1440)*1440
        f = out[dst[out]==peer]
        h = times[f]
        previous = np.searchsorted(h,t)
        values["pair_prior_count"][ix] = L1(previous)
        values["pair_gap_minutes"][ix] = gap(h,t)
        values["pair_count_1h"][ix] = L1(previous-np.searchsorted(h,t-60))
        values["pair_age_at_day_start"][ix] = gap(h,day)
        values["reverse_history_count"][ix] = L1(np.searchsorted(times[inc[src[inc]==peer]],day))
        for c in np.unique(L["pc"][target]):
            use = L["pc"][target]==c
            prior = f[L["pc"][f]==c]
            values["pair_amount_seen_before_day"][ix[use]] = seen_before(L["paid"][prior],times[prior],L["paid"][target[use]],day[use])


def role_values(L, rows, ix, role, out, inc, values, params):
    times = L["minute"]
    target = rows[ix]
    t = times[target]
    day = (t//1440)*1440
    sender = role=="src"
    h, other = (out, inc) if sender else (inc,out)
    ccol, amount, ocol, oamount = ("pc","paid","rc","received") if sender else ("rc","received","pc","paid")
    ht = times[h]
    peers = L["dst" if sender else "src"][h]
    hi = np.searchsorted(ht,t)
    n_hour = hi-np.searchsorted(ht,t-60)
    heading = "sender" if sender else "receiver"
    values[heading+"_count_1h"][ix] = L1(n_hour)
    values[heading+"_gap_minutes"][ix] = gap(ht,t)
    nonself = ht[L["src"][h]!=L["dst"][h]]
    n_min = np.searchsorted(nonself,t,side="right")-np.searchsorted(nonself,t)
    values["minute_"+heading+"_vs_prior_hour"][ix] = L1(60*n_min) - L1(n_hour)
    if sender:
        values["src_out_1d"][ix] = L1(hi-np.searchsorted(ht,t-1440))
    _, first = first_times(peers.astype(np.int64)*256+ht//1440,ht)
    first.sort()
    name = "src_uniq_dst_1d" if sender else "dst_uniq_src_1d"
    values[name][ix] = L1(np.searchsorted(first,t)-np.searchsorted(first,t-1440))
    for c in np.unique(L[ccol][target]):
        take = L[ccol][target]==c
        q = ix[take]
        when = day[take]
        amounts = L[amount][target[take]]
        hist = h[L[ccol][h]==c]
        opposite = other[L[ocol][other]==c]
        tm, ot = times[hist], times[opposite]
        lo = np.searchsorted(tm,when)
        end = np.searchsorted(tm,when+1440)
        span = np.maximum(1, (when//1440 - (tm[0]//1440 if len(tm) else 0)))
        values[role+"_day_ccy_rate_vs_prior"][q] = L1(end-lo)-L1(lo/span)
        accum = sum_before(L[amount][hist])
        avg = np.divide(accum[lo],lo,out=np.zeros(len(q)),where=lo>0)
        values[role+"_prior_ccy_amount_vs_mean"][q] = L1(np.divide(amounts,avg,out=np.zeros(len(q)),where=avg>0))
        values[role+"_prior_ccy_amount_seen"][q] = seen_before(L[amount][hist],tm,amounts,when)
        other_acc = sum_before(L[oamount][opposite])
        ot_lo, ot_hi = np.searchsorted(ot,when), np.searchsorted(ot,when+1440)
        av, bv = accum[end]-accum[lo], other_acc[ot_hi]-other_acc[ot_lo]
        mx = np.maximum(av,bv)
        values[role+"_day_ccy_flow_balance"][q] = np.divide(np.minimum(av,bv),mx,out=np.zeros(len(q)),where=mx>0)
        if sender:
            for j,qrow in enumerate(q):
                same_day = opposite[ot_lo[j]:ot_hi[j]]
                values["src_day_ccy_log_matching_in_amount"][qrow] = L1(np.count_nonzero(L[oamount][same_day]==amounts[j]))


def account_values(L, rows, values, params, kyc, owners, index):
    src, dst, times = (L[k] for k in ("src","dst","minute"))
    s, d, n = src[rows], dst[rows], len(rows)
    keys, hist_rows = index
    for num,(a,pos) in enumerate(grouped_positions(np.r_[s,d])):
        lower, upper = np.searchsorted(keys,[int(a)<<E.SH,(int(a)+1)<<E.SH])
        hist = hist_rows[lower:upper]
        out, inc = hist[src[hist]==a], hist[dst[hist]==a]
        ot, it = times[out], times[inc]
        op, ot_first = first_times(dst[out],ot)
        ip, it_first = first_times(src[inc],it)
        common, oi, ii = np.intersect1d(op,ip,return_indices=True)
        mutual = np.sort(np.maximum(ot_first[oi],it_first[ii])[common!=a])
        _, cfirst = first_times(np.r_[L["pc"][out],L["rc"][inc]],np.r_[ot,it])
        self_t = ot[dst[out]==a]
        z = amount_z(L["paid"][out],L["pc"][out],params)
        zsum, zext = sum_before(z), sum_before(abs(z)>=3)
        firsts = { "log_out_count":ot, "log_in_count":it, "log_out_neighbors":np.sort(ot_first),
                   "log_in_neighbors":np.sort(it_first), "log_active_days":np.unique(times[hist]//1440)*1440,
                   "log_self_count":self_t, "log_reciprocal_neighbors":mutual, "log_currency_count":np.sort(cfirst)}
        for role, ix in [("src",pos[pos<n]),("dst",pos[pos>=n]-n)]:
            if not len(ix):
                continue
            qday = times[rows[ix]]//1440*1440
            for name, ary in firsts.items():
                values[role+"_"+name][ix] = L1(np.searchsorted(ary,qday))
            hi = np.searchsorted(ot,qday)
            values[role+"_mean_paid_currency_z"][ix] = np.divide(zsum[hi],hi,out=np.zeros(len(ix)),where=hi>0)
            values[role+"_paid_outlier_fraction"][ix] = np.divide(zext[hi],hi,out=np.zeros(len(ix)),where=hi>0)
            role_values(L,rows,ix,role,out,inc,values,params)
            if role=="src":
                pair_values(L,rows,ix,out,inc,values)
        if (num+1)%10000==0:
            print("거래·계좌 이력",num+1,"계좌",flush=True)


def owner_values(L, rows, values, owner):
    # 필요한 소유주의 계좌를 모두 포함한다. 다른 계좌에서 발생한 거래도 소유주 통계에 들어간다.
    src,dst,times = (L[k] for k in ("src","dst","minute"))
    n=len(rows)
    sowner, downer = owner[src[rows]],owner[dst[rows]]
    want=np.zeros(int(owner.max())+1,bool)
    want[sowner]=want[downer]=True
    def role_index(acct):
        # 필요한 소유주만 모아서 행의 시간 순서를 유지한다.
        pieces=[]
        for j in range(0,len(acct),2_000_000):
            picked=np.flatnonzero(want[owner[acct[j:j+2_000_000]]]).astype(np.int32)
            pieces.append(picked+j)
        picked=np.concatenate(pieces)
        own = owner[acct[picked]]
        order=np.argsort(own,kind="stable")
        counts=np.bincount(own,minlength=len(want))
        return picked[order],np.r_[0,np.cumsum(counts)]
    out,oo=role_index(src)
    inc,io=role_index(dst)
    for ent,loc in grouped_positions(np.r_[sowner,downer]):
        a, b = out[oo[ent]:oo[ent+1]],inc[io[ent]:io[ent+1]]
        _, acc = first_times(np.r_[src[a],dst[b]],np.r_[times[a],times[b]])
        _, oo_first = first_times(owner[dst[a]],times[a])
        _, ii_first = first_times(owner[src[b]],times[b])
        profiles = tuple(map(np.sort,(acc,oo_first,ii_first)))
        for role,ix in [("src",loc[loc<n]),("dst",loc[loc>=n]-n)]:
            bounds = times[rows[ix]]//1440*1440
            for name, first in zip(OWNER,profiles):
                values[role+"_"+name][ix]=L1(np.searchsorted(first,bounds))


def feature_frame(L, rows, params, kyc_path):
    kyc=pd.read_parquet(kyc_path,columns=["node_id","entity_id","entity_type","country"]).sort_values("node_id")
    assert np.array_equal(kyc.node_id,np.arange(len(kyc))) and kyc.entity_id.notna().all()
    owner=pd.factorize(kyc.entity_id)[0].astype(np.int32)
    countries=pd.factorize(kyc.country)[0]
    kinds=kyc.entity_type.to_numpy()
    s,d,t=(L[k][rows] for k in ("src","dst","minute"))
    cols={n:np.full(len(rows),np.nan,np.float32) for n in NAMES}
    for role,ac in [("src",s),("dst",d)]:
        for k in TYPES_KYC:
            cols[f"{role}_type_{k.replace(' ','_')}"][:]=kinds[ac]==k
    known=(countries[s]>=0)&(countries[d]>=0)
    cols["both_countries_known"][:]=known
    cols["same_known_country"][:]=known & (countries[s]==countries[d])
    cols["same_currency"][:]=L["pc"][rows]==L["rc"][rows]
    cols["is_self_transfer"][:]=s==d
    cols["paid_currency_z"][:]=amount_z(L["paid"][rows],L["pc"][rows],params)
    phase=t.astype(np.float64)%1440*2*np.pi/1440
    cols["hour_sin"][:]=np.sin(phase)
    cols["hour_cos"][:]=np.cos(phase)
    cols["weekday"][:]=(t//1440)%7  # 2022-08-01 was Monday.
    mask=np.zeros(len(kyc),bool)
    mask[s]=mask[d]=True
    index=E.build_index(L["src"],L["dst"],L["minute"],mask)
    account_values(L,rows,cols,params,kyc,owner,index)
    del index
    owner_values(L,rows,cols,owner)
    frame=pd.DataFrame(cols,index=pd.Index(L["edge_id"][rows],name="edge_id"))
    assert np.isfinite(frame.to_numpy()).all(), frame.isna().sum().loc[lambda x:x>0]
    assert frame.index.is_unique
    return frame
