"""서비스 Alert와 마감 전 원장에서 Extra Trees용 326개 피처를 만들고 유형을 예측한다."""
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.compute as pc
import pyarrow.parquet as pq

from pipeline.config import CURRENCIES, FORMATS, ORIGIN
from pipeline.context_features import core_features, ledger_context
from pipeline.edges import account_index, candidates, core_rows, pair_features
from pipeline.flows import evidence
from pipeline.structure import core_structure
from pipeline.transaction_features import NAMES, feature_frame

ROOT = Path(__file__).resolve().parent


def ordinal(column, names):
    codes = pc.index_in(column, value_set=pa.array(names))
    if codes.null_count:
        raise ValueError("Unknown or missing category in the ledger")
    return codes.to_numpy().astype(np.int8)


def read_history(path, cutoff):
    keys = ["edge_id", "src", "dst", "ts", "paid", "received", "payment_currency", "receiving_currency", "payment_format"]
    table = pq.read_table(path, columns=keys, filters=[("ts", "<", cutoff.to_pydatetime())])
    if not len(table):
        raise ValueError("No transactions before the Alert cutoff")
    if any(table[name].null_count for name in keys):
        raise ValueError("A required transaction field contains a null")
    raw = {}
    for key in ("edge_id", "src", "dst"):
        values = table[key].to_numpy()
        if values.min() < 0 or values.max() > np.iinfo(np.int32).max:
            raise ValueError(f"{key} exceeds the supported nonnegative int32 range")
        raw[key] = values.astype(np.int32)
    times = table["ts"].to_numpy()
    raw["minute"] = ((times - ORIGIN.to_datetime64()) / np.timedelta64(1, "m")).astype(np.int32)
    if np.any(np.diff(raw["edge_id"]) <= 0) or np.any(np.diff(raw["minute"]) < 0):
        raise ValueError("Ledger must be in increasing edge_id and chronological order")
    for key in ("paid", "received"):
        raw[key] = table[key].to_numpy().astype(np.float64, copy=False)
        if not np.isfinite(raw[key]).all() or np.any(raw[key] < 0):
            raise ValueError(f"Invalid transaction amounts in {key}")
    raw["pc"] = ordinal(table["payment_currency"], CURRENCIES)
    raw["rc"] = ordinal(table["receiving_currency"], CURRENCIES)
    return raw, ordinal(table["payment_format"], FORMATS)


def alert_frame(ledger, batch, columns, *, history=None):
    cutoff = pd.Timestamp(batch["cutoff"])
    if cutoff != cutoff.normalize() or cutoff.tzinfo is not None:
        raise ValueError("This model uses a local day-end snapshot, e.g. 2022-09-05 00:00:00")
    cut = int((cutoff - ORIGIN) // pd.Timedelta(minutes=1))
    if not 0 < cut < (1 << 18):
        raise ValueError("The frozen ledger index uses minutes from 2022-08-01 in 18 bits")
    day = str((cutoff - pd.Timedelta(days=1)).date())
    alerts = batch["alerts"]
    ids = [a["alert"] for a in alerts]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate Alert ID")
    if not alerts:
        return pd.DataFrame(columns=["date", "alert", *columns])
    for a in alerts:
        if not a["core"] or a["seed"] not in a["core"] or len(a["core"]) != len(set(a["core"])):
            raise ValueError(f"Invalid seed or core in Alert {a['alert']}")
    cores = [[a["seed"], *(e for e in a["core"] if e != a["seed"])] for a in alerts]
    raw, formats = history if history is not None else read_history(ledger / "transactions.parquet", cutoff)
    if raw["minute"][0] < 0 or raw["minute"][-1] >= cut:
        raise ValueError("Ledger timestamps fall outside the supported history window")
    for members in cores:
        pos = np.searchsorted(raw["edge_id"], members)
        if np.any(pos == len(raw["edge_id"])) or not np.array_equal(raw["edge_id"][pos], members):
            raise ValueError("An Alert member is absent from the pre-cutoff ledger")
    positions = [core_rows(raw, core) for core in cores]
    unique = np.unique(np.concatenate(positions))
    rates = pd.read_csv(ROOT / "models/currency_calibration.csv", index_col=0, float_precision="round_trip").loc[CURRENCIES].to_numpy()
    per_tx = feature_frame(raw, unique, rates, ledger / "kyc.parquet")
    account_history = account_index(raw, cores)
    ranker = lgb.Booster(model_file=str(ROOT / "models/membership.txt"))
    records = []
    for rows in positions:
        block = per_tx.to_numpy()[per_tx.index.get_indexer(raw["edge_id"][rows])]
        summary = {}
        for name, values in zip(("mean", "min", "max", "sd", "seed"),
                                (block.mean(0), block.min(0), block.max(0), block.std(0), block[0])):
            summary.update(zip((name + "__" + n for n in NAMES), values))
        summary.update(core_structure(raw, rows))
        summary.update({"graph_" + k: v for k, v in core_features(raw, rows).items()})
        summary.update(ledger_context(raw, account_history, rows, cut))
        near = candidates(raw, account_history, rows, cut)
        if len(near):
            pairs = pair_features(raw, formats, rows, near, cut)
            if list(pairs.columns) != ranker.feature_name():
                raise ValueError("Membership model feature order mismatch")
            weights = ranker.predict(pairs, num_threads=1)
        else:
            weights = np.empty(0)
        ranked, _, _ = evidence(raw, formats, rows, near, weights)
        summary.update(ranked)
        records.append([summary[name] for name in columns])
    frame = pd.DataFrame(records, columns=columns)
    frame.insert(0, "alert", ids)
    frame.insert(0, "date", day)
    return frame
