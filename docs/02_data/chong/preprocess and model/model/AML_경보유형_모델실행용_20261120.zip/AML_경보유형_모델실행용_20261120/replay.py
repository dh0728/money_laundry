"""Generate daily Alert versions, carrying the published scores and open Alert state forward."""
import hashlib
import json
from collections import Counter
from dataclasses import replace

import numpy as np
import pandas as pd
import pyarrow as pa
import torch

import service_inputs as source


def evidence(seeds, links, context, witnesses):
    from alerts.alert_lifecycle import Evidence
    seed = frozenset(map(int, seeds))
    link = frozenset(map(int, links)) - seed
    ctx = frozenset(map(int, context)) - seed - link
    proof = tuple(sorted(set(witnesses), key=lambda w: (w.kind, w.tx_ids)))
    key = (sorted(seed), sorted(link), sorted(ctx), [(w.kind, w.tx_ids) for w in proof])
    return Evidence(hashlib.sha256(json.dumps(key).encode()).hexdigest(), seed, link, ctx, proof)


def reports(ledger, history_start, first_report, last_report):
    from alerts.alert_lifecycle import CaseSnapshot, build_case_plans
    from alerts.block_graph import BlockPolicy, build_block_graphs
    from alerts.flow_graph import FlowIndex
    from alerts.seed_promotion import promote
    from models.multi_fraudgt_hgb.materials import CURRENCY_NAMES
    import alert_policy as spec
    policy = BlockPolicy()
    torch.set_num_threads(2)
    pa.set_cpu_count(2)
    pa.set_io_thread_count(2)
    iso = {name: code for code, name in CURRENCY_NAMES.items()}
    state, probabilities = {}, {}
    next_id = 1
    start = pd.Timestamp(history_start)
    end = pd.Timestamp(last_report) + pd.Timedelta(days=1)
    tx, accounts = source.read_transactions(ledger, end, history=start)
    if tx.empty:
        raise ValueError("지정한 원장에 재생 기간의 거래가 없습니다.")
    for day in pd.date_range(first_report, last_report):
        cutoff = day + pd.Timedelta(days=1)
        partial = tx[tx.ts < cutoff]
        if partial.empty or partial.ts.max() < day:
            empty = pd.DataFrame({"tx_id": pd.Series(dtype="int64"), "p_laundering": pd.Series(dtype=float)})
            yield {"date": str(day.date()), "cutoff": str(cutoff), "alerts": []}, empty
            continue
        assert partial.ts.max() < cutoff and cutoff - start < pd.Timedelta(days=46)
        nodes = np.union1d(partial.src, partial.dst)
        history_accounts = accounts[accounts.node_id.isin(nodes)]
        daily, _ = source.score(partial, history_accounts, target_start=day)
        assert not set(daily.tx_id) & probabilities.keys()
        probabilities.update(zip(daily.tx_id.astype(int), daily.p_laundering))
        edges = source.alert_edges(partial, iso)
        high = {k for k, v in probabilities.items() if v >= spec.RECOMMENDED_THRESHOLD}
        extra = promote(edges, probabilities, high, spec.ALERT_SEED_LOW, spec.ALERT_CHAIN_FLOOR)
        positive = high | {int(edges.tx_ids[i]) for i in extra}
        pins = []
        for snap in state.values():
            if snap.merged_into_alert_id is not None:
                continue
            ev = snap.evidence
            owned = sorted(ev.seed_ids & positive)
            if owned:
                pins.append((owned, sorted(ev.core_ids), sorted(ev.member_ids),
                             [(w.kind,w.tx_ids) for w in ev.witnesses], False))
        graphs = build_block_graphs(FlowIndex(edges), positive, policy, seed_groups=pins)
        current = [evidence(g.seed_ids,g.connection_ids,g.context_ids,g.witnesses) for g in graphs.graphs]
        planned = build_case_plans(state.values(), current, policy_version=policy.version)
        records, counts = [], Counter()
        for plan in planned.plans:
            counts[plan.action.value] += 1
            if plan.action.value == "NOOP":
                continue
            assert plan.action.value in ("NEW", "UPDATE", "MERGE")
            parts = [state[k].evidence for k in plan.case_ids] + [current[i] for i in plan.graph_ids]
            ev = evidence(*(set().union(*(getattr(e, attr) for e in parts)) for attr in
                            ("seed_ids", "connection_ids", "context_ids", "witnesses")))
            if plan.action.value == "NEW":
                key = next_id
                next_id += 1
                state[key] = CaseSnapshot(key,1,0,1,cutoff.tz_localize("Asia/Seoul").to_pydatetime(),
                                          "OPEN",None,ev,policy_version=policy.version)
            else:
                key = plan.target_alert_id
                old = state[key]
                if plan.action.value == "UPDATE" and (old.evidence.seed_ids,old.evidence.connection_ids,old.evidence.context_ids) == (ev.seed_ids,ev.connection_ids,ev.context_ids):
                    counts["membership_unchanged"] += 1
                    continue
                state[key] = replace(old, published_version=old.published_version+1, revision=old.revision+1,evidence=ev)
                for alias in set(plan.case_ids) - {key}:
                    state[alias] = replace(state[alias],merged_into_alert_id=key)
            records.append(dict(alert=key,version=state[key].published_version,action=plan.action.value,
                            seed=max(ev.seed_ids),core=sorted(ev.core_ids),seeds=sorted(ev.seed_ids)))
        result = dict(date=str(day.date()),cutoff=str(cutoff),loaded=len(partial),targets=len(daily),
                      high=len(high),promoted=len(positive-high),actions=dict(counts),alerts=records)
        yield result, daily
