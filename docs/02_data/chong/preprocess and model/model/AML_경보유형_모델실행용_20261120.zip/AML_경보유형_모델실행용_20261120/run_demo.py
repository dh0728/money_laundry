"""보유한 HI-Large 원장에서 일별 경보를 재생하고 최초 발행 경보의 유형을 예측한다."""
import argparse
import json
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parent
TYPE_DIR = ROOT / "alert_type"
BASE_DIR = ROOT / "baseline326"
HISTORY_START = "2022-11-06"
FIRST_REPORT = "2022-11-12"
FIRST_PREDICTION = "2022-11-25"
LAST_REPORT = "2022-12-12"


def ledger_path(path):
    folder = path.expanduser().resolve()
    for candidate in (folder, folder / "HI-Large"):
        if all((candidate / name).is_file() for name in ("transactions.parquet", "kyc.parquet")):
            return candidate
    raise ValueError(f"{folder} 또는 그 아래 HI-Large 폴더에 transactions.parquet와 kyc.parquet가 필요합니다.")


def run(ledger, out):
    sys.path[:0] = [str(TYPE_DIR), str(BASE_DIR), str(ROOT / "service")]
    os.environ["MULTI_FRAUDGT_HGB_DEVICE"] = "cpu"
    os.environ["MULTI_FRAUDGT_HGB_THREADS"] = "2"

    import joblib
    import pandas as pd
    import baseline
    from classify import alert_features, predict_features
    from fuse_service import TYPES, mix
    from replay import reports
    from service_inputs import transaction_types

    comparator = joblib.load(BASE_DIR / "models/original.joblib")
    schema = json.loads((BASE_DIR / "schema.json").read_text(encoding="utf-8"))
    if list(comparator["columns"]) != schema["columns"] or list(comparator["labels"]) != TYPES:
        raise ValueError("326개 특성 모델의 열 또는 유형 순서가 스키마와 다릅니다.")
    forests = {"first": joblib.load(TYPE_DIR / "alert_model.joblib"),
               "followup": joblib.load(TYPE_DIR / "followup.joblib")}
    results = {key: [] for key in ("baseline_326", "first", "followup", "combined")}
    daily_type_scores = []
    for report, binary in reports(ledger, HISTORY_START, FIRST_REPORT, LAST_REPORT):
        day = report["date"]
        scores = transaction_types(ledger, HISTORY_START, report["cutoff"], binary)
        if len(scores):
            daily_type_scores.append(scores)
        new = [alert for alert in report["alerts"] if alert["action"] == "NEW"]
        print(f"{day}   거래 {len(binary):,}건   최초 발행 경보 {len(new):,}건", flush=True)
        if day < FIRST_PREDICTION or not new:
            continue

        batch = {**report, "alerts": new}
        results["baseline_326"].append(baseline.predict(ledger, batch, HISTORY_START, comparator))
        items, features = alert_features(ledger / "transactions.parquet", batch, HISTORY_START)
        for name, model in forests.items():
            predicted = predict_features(items, features, model)
            results[name].append(predicted.assign(date=day))
        available_scores = pd.concat(daily_type_scores, ignore_index=True) if daily_type_scores else scores
        mixed = mix(results["followup"][-1], items, available_scores)
        results["combined"].append(mixed.assign(date=day))

    out.mkdir(parents=True, exist_ok=True)
    counts = {}
    with TemporaryDirectory(prefix=".aml-", dir=out) as temp:
        staged = Path(temp)
        for name, blocks in results.items():
            columns = ["alert", "version", "type", *TYPES, "date"]
            if name == "combined":
                columns.insert(3, "scored_members")
            elif name == "baseline_326":
                columns = ["date", "alert", "version", "type", *TYPES]
            frame = pd.concat(blocks, ignore_index=True) if blocks else pd.DataFrame(columns=columns)
            frame = frame[columns].sort_values(["date", "alert", "version"])
            frame.to_csv(staged / f"{name}.csv", index=False)
            counts[name] = len(frame)
        for name in results:
            (staged / f"{name}.csv").replace(out / f"{name}.csv")
    print(f"모델별 예측 {counts['baseline_326']:,}건을 {out}에 저장했습니다.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=ROOT / "parquets",
                        help="보유한 HI-Large 폴더 또는 그 상위 parquets 폴더")
    parser.add_argument("--out", type=Path, default=ROOT / "output", help="모델별 예측 CSV를 저장할 폴더")
    args = parser.parse_args()
    try:
        ledger = ledger_path(args.data_dir)
    except ValueError as error:
        parser.error(str(error))
    run(ledger, args.out.expanduser().resolve())


if __name__ == "__main__":
    main()
