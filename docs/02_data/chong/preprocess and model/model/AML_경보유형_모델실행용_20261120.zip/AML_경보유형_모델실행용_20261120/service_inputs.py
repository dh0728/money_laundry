"""Read the original ledger and score each frozen service report."""
from decimal import Decimal, ROUND_HALF_UP

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

# V1__initial_schema.sql, fx_rates_usd_v1 at e803583.
UNITS_PER_USD = {"AUD":"1.41280000","BTC":"0.00008416","BRL":"5.64649997","CAD":"1.31930001","EUR":"0.85340000","MXN":"21.14310180","RUB":"77.80399773","INR":"73.44397914","SAR":"3.75109996","ILS":"3.37699997","CHF":"0.91500000","GBP":"0.77420000","USD":"1.00000000","JPY":"105.39995594","CNY":"6.69760020"}


def read_transactions(data, end, history):
    columns = ["edge_id","src","dst","ts","paid","received","payment_format","payment_currency","receiving_currency"]
    bounds = [("ts",">=",history.to_pydatetime()), ("ts","<",end.to_pydatetime())]
    tx = pq.read_table(data/"transactions.parquet", columns=columns, filters=bounds).to_pandas()
    tx = tx.sort_values("edge_id").reset_index(drop=True)
    assert tx.edge_id.is_unique
    nodes = np.union1d(tx.src, tx.dst)
    names = ["node_id","entity_id","entity_type","country"]
    kyc = pq.read_table(data/"kyc.parquet",columns=names).to_pandas()
    return tx, kyc[kyc.node_id.isin(nodes)].copy()


def score(tx, accounts, target_start):
    from models.multi_fraudgt_hgb import model, spec
    from models.multi_fraudgt_hgb.materials import CURRENCY_NAMES
    key = accounts.set_index("node_id").index.to_series().map(lambda n: f"account-{n:010d}")
    iso = {v:k for k,v in CURRENCY_NAMES.items()}
    material = pd.DataFrame({
        "tx_id":tx.edge_id, "occurred_at":tx.ts.dt.tz_localize("Asia/Seoul").dt.tz_convert("UTC"),
        "from_account_id":tx.src.map(key), "to_account_id":tx.dst.map(key),
        "amount_paid":tx.paid, "amount_received":tx.received, "payment_format":tx.payment_format,
        "payment_currency":tx.payment_currency.astype(object).map(iso),
        "receiving_currency":tx.receiving_currency.astype(object).map(iso),
    })
    assert material.notna().all().all()
    ac = accounts.assign(account_id=accounts.node_id.map(key)).rename(columns={"entity_id":"owner_id"})
    targets = tx.loc[tx.ts.ge(target_start), "edge_id"]
    inputs = {"transactions":pa.Table.from_pandas(material,preserve_index=False),
              "accounts":pa.Table.from_pandas(ac[["account_id","owner_id","entity_type","country"]],preserve_index=False),
              "targets":pa.table({"tx_id":targets.to_numpy()})}
    result = model.calculate_inputs(inputs,"binary",model_version=spec.MODEL_VERSION,
                                    feature_version=spec.FEATURE_VERSION).to_pandas()
    assert result.tx_id.is_unique and set(result.tx_id)==set(targets) and result.p_laundering.between(0,1).all()
    return result, iso


def alert_edges(tx, iso):
    from alerts.flow_graph import EdgeTable
    table = EdgeTable()
    rates = {name:Decimal(UNITS_PER_USD[code]) for name,code in iso.items()}
    for r in tx.itertuples():
        usd = (Decimal(str(r.paid)) / rates[r.payment_currency]).quantize(Decimal("0.000001"), rounding=ROUND_HALF_UP)
        table.append(r.edge_id, int(r.ts.value//1000),r.src+1,r.dst+1,int(usd*1_000_000))
    return table


def transaction_types(ledger, history_start, cutoff, binary_scores):
    """Calculate SALT_R on the transactions eligible in this published report."""
    import pyarrow.compute as pc
    from alert_policy import RECOMMENDED_THRESHOLD
    from common.score_contract import check_scores
    from models.salt_r import model, spec

    eligible = binary_scores.loc[
        binary_scores.p_laundering >= RECOMMENDED_THRESHOLD, ["tx_id", "p_laundering"]
    ].sort_values("tx_id")
    if eligible.empty:
        return eligible.assign(**{f"p_{i}": np.empty(0, dtype=float) for i in range(9)})
    lower = pd.Timestamp(history_start).to_pydatetime()
    upper = pd.Timestamp(cutoff).to_pydatetime()
    table = pq.read_table(
        ledger / "transactions.parquet",
        columns=["edge_id", "ts", "src", "dst", "paid"],
        filters=[("ts", ">=", lower), ("ts", "<", upper)],
    )
    if pc.min(table["ts"]).as_py() < lower or pc.max(table["ts"]).as_py() >= upper:
        raise ValueError("SALT_R 이력 시점이 경보의 원장 범위를 벗어났습니다.")
    history = pa.table({
        "tx_id": table["edge_id"], "occurred_at": pc.assume_timezone(table["ts"], "Asia/Seoul"),
        "from_account_id": table["src"], "to_account_id": table["dst"], "amount_paid": table["paid"],
    })
    result = model.calculate_inputs(
        {"transactions": history, "targets": pa.table({"tx_id": eligible.tx_id.to_numpy()})},
        "type", model_version=spec.MODEL_VERSION, feature_version=spec.FEATURE_VERSION,
    )
    check_scores(result, eligible.tx_id.to_list(), "type")
    return eligible.merge(result.to_pandas(), on="tx_id", validate="one_to_one")
