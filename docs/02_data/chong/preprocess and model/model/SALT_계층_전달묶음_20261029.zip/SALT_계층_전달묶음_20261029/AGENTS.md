# AGENTS.md — SALT-GNN 계층(대분류 → 소분류) 전달 묶음 · AI 에이전트용 안내

> 사람용 설명과 결과 표는 `README.md` 에 있습니다. 이 파일은 AI 코딩 에이전트(Claude Code · Codex · Cursor 등)가 이 폴더를 **바로 파악하고 안전하게 돌리도록** 쓴 안내입니다. 2026-10-29 · 손은총 님 모델 · Claude Code 작성. README · 노트북 머리말과 다르면 이 파일이 맞습니다.

**English TL;DR** — Self-contained Jupyter notebook (`SALT_계층_한파일.ipynb`) that trains/evaluates a hierarchical SALT-GNN classifier for 9 money-laundering typology classes on IBM AML HI-Large (stage 2 only: input rows are already-known laundering transactions). Run it from this folder. Edit only the config cell `nb.cells[1]` (the first code cell). Never point `OUT_DIR` inside `학습된_모델/` — copy a seed folder first. Any prediction on 평가 (val) rows — `DO_VAL = True` or calling `predict` on them — consumes the dev validation set once: ask the human first. Test data is not included. Do not modify `데이터/` or `학습된_모델/`.

---

## 1. 한눈에

- **과제:** 세탁으로 이미 확인된 거래 한 건 → 9칸(8유형 + 무패턴) 중 하나로 분류. 정상 거래는 들어 있지 않습니다(1단계 탐지가 완벽하다고 친 2단계).
- **구조(계층 · 차례 판별):** 대분류 모델(5칸) 1등 묶음 → 그 묶음의 이진 모델(2칸)이 두 유형 중 하나(확률 ≥ 0.5 면 뒤 유형) · 무패턴 묶음이면 그대로 무패턴. 곁으로 확률 곱(묶음 확률 × 이진 확률 → 9칸 1등)도 계산.
- **모델 5개:** `대분류` · `fan-out_family` · `fan-in_family` · `bipartite_family` · `cycle_family` — 모두 같은 SALT2 구조, 출력 칸 수(5 · 2)만 다름.
- **학습된 모델은 씨앗 42 · 43 · 44 세 벌**(씨앗마다 모델 5개)이 들어 있습니다.
- **진입점은 노트북 하나:** `SALT_계층_한파일.ipynb`. 프로젝트의 다른 파이썬 모듈을 import 하지 않습니다(필요한 함수는 원본에서 글자 그대로 옮겨 노트북 안에 있음).
- **작업 폴더 = 이 폴더.** 설정 셀의 경로가 모두 이 폴더 기준 상대 경로입니다.
- **결정적 계산:** 같은 GPU · 라이브러리 버전 · 씨앗이면 결과가 비트까지 같습니다.
- **확인한 범위(2026-10-29 · 정직하게):**
  - 이 묶음을 푼 상태에서: 그래프 값 · 씨앗 42 · 43 · 44 모델 가중치 · 그 모델이 낸 고르기 구간 확률이 서버와 비트까지 같음(`DO_TRAIN = False` · `DO_VAL = False` 로만 실행).
  - 노트북으로 처음부터 학습한 재현은 **서버 경로에서 씨앗 42 만** 확인(가중치 비트 같음). 씨앗 43 · 44 는 같은 식의 별도 스크립트로 학습.
  - 노트북의 val 채점 경로(셀 17 → 19)는 val 횟수를 아끼려고 **노트북으로는 돌려 보지 않았습니다.** 기대값은 서버 평가 스크립트의 val 결과이고, 채점 함수는 그 스크립트와 글자 그대로 같거나 같은 식임을 코드 대조로 확인했습니다.

## 2. 파일 지도

| 경로 | 무엇 | 언제 필요 |
|---|---|---|
| `SALT_계층_한파일.ipynb` | 그래프 불러오기 → 학습 → val 평가 전부(셀 21개 · Jupyter/IPython 전용) | 항상 |
| `데이터/graph_slim.npz.xz` | 대상 거래마다 1홉 부분 그래프 · 노드 14열 · 정답 · 구간(lzma 로 압축한 npz) | 항상(`BUILD_GRAPH = False`) |
| `데이터/edge11_slim.npz.xz` | 1홉 엣지 11열 · 대상 거래 11열(같은 엣지 줄은 한 번만 적은 꼴) | 항상(`BUILD_GRAPH = False`) |
| `데이터/행나눔.parquet` | 세탁 거래 147,109행의 구간(학습 · 고르기 · 평가 · 뺌) · 뺀 까닭 | `BUILD_GRAPH = True` 일 때만(노트북은 그때만 읽음) |
| `학습된_모델/씨앗<42·43·44>/salt_best_<모델>.pt` | 학습된 가중치(state_dict) · 씨앗마다 5개 | 학습 없이 쓸 때(복사해서) |
| `학습된_모델/씨앗<42·43·44>/salt_학습.json` | 모델별 고른 epoch · 고르기 점수 · 학습 · 고르기 행 수 · 정규화 기준값 · δ | 학습 없이 쓸 때(노트북은 `'모델'` 키만 읽음) |
| `학습된_모델/씨앗<42·43·44>/salt_hist_<모델>.csv` | epoch 마다 학습 손실 · 고르기 점수(기록용) | 실행에는 필요 없음 |
| `README.md` | 사람용 설명 · 이 서버 결과 표 | — |
| `목록_sha256.txt` | 파일별 sha256 | 받은 뒤 `sha256sum -c 목록_sha256.txt`(macOS `shasum -a 256 -c`) |
| `CLAUDE.md` | 이 파일을 불러오는 한 줄(Claude Code 자동 읽기용) | — |

들어 있지 않은 것:
- **라벨 복사본 CSV**(그래프를 새로 만들 때만 필요 · 사람에게 받을 것): `COPY_DIR` 안에 `HI-Large_Trans_family_train.csv`(2022-08-01 ~ 09-27 · 106,365,236줄) · `HI-Large_Trans_family_val.csv`(09-28 ~ 10-14 · 33,651,739줄)가 있어야 하고, 노트북이 줄 수를 assert 합니다. 열 13개 = 원본 IBM AML `HI-Large_Trans.csv` 11열 + `Pattern Type` + `Pattern Family`(합계 약 13.6 GB). 서버에서 만든 코드: `/workspace/Final_preprocess/HI-Large_EDA/대분류라벨_복사본_20261028/code/make_labels_copy_v2.py`.
- test 기간 자료(2022-10-15 ~) · 원본 학습 · 평가 스크립트(노트북에 같은 코드가 들어 있음) · 9클래스 모델(따로 묶음 `SALT_9클래스_전달묶음_20261029`).

## 3. 돌리는 법

### 3-1. 환경

- 확인한 판: GPU Tesla V100-SXM2-32GB(드라이버 580.126.20) · Python 3.12.3 · torch 2.10.0+cu126 · numpy 2.4.1 · pandas 3.0.3 · scikit-learn 1.8.0 · pyarrow 24.0.0 · nbformat 5.10.4 · nbconvert 7.17.1 · ipykernel 7.2.0.
- RAM(잰 값): 그래프 불러오기 + 학습 · 평가 프로세스 최고 약 2.4 GB · `BUILD_GRAPH = True` 는 최고 약 13.7 GB(같은 셀을 쓰는 9클래스 노트북으로 잼).
- GPU 메모리는 재지 않았습니다. 이 서버에서 GPU 여유 약 4.5 GB 안에서 두 씨앗 학습을 함께 돌렸습니다. CPU 로만 돌리는 경로는 시험하지 않았습니다(학습이 매우 느리고 숫자가 GPU 와 다를 수 있음).
- 노트북은 커널 이름 `python3` 로 실행됩니다. 셀 2 의 `import torch` 가 실패하면 torch 가 깔린 해석기로 커널을 만들어 쓰십시오: `python3 -m ipykernel install --user --name salt` → nbconvert 에 `--ExecutePreprocessor.kernel_name=salt`.
- 셀 2 는 `torch.set_num_threads(THREADS)`(기본 4)를 겁니다. `OMP_NUM_THREADS` 등 환경변수는 이미 정해져 있지 않을 때만 `THREADS` 로 맞춥니다. `CUBLAS_WORKSPACE_CONFIG` · `torch.use_deterministic_algorithms(True)` 를 켜므로 **새 커널에서 위에서부터 차례로** 실행하십시오.
- 노트북 코드는 `display()`(IPython 내장)를 씁니다. 셀 코드를 .py 로 옮겨 돌리면 맨 앞에 `from IPython.display import display` 를 넣으십시오.

### 3-2. 모드(설정 셀 = `nb.cells[1]` · 마크다운 포함 0부터 센 셀 번호 1 · 첫 번째 코드 셀)

기본값: `BUILD_GRAPH = False` · `DO_TRAIN = True` · `DO_VAL = True` · `SEED = 42` · `OUT_DIR = './결과_s42'`.

| 하고 싶은 일 | 설정 | 걸리는 시간(이 서버 · GPU) | val 사용 |
|---|---|---|---|
| 처음부터 학습 + 평가 | 기본값 그대로 | 학습 약 12분 + 평가 1분 안쪽 | **1번** |
| 처음부터 학습만 | `DO_VAL = False` | 약 12분 | 0 |
| 학습된 모델 불러오기만(고르기 행 확률 · 점검) | 먼저 `학습된_모델/씨앗42` 를 `결과_평가만_s42` 로 복사 → `DO_TRAIN = False` · `DO_VAL = False` · `OUT_DIR = './결과_평가만_s42'` | 30초 안쪽 | 0 |
| 학습된 모델로 평가 | 위와 같되 `DO_VAL = True` | 1분 안쪽 | **1번** |
| 그래프를 원자료에서 새로 만들기 | `BUILD_GRAPH = True` · `COPY_DIR` = 라벨 복사본 폴더(2절). **그래프만 만들려면 셀 1 ~ 6 까지만 실행**(셀 6 이 `OUT_DIR` 에 `graph.npz` · `edge11.npz` 를 씀). Run All 하면 기본값대로 학습 · 평가까지 갑니다(`DO_TRAIN = False` 로 두면 셀 13 이 `OUT_DIR` 에서 모델을 찾다 FileNotFoundError) | 그래프 약 6분(+ Run All 이면 학습 12분) | 셀 6 까지만이면 0 · Run All 기본값이면 **1번** |

- **`OUT_DIR` 을 `학습된_모델/` 안으로 두지 마십시오.** 셀 13 은 `DO_TRAIN` 과 상관없이 `OUT_DIR` 에 `salt_고르기.npz` 를 쓰고, 셀 17 은 `DO_VAL` 이면 `val_*` 파일을 쓰며, `DO_TRAIN = True` 면 셀 11 · 13 이 받은 가중치 · 기록을 덮어씁니다. 늘 씨앗 폴더를 복사해 쓰십시오.
- `DO_TRAIN = False` 일 때 노트북은 `OUT_DIR` 에서 모델 5개와 `salt_학습.json` 을 읽습니다. `SEED` 는 그때 기대값 비교(셀 19)와 `val_결과.json` 의 seed 기록(셀 17)에만 쓰이므로, 복사한 씨앗 폴더와 같은 값으로 맞추십시오.
- `OUT` 은 셀 2 에서 `OUT_DIR` 로 정해집니다. 셀 2 를 실행한 뒤 `OUT_DIR` 만 바꾸면 반영되지 않습니다.

### 3-3. 머리 없이(headless) 실행 — 학습된 모델 불러오기만(val 안 씀)

이 폴더(이 파일이 있는 곳)에서 아래 파이썬을 그대로 실행합니다(운영체제 무관 · 파일로 저장해 `python3 파일.py`).

```python
import shutil, subprocess, sys
from pathlib import Path
import nbformat

SEED = 42                                    # 42 · 43 · 44
SRC, OUT = Path(f'학습된_모델/씨앗{SEED}'), Path(f'결과_평가만_s{SEED}')
if not OUT.exists():
    shutil.copytree(SRC, OUT)                # 받은 모델 폴더는 건드리지 않음
nb = nbformat.read('SALT_계층_한파일.ipynb', as_version=4)
assert nb.cells[1].source.startswith('# ═══ 설정')
nb.cells[1].source += (f"\n# ── 덮어쓰기(뒤에 쓴 값이 이김) ──\nDO_TRAIN = False\nDO_VAL = False\n"
                       f"SEED = {SEED}\nOUT_DIR = './{OUT.as_posix()}'\n")
nbformat.write(nb, f'실행용_s{SEED}.ipynb')
subprocess.run([sys.executable, '-m', 'jupyter', 'nbconvert', '--to', 'notebook', '--execute',
                '--ExecutePreprocessor.timeout=-1', '--output', f'실행결과_s{SEED}.ipynb', f'실행용_s{SEED}.ipynb'], check=True)
res = nbformat.read(f'실행결과_s{SEED}.ipynb', as_version=4)
text = ''.join(o.get('text', '') for c in res.cells if c.cell_type == 'code' for o in c.get('outputs', []))
assert 'val 예측 · 채점 한 번 끝' not in text, 'val 을 쓴 것 같습니다 — 사람에게 알리십시오'
print('끝 · val 안 씀 ·', f'실행결과_s{SEED}.ipynb')
```

- 설정을 바꿀 때는 위처럼 설정 셀 **끝에 덮어쓰는 줄을 붙이십시오.** 문자열 치환(`replace`)은 글자가 조금만 달라도 아무 말 없이 안 바뀌어 val 을 쓰게 될 수 있습니다.
- 평가까지 하려면 덮어쓰는 줄에서 `DO_VAL = True` 로 바꾸고 마지막 assert 를 지우되, **3-5 규칙 1 을 먼저 지키십시오.**

### 3-4. 잘 돌았는지 보는 법

- 출력에 오류(traceback)가 없을 것. 그래프를 새로 만들 때 셀 6 에 나오는 `RuntimeWarning: divide by zero encountered in log` · `RuntimeWarning: invalid value encountered in log` 두 경고는 정상입니다(`edge11()` 의 `np.where` 가 양쪽을 다 계산하고 그 값은 버림 · 결과에 영향 없음) — 고치지 마십시오.
- 셀 6 출력: `그래프 준비 · 대상 94,270 · 노드 2,506,930 · 엣지 8,438,741 · 학습 52,147 · 고르기 17,946 · 평가 24,177`. 셀 10 출력: `δ 2.934549`.
- **학습한 경우(`DO_TRAIN = True`):** 셀 13 표의 고른 epoch(대분류 · fan-out · fan-in · bipartite · cycle 차례)가 씨앗 42 = 23 · 15 · 29 · 31 · 15 / 43 = 43 · 10 · 40 · 17 · 90 / 44 = 39 · 6 · 51 · 25 · 95 와 같아야 합니다(같은 GPU · 판일 때). `DO_TRAIN = False` 면 이 표는 json 을 그대로 보여 줄 뿐이라 확인 수단이 아닙니다.
- **val 없이 모델 출력 확인(불러오기 모드 · 셀 13 뒤에 새 셀로):**

```python
print('대분류', mAP5(Pf_pick, yf[pi]), INFO['대분류']['고르기_점수'])
for f in PAIR:
    m = yf[pi] == f
    print(FAMS[f], average_precision_score(y9[pi][m] == PAIR[f][1], Ps_pick[m, f]), INFO[FAMS[f]]['고르기_점수'])
```
  두 숫자가 줄마다 같으면(이 서버에서는 소수점 끝까지 같음 확인) 모델과 그래프가 제대로 읽힌 것입니다.
- **평가한 경우(`DO_VAL = True`):** 끝에서 두 번째 셀 19 '5. 기대값 비교' 가 `모두 같음` 을 출력해야 합니다(같은 GPU · 판). 기대값(9칸 · 8유형 · 대분류 5칸 정밀도 / 재현율):

| 씨앗 | 9칸 | 8유형 | 대분류 5칸 |
|---|---|---|---|
| 42 | 0.5609 / 0.5438 | 0.5207 / 0.5060 | 0.7153 / 0.7005 |
| 43 | 0.5654 / 0.5282 | 0.5268 / 0.4835 | 0.7112 / 0.6909 |
| 44 | 0.5668 / 0.5308 | 0.5281 / 0.4908 | 0.7152 / 0.6927 |

  - 다른 GPU · 판에서: 학습된 모델 불러오기면 소수점 끝자리 정도만 다를 것으로 봅니다(재 보지는 않음). 다시 학습하면 고르기 점수 1 · 2등 차이가 0.0001 정도인 모델도 있어 고른 epoch 가 바뀔 수 있고, 9칸 숫자가 씨앗 차이만큼(표준편차 약 0.003 ~ 0.008) 움직일 수 있습니다 — 그때 '모두 같음' 이 아니어도 고장이 아닙니다. 같은 환경인데 다르면 노트북 채점 코드도 의심하고 사람에게 알리십시오.

### 3-5. 지킬 규칙(이 프로젝트의 평가 규칙)

1. **val 은 개발용이고 쓴 횟수를 셉니다.** 평가(`seg == '평가'` · 변수 `val`) 행에 대해 예측 · 채점하는 것은 방법과 상관없이 val 사용 1번입니다 — `DO_VAL = True` 실행, `predict` · `preds` · `evaluate_rows` 에 평가 행을 넣는 것 모두. **사람에게 묻기 전에는 하지 마십시오.** val 점수를 보며 설정을 고르는 반복(튜닝 루프)도 하지 마십시오.
2. **고르기 · 견주기는 `고르기` 구간(09-14 ~ 09-27)으로 합니다.** val 없이 점수 보기: `DO_VAL = False` 로 셀 17 까지 실행한 뒤 `R = evaluate_rows(pick, {'고르기': pick}); show(R['R'], '고르기')`. 고르기 행은 epoch 고르기에도 쓰였으므로 절대값은 낙관적입니다 — 같은 조건끼리, 씨앗 여러 개로만 견주십시오.
3. **test(2022-10-15 ~)는 이 묶음에 없습니다.** 찾거나 만들려 하지 마십시오. `행나눔.parquet` 의 `구간 == '뺌'` 52,839행(노이즈 · 정화 · `test 로 이어짐(test 로 보냄)` 17,050행)에도 `y9` · `att` 가 있지만, 학습 · 고르기 · 평가 · 집계 어디에도 쓰지 마십시오(노트북은 `BUILD_GRAPH = True` 일 때 행 수 · 유형 대조 assert 에만 씀).
4. **나눔은 날짜순입니다.** 학습 2022-08-01 ~ 09-13 · 고르기 09-14 ~ 09-27 · 평가 09-28 ~ 10-14. 무작위로 다시 나누지 마십시오(시간 누수).
5. **입력은 판정 시점보다 앞선 분의 거래만 씁니다.** 새 피처에 대상 거래와 같은 분이거나 뒤의 거래 · 정답(유형 · 시도 번호 `att`) · Patterns.txt 정보를 쓰지 마십시오. **`eid` 도 피처 · 정렬 · 같은 분 동점 처리 · 나눔에 쓰지 마십시오** — 원본 CSV 줄 번호이고 날짜순이 아니며, 같은 (계좌, 분) 안의 순서가 세탁 여부(정상 대 세탁)와 이어져 있었습니다(서버 누수 점검 F22 · AUC 0.739 · 유형 정답과의 관계는 재지 않음). 행을 잇는 열쇠로만 씁니다.
6. 이 모델 입력에는 **절대 시각 · 통화 · 결제 형식 · 소유주 · 나라 열이 없습니다**(일부러 뺌 · 열 단위로 없다는 뜻). 다만 간접 정보는 남아 있습니다:
   - 노드의 금액 평균 2열(6-3)은 통화 환산 없이 각 거래 결제 통화 단위의 금액이라, 통화마다 다른 금액 크기가 섞여 들어갑니다.
   - 2022-08-01 부터 센 누적 개수 열(노드 앞선 거래 수 · 상대 수, 엣지 `pair_prior_count` · `pair_history_count` · `reverse_history_count`)은 날짜가 지날수록 커져 시각을 간접적으로 담습니다. '시간 정보가 없다'고 단정하지 마십시오.
7. `데이터/` · `학습된_모델/` 의 파일을 고치거나 덮어쓰지 마십시오. 노트북 코드를 고치면 '원래 결과 재현' 이 아니라 새 실험입니다 — 결과를 원래 숫자와 구분해 보고하십시오.
8. 성능을 보고하거나 견줄 때는 정밀도 · 재현율을 함께, 씨앗 하나가 아니라 씨앗 3개의 평균 ± 표준편차로 말하십시오. 차이가 씨앗 표준편차보다 작으면 '개선'이라 하지 않는 것이 이 프로젝트 규칙입니다.

### 3-6. 9클래스 모델과 견주기

- 세 씨앗 비교 결과가 이미 있습니다(9절). 다시 돌리기 전에 사람에게 물으십시오.
- 다시 한다면: 9클래스 묶음(이 폴더에 없음 · 사람에게 받기)을 같은 `SEED` · `DO_VAL = True` 로 실행 → 이 노트북을 같은 `SEED` · `DO_VAL = True` · `OTHER_PRED = '<9클래스 폴더>/<그 OUT_DIR>/val_pred.npz'`(이 노트북 기준 상대 경로) 로 실행하면 셀 20 이 규칙 ①(시도 단위 부트스트랩 · 하루 빼기)로 견줍니다. **씨앗마다 val 을 2번 씁니다.** 셀 20 은 차례 판별 예측(`pred9`)만 견줍니다.

### 3-7. 새 피처를 실험하려면

- 이 묶음의 그래프에는 계산이 끝난 피처만 있고 원 거래(계좌 · 금액 · 이웃 엣지의 시각 · 엣지와 원 거래의 대응)는 없습니다. 대상 거래의 시각 `minute` 과 `eid` 는 있지만 입력으로 쓰지 마십시오(3-5 규칙 5 · 6).
- 노드 · 엣지 피처를 새로 만들려면 라벨 복사본(2절)과 `BUILD_GRAPH = True` 가 필요하고, **셀 6 의 `build_graph_from_copy()` 를 고쳐야 합니다** — 원 거래 배열(`minute` · `sid` · `did` · `lap`)과 엣지 ↔ 원 거래 대응(`e_row` · `tp`)은 그 함수 안에서만 쓰이고 `G` 에 남지 않습니다(`edge11()` 처럼 `e_row` · `tp` 로 계산해 `G` 에 넣기). 이는 3-5 규칙 7 의 '새 실험' 입니다.
- 피처를 붙일 자리: 셀 6 뒤 · 셀 10 앞에서 `G['nx']`(노드) · `G['ea']`(엣지) · `G['tx']`(대상 거래)에 열을 붙이면 셀 10 이 정규화 기준값 · δ · 열 수를 다시 잽니다.
- **`ea` 와 `tx` 는 열 수 · 차례가 같아야 합니다** — 정규화(`zn`)가 대상 거래 `tx` 도 엣지 평균 · 표준편차(`em` · `es`)로 나눕니다.
- 열 수가 바뀌면 `학습된_모델/` 은 쓸 수 없습니다(다시 학습). 3-5 규칙 2 · 5 · 6 · 8 을 지키십시오.

## 4. 노트북 구조(셀 번호는 마크다운 포함 0부터)

| 셀 | 종류 | 내용 | 정의하는 주요 이름 |
|---|---|---|---|
| 0 | md | 머리말 · 원본 코드 출처(sha1) | — |
| 1 | code | **설정**(여기만 고침) | `COPY_DIR` `ROWS_PATH` `BUILD_GRAPH` `GRAPH_NPZ` `EDGE11_NPZ` `DO_TRAIN` `DO_VAL` `SEED` `OUT_DIR` `OTHER_PRED` `THREADS` |
| 2 | code | 0. 준비: 스레드 · 결정적 계산 · 상수 | `dev` `OUT` `CN9` `FAMS` `G5` `PAIR` `CFG` `EPOCHS` `BATCH` `CLIP` `NB` `BSEED` `log()` |
| 3 | md | 1부 제목 | — |
| 4 | code | 1-1. 그래프 상수 · 계좌 번호 읽기 | `BASE_S` `K1`(=100) `NONE_GAP` `NAMES`(라벨 복사본 13열 이름) `COPY_FILES`(복사본 파일 이름 · 줄 수) `hexkey()` |
| 5 | code | 1-2. 정렬 구조 · 노드 14열 · 1홉 그래프 · 엣지 11열 | `sort_structs()` `node_feats()` `graph_for()` `edge11()` |
| 6 | code | 1-3. 그래프 만들기 또는 불러오기 | `read_copy()` `build_graph_from_copy()` `np_load_any()` `load_graph_files()` · 전역 `G` `seg` `y9` `yf` `att` `zs` `day` `learn` `pick` `val` `li` `pi` |
| 7 | md | 2부 제목 | — |
| 8 | code | 2-1. SALT2 모델 | `scatter_pt()` `softmax_pt()` `TransformerConvPT` `build_salt()` |
| 9 | code | 2-2. 묶음 · 예측 · macro-AP | `ranges()` `make_batch()` `predict()` `mAP5()` |
| 10 | code | 2-3. 정규화 기준값 · δ | 전역 `S` `delta` `n_node` `n_edge` `batch` |
| 11 | code | 2-4. 학습 함수 | `train_one()` `load_model()` `mAP9()` |
| 12 | md | 3부 제목 | — |
| 13 | code | 3. 학습(또는 불러오기) · 고르기 확률 저장 | 전역 `MODELS` `INFO` `Pf_pick` `Ps_pick` `ap_bin` |
| 14 | md | 4부 제목 | — |
| 15 | code | 4-1. 판정 규칙 ① · 채점 함수 | `rule1()` `keyw()` `BJ` `compare()` `macro()` `keyw5()` `compare5()` `assemble()` `route()` `preds()` `P3` |
| 16 | code | 4-2. 채점 도우미 | `score_pred()` `score5()` `funnel()` `pairwise()` `show()` |
| 17 | code | 4-3. 평가(val · `DO_VAL` 일 때만 실행) | `predict_all()` `evaluate_rows()` · 전역 `EVR` |
| 18 | md | 5부 제목 | — |
| 19 | code | 5. 기대값 비교(`DO_VAL` 일 때만) | `EXPECT` `EXPECT_EPOCH` |
| 20 | code | 6. [선택] 다른 노트북 val 예측과 규칙 ①로 견주기(`OTHER_PRED`) | — |

- 학습된 모델만 함수로 쓰려면: 셀 1 에서 `OUT_DIR` 을 복사한 씨앗 폴더로 바꾼 뒤 셀 1 ~ 11 을 차례로 실행하고 `load_model('대분류', 5)` · `load_model('fan-in_family', 2)` 처럼 부릅니다.
- `predict(model, batch, ix, k)` 는 그래프 행 번호 배열 `ix` 에 대한 softmax 확률 `(len(ix), k)`(float32)를 냅니다. **`ix` 에는 학습 · 고르기 행(`li` · `pi`)만 넣으십시오** — 평가 행을 넣으면 val 사용입니다(3-5 규칙 1).
- 계층 잇기: `preds(Pfam, Psub)` → `{'구조': (9칸 예측, 8유형 예측), '곱': (9칸 예측, 8유형 예측)}` · `Pfam` = 대분류 확률 `(n, 5)` · `Psub` = 이진 모델 4개의 '뒤 유형' 확률 `(n, 4)`(열 차례 = 묶음 0 ~ 3).
  - **8유형 예측**은 9칸 예측의 부분이 아니라 다른 규칙입니다: 대분류에서 무패턴을 빼고 4묶음 중 1등 → 이진 모델. 8유형 점수는 정답이 8유형인 행만으로 잰 8칸 macro 입니다.

## 5. 라벨 · 묶음 번호

| y9 | 유형 | 묶음(G5) | 이진 모델에서 |
|---|---|---|---|
| 0 | FAN-OUT | 0 `fan-out_family`(흩기) | 앞 = 0 |
| 3 | SCATTER-GATHER | 0 `fan-out_family` | 뒤 = 1 |
| 1 | FAN-IN | 1 `fan-in_family`(모으기) | 앞 = 0 |
| 4 | GATHER-SCATTER | 1 `fan-in_family` | 뒤 = 1 |
| 5 | BIPARTITE | 2 `bipartite_family`(층) | 앞 = 0 |
| 6 | STACK | 2 `bipartite_family` | 뒤 = 1 |
| 2 | CYCLE | 3 `cycle_family`(사슬) | 앞 = 0 |
| 7 | RANDOM | 3 `cycle_family` | 뒤 = 1 |
| 8 | no_pattern(무패턴 · 세탁이지만 8유형 밖) | 4 `no_pattern` | — |

- 코드 상수: `CN9 = ['FAN-OUT', 'FAN-IN', 'CYCLE', 'SCATTER-GATHER', 'GATHER-SCATTER', 'BIPARTITE', 'STACK', 'RANDOM', 'no_pattern']` · `G5 = [0, 1, 3, 0, 1, 2, 2, 3, 4]` · `PAIR = {0: (0, 3), 1: (1, 4), 2: (5, 6), 3: (2, 7)}`(묶음 → (앞 유형, 뒤 유형) · 이진 정답 1 = 뒤 유형).
- 정답 = 그 거래가 속한 시도(attempt)의 최종 유형(Patterns.txt).

## 6. 데이터 형식

### 6-1. `데이터/graph_slim.npz.xz` (읽기: `load_graph_files()` 가 .xz 를 풀어 원래 값으로 되살림)

대상(target) = 학습 · 고르기 · 평가 세탁 거래 94,270행. 그래프는 대상마다 따로인 부분 그래프를 이어 붙인 CSR 꼴입니다.

| 키 | dtype · 모양 | 뜻 |
|---|---|---|
| `noff` | int64 (94271,) | 대상 i 의 노드 = `nx[noff[i]:noff[i+1]]` |
| `nx` | float32 (2506930, 14) | 노드(계좌) 14열 — 6-3 |
| `eoff` | int64 (94271,) | 대상 i 의 엣지 = `ei[eoff[i]:eoff[i+1]]` · `ea` 같은 범위 |
| `ei` | int32 (8438741, 2) | 엣지 (보낸 노드, 받은 노드) — 대상 i 부분 그래프 안의 지역 번호 |
| `tg` | int32 (94270, 2) | 대상 거래의 (보낸 계좌, 받는 계좌) 지역 노드 번호(자기 송금이면 같음) |
| `use` | int64 (94270,) | `행나눔.parquet` 에서의 행 위치 |
| `eid` | int64 (94270,) | 거래 번호 = 원본 CSV 줄 번호(`행나눔.parquet` 의 `eid` 와 같음 · 날짜순 아님 · **행을 잇는 열쇠로만** · 3-5 규칙 5) |
| `seg` | str (94270,) | 구간: `학습` 52,147 · `고르기` 17,946 · `평가` 24,177 |
| `y9` | int8 (94270,) | 정답 0 ~ 8(5절) |
| `att` | int64 (94270,) | 패턴 행 = 시도 번호(≥ 0) · 무패턴 행 = 음수 자리표(시도가 아님). 평가 · 고르기에서는 무패턴 행마다 다른 값이지만, 학습에서는 -1 이 여러 행에 겹치고 구간끼리 같은 음수를 다시 씁니다 — 시도 단위로 묶거나 겹침을 셀 때는 `att >= 0` 행만 쓰십시오. 채점 부트스트랩 단위로 씀 |
| `집합` | str (94270,) | `train`(학습 · 고르기) · 평가 행: `S1`(val 안에서 시작한 시도) · `S2`(train 기간 08-01 ~ 09-27 에 시작해 val 로 이어진 시도) · `무패턴` |
| `minute` | int32 (94270,) | 대상 거래 시각(2022-08-01 00:00 부터 분) — **모델 입력 아님**(채점의 날짜 묶음 `day` 에만 씀) |

- 1홉 규칙: 대상 거래의 보낸 · 받는 계좌(씨앗)마다, 그 계좌가 **받은** 거래 중 대상 거래보다 **앞선 분**의 최근 100개(`K1`)가 엣지, 그 거래들의 보낸 계좌가 이웃 노드. 같은 분 거래는 넣지 않습니다.

### 6-2. `데이터/edge11_slim.npz.xz`

| 키 | dtype · 모양 | 뜻 |
|---|---|---|
| `ea11_u` | float32 (4528522, 11) | 서로 다른 엣지 피처 줄 |
| `ea11_inv` | int32 (8438741,) | 엣지마다 `ea11_u` 몇 번째 줄인지 → `ea = ea11_u[ea11_inv]`(노트북이 자동으로 되살림 · 원래 `ea11` 과 비트 같음) |
| `tx11` | float32 (94270, 11) | 대상 거래 자체의 11열(모델 머리에 들어감) |

엣지 · 대상 11열(차례대로 · 셀 5 `edge11()` · 팀 명세 FEATURE_SPEC_36 의 거래 이력 열):

| # | 이름 | 값 |
|---|---|---|
| 0 | `pair_prior_count` | log1p(앞선 분의 A→B 거래 수) |
| 1 | `pair_gap_minutes` | ln(2 + 마지막 A→B 거래 뒤 지난 분) · 이력 없으면 0 |
| 2 | `pair_count_1h` | log1p(최근 60분 A→B 거래 수) |
| 3 | `sender_gap_minutes` | ln(2 + A 의 마지막 보낸 거래 뒤 지난 분) · 없으면 0 |
| 4 | `sender_count_1h` | log1p(최근 60분 A 가 보낸 수) |
| 5 | `receiver_gap_minutes` | ln(2 + B 의 마지막 받은 거래 뒤 지난 분) · 없으면 0 |
| 6 | `receiver_count_1h` | log1p(최근 60분 B 가 받은 수) |
| 7 | `pair_history_count` | log1p(그날 0시 전 A→B 거래 수) |
| 8 | `reverse_history_count` | log1p(그날 0시 전 B→A 거래 수) |
| 9 | `pair_age_at_day_start` | 이름과 달리 쌍의 나이가 아님: ln(2 + 그날 0시와 그 앞 마지막 A→B 거래 사이 분) · 없으면 0 |
| 10 | `is_self_transfer` | A == B 면 1 |

- 간격 열의 0 은 '이력 없음' 표시입니다(실제 값은 ln 3 ≈ 1.10 이상). 노드 피처(6-3)는 '없음'을 반대로 큰 값(log1p(200000))으로 표시합니다.

### 6-3. 노드 14열(`node_feats()`)

보낸 쪽 7열(0 ~ 6) + 받은 쪽 7열(7 ~ 13), 각 7열 = [log1p(앞선 거래 수) · log1p(최근 1일 수) · log1p(7일 수) · log1p(30일 수) · log1p(서로 다른 상대 수) · 앞선 거래 log(1 + Amount Paid) 평균(거래 없으면 0) · log1p(마지막 거래 뒤 지난 분)(없으면 log1p(200000))] — 모두 대상 거래보다 앞선 분의 거래만, 2022-08-01 부터 셈.

- 금액은 **통화 환산 없이** 각 거래의 결제 통화 단위(Amount Paid) 그대로입니다. 받은 쪽 7열의 금액도 상대가 자기 결제 통화로 보낸 금액입니다(3-5 규칙 6).

### 6-4. `데이터/행나눔.parquet` (147,109행 = 학습 · 고르기 · 평가 기간의 세탁 거래 전체)

칸: `eid` · `구간`(학습 · 고르기 · 평가 · 뺌) · `뺀까닭` · `원래구간` · `y9` · `att` · `집합`. `뺌` 52,839행 = 노이즈 시도 · 정화(구간을 넘어 이어지는 시도) · test 로 이어지는 시도 — 쓰지 마십시오(3-5 규칙 3). 노트북은 `BUILD_GRAPH = True` 일 때만 이 파일을 읽습니다.

## 7. 모델(SALT2 · 셀 8 `build_salt`)

- `build_salt(n_node, n_edge, k, s, delta, H=64, heads=2, p=0.1, pf=0.3)` — 이 묶음에서는 `n_node = 14` · `n_edge = 11`(셀 10 이 `nx` · `ea` 모양에서 잼) · `s` = 셀 10 의 `S` · `delta` = 셀 10 의 `delta` · `k` = 5(대분류) 또는 2(이진).
- 입력 정규화(`zn`): 노드 14열은 학습 대상 부분 그래프 노드들의 평균 · 표준편차, 엣지 11열과 대상 `tx11` 은 **둘 다** 학습 대상 부분 그래프 엣지들의 평균 · 표준편차(`em` · `es`)로 나눔(표준편차 ≤ 1e-6 이면 1).
- 그다음: 노드 임베딩(14 → 64) → SALT 층 2개(엣지 통계(평균 · 표준편차 · 최소 · 최대 × 차수 보정 δ) + TransformerConv 주의 + 합침 · 잔차) → 머리 `[h(보낸), h(받는), tx11]`(64 + 64 + 11 = 139) → 64 → k.
- `forward(x, ei, ea, tg, tx)` — `make_batch(G, dev)(ix)` 가 이 다섯 텐서를 만듭니다(여러 대상의 부분 그래프를 이어 붙임).
- state_dict 77개 텐서(대분류 203,708 · 이진 203,513 값). 정규화 값(`zn.*`)과 δ(`salt_delta`)가 버퍼로 들어 있어 가중치 파일만으로 정규화가 재현됩니다.
- 학습: Adam lr 0.001 · 교차 엔트로피(가중 없음) · 기울기 자르기 5 · 100 epoch · 배치 512 · 묶음 순서 `np.random.default_rng([SEED, ep]).permutation(...)`(ep = 0 ~ 99 · 고른 epoch 와 salt_hist 의 epoch 는 ep + 1) · 모델마다 시작할 때 `torch.manual_seed(SEED)` 를 다시 겁니다.
- epoch 고르기 = 고르기 구간 점수 최고(같으면 앞 epoch): 대분류 = 고르기 전체 5칸 macro-AP · 이진 = **정답 묶음의 고르기 행만**으로 잰 AP. 이진 모델은 학습도 정답 묶음의 행만 씁니다.

## 8. 출력(`OUT_DIR` 안)

| 파일 | 언제 | 내용 |
|---|---|---|
| `salt_best_<모델>.pt` · `salt_hist_<모델>.csv` · `salt_학습.json` | `DO_TRAIN = True` | 가중치 · epoch 기록 · 학습 요약 |
| `salt_고르기.npz` | 항상 | 고르기 행 `eid` · `Pfam`(5) · `Psub`(4 · float32) |
| `val_pred.npz` | `DO_VAL = True` | 평가 행 `eid` · `y9` · `att` · `day` · `Pfam` · `Psub` · `pred9`(차례 판별) |
| `val_결과.json` · `val_단계별.csv` · `val_이진단독.csv` · `val_혼동표.csv` | `DO_VAL = True` | 점수 · 단계별(대분류 탓 / 이진 탓) · 이진 단독(정답 묶음 안 · 참고) · 혼동표 |
| `graph.npz` · `edge11.npz` | `BUILD_GRAPH = True` | 새로 만든 그래프(압축 안 한 꼴 · 다음부터 `GRAPH_NPZ` · `EDGE11_NPZ` 로 불러올 수 있음) |

## 9. 결과와 알려진 한계

- 계층 씨앗 3개(42 · 43 · 44) 9칸 정밀도 / 재현율 **0.5644 ± 0.0031 / 0.5343 ± 0.0084**(씨앗 42 가 셋 중 재현율이 가장 높음).
- 같은 그래프의 '9클래스 한 번에' 모델(씨앗 3개 0.5751 ± 0.0056 / 0.5478 ± 0.0077)과 같은 씨앗끼리 견주면 세 짝 모두 9클래스가 높았습니다(규칙 ① '오름' 3번 · 평균 차이 +0.0107 / +0.0136 이 두 쪽 씨앗 표준편차 중 큰 것보다 큼 · 미리 정한 읽기 '9클래스가 씨앗에 흔들리지 않고 오름' · val 기준 개발용 판정).
  - 9클래스 묶음 README 의 "오름이라고 하지 않습니다" 는 계층 씨앗 42 하나와 견준 옛 읽기입니다. 두 쪽 모두 씨앗 3개로 견준 것은 위 읽기가 최신입니다.
- 사슬 이진(CYCLE vs RANDOM)은 고르기 AP 0.43 ~ 0.44 로 거의 못 가릅니다(RANDOM 비율 약 0.41). cycle 모델의 고르기 AP 는 100 epoch 내내 0.40 ~ 0.44 사이로 거의 평평해서, 고른 epoch 가 씨앗마다 크게 다릅니다(15 · 90 · 95).
- 대분류가 틀린 행은 이진 모델이 무엇을 내든 틀립니다(셀 17 의 '단계별' 표).
- val 숫자는 개발용 · 2단계만입니다. 노트북 한 번 실행은 씨앗 하나의 숫자를 냅니다. 최종 성능은 test 에서 마지막에 한 번 잽니다(이 묶음 밖).
- 이 노트북은 **이 데이터셋의 재현용**입니다. 새 거래 자료에 바로 쓰는 추론 파이프라인이 아닙니다: `build_graph_from_copy()` 는 라벨 복사본 13열 꼴과 줄 수 · 세탁 줄 147,109 = `행나눔.parquet` 를 assert 합니다.

## 10. 출처(손은총 님 작업 서버 기준 · 참고용)

- 서버 노트북: `/workspace/Final_preprocess/HI-Large_EDA/모델코드_노트북_20261016/10_SALT_계층_한파일.ipynb`(이 노트북과 코드 셀이 같고 설정 셀 · 머리말 첫 줄만 다름)
- 원래 결과: 씨앗 42 = `.../유형분류_8종_20261013/results/LGB_SALT_통화형식뺌_20261029/`(모델 · `결과.json` · 보고서) · 씨앗 43 · 44 와 세 씨앗 비교 = `.../results/SALT_계층_시드_20261029/`(사전기록 · 보고 `보고_SALT_계층_시드_20261029.md`)
- 묶음 만든 코드: `/workspace/Final_preprocess/HI-Large_EDA/SALT_계층_전달묶음_20261029/make_zip.py`
