# CLAUDE.md

이 폴더(SALT-GNN 계층 전달 묶음)의 AI 에이전트용 안내는 `AGENTS.md` 에 있습니다. 아래 줄이 그 파일을 불러옵니다. 사람용 설명은 `README.md`.

@AGENTS.md
