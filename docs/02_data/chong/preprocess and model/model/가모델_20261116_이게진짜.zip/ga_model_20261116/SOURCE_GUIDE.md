# 실험에서 사건을 정한 방법과 서비스에서 Alert를 만드는 방법

**(가) 실험은 합성 자료의 사건 번호를 알고 출발합니다.** 같은 사건에서 같은 날까지 발생한 거래를 모아 정답을 만들고, 마지막 거래 주변의 실제 원장 행을 더해 모델 입력을 만듭니다. **서비스는 이진 모델의 점수에서 출발합니다.** 계좌·시각·금액으로 이어지는 근거가 있을 때 거래를 같은 Alert에 넣습니다. 두 경우 모두 모델에 거래 목록을 줄 수 있지만, 8번째 피처의 소속을 정하는 근거가 다릅니다.

## 원본 코드에서 따라갈 순서

| 확인할 질문 | 코드에서 볼 부분 |
|---|---|
| 실험에서 사건 한 건과 날짜별 정답은 어떻게 만들었나? | [g1_data.py](experiment/results/묶음단위_모델_20261111/code/g1_data.py)의 `groupby('att')`와 날짜 반복문을 봅니다. 한 사건의 그날까지의 송금 방향과 원래 유형으로 [g_lib.py](experiment/results/묶음단위_모델_20261111/code/g_lib.py)의 `flags`와 `label_v`를 호출합니다. |
| 11월 16일 재학습 원장에 어떤 거래를 남겼나? | [f1_trainval_input.py](experiment/results/묶음단위_가_세종류뺌_꼬리포함_20261116/code/f1_trainval_input.py)의 `rem`과 `keep`을 봅니다. 세탁으로 표시됐지만 대상 여섯 유형에 속하지 않는 무패턴·BIPARTITE·STACK 거래를 제거하고, 남은 원장을 `H1.build_inputs`에 넘깁니다. |
| 정상 거래는 몇 건씩 어떻게 섞었나? | [e1_build.py](experiment/results/묶음단위_주변거래_학습_20261112/code/e1_build.py)의 `take`와 `expand`를 봅니다. 기준 거래의 양 끝 계좌에서 시작해 최대 2홉을 탐색하고, 계좌마다 마감 전 100일 안의 입출금 중 최근 200건까지 가져옵니다. 정상·세탁 여부는 이 함수의 입력에 없습니다. 따라서 정상 거래의 수와 비율은 계좌의 거래 이력에 따라 달라집니다. |
| 주변 거래와 사건 거래를 어떻게 구별하나? | [h1_test_input.py](experiment/results/묶음단위_주변거래_test_가_20261116/code/h1_test_input.py)의 `build_inputs`에서 `m_laund`는 원장의 세탁 표시, `m_own`은 그날까지 해당 사건에 속하는 거래의 표시입니다. 다른 세탁 사건에 속한 주변 거래도 `m_own=0`입니다. 파일 이름에 test가 있지만 11월 16일 학습·검증 입력 생성 때에도 같은 함수를 호출했습니다. |
| 모델에는 어떤 표시가 들어가나? | [f2_train.py](experiment/results/묶음단위_가_세종류뺌_꼬리포함_20261116/code/f2_train.py)의 `PANELS`, `Data.set_norm`, `Net`, `main`이 (가)의 표시·8열·신경망·학습을 정의합니다. [f5_predict.py](experiment/results/묶음단위_가_세종류뺌_꼬리포함_20261116/code/f5_predict.py)의 `run`이 `a['m_own']`을 [h_lib.py](experiment/results/묶음단위_주변거래_test_가_20261116/code/h_lib.py)의 `features`에 넘기고, 이 값이 8번째 열이 됩니다. |
| 서비스는 실제로 어떤 거래를 하나의 Alert에 넣나? | [alert_pipeline.py](service_snapshot/backend/api-server/worker/alerts/alert_pipeline.py)에서 점수와 입력을 고정하고 [seed_promotion.py](service_snapshot/backend/api-server/worker/alerts/seed_promotion.py)의 `promote`로 씨앗을 보강합니다. [block_graph.py](service_snapshot/backend/api-server/worker/alerts/block_graph.py)의 `build_block_graphs`가 채택한 구조 근거에 따라 `seed_ids`와 `connection_ids`를 돌려줍니다. 금액·시간이 이어지는 비씨앗 거래를 확인하려면 같은 파일의 `paths`를 봅니다. |

11월 16일 실험에서 **채점 대상 검증 묶음 13,796개에 들어간 전체 거래 행 중 98.035%**가 원장에서 정상으로 표시된 거래였습니다. 같은 실험의 학습 묶음에서는 98.215%였습니다. 이는 주변 원장을 조회한 **결과로 측정한 비율**입니다. 여러 사건·날짜의 입력에 같은 거래가 들어가면 각각의 행으로 집계됩니다. [원본 집계표](experiment/results/묶음단위_가_세종류뺌_꼬리포함_20261116/tables/1_입력_크기와_구성.csv)

## 작은 원장으로 실행해서 확인하기

압축을 푼 폴더에서 `python -m pip install -r requirements-review.txt`를 실행한 다음 `python verify_grouping.py`를 실행합니다. 가상 거래 7건과 예시 이진 점수는 [검증 스크립트](verify_grouping.py)의 `ROWS`에 있습니다.

| 예시 거래 | 직접 확인할 결과 |
|---|---|
| 102번 | 가상 원장에서는 정상입니다. 실험 입력에는 주변 거래로 들어와 8번째 값이 0입니다. 서비스 생성기에서는 의심 거래 101번과 103번 사이의 금액·시각·방향이 이어져 같은 Alert의 연결 거래가 됩니다. |
| 105번과 106번 | 105번은 정상 거래, 106번은 다른 세탁 사건의 거래입니다. 둘 다 이 사건 주변에 들어오지만 8번째 값은 0입니다. |
| 104번과 107번 | 104번은 의심 점수가 높지만 계좌 흐름이 따로 떨어져 있습니다. 107번은 관측 마감 이후입니다. 둘 다 이 사건의 실험 입력에 들어오지 않습니다. |

실험 쪽은 원본 `t1_test.build`와 `h1_test_input.build_inputs`를 호출합니다. 서비스 쪽은 같은 시점에 보인 거래와 예시 점수를 원본 `promote`와 `build_block_graphs`에 넣습니다. 102번 한 건을 빼고 다시 실행하면 이 예시에서 서비스 Alert 수가 1개에서 0개가 됩니다. 이 실행은 그룹 구성만 점검합니다. 서비스 이진 모델의 점수를 새로 계산하거나 서비스 전체의 성능을 측정하는 과정은 별도입니다.

## 파일 출처와 실행 범위

- `experiment/results/`에는 11월 16일 실험 폴더와 원래 상대 경로대로 배치한 공용 코드가 있습니다. 핵심 코드는 실험 당시의 [고정 해시 기록](experiment/results/묶음단위_가_세종류뺌_꼬리포함_20261116/data/코드_sha256_고정시.txt)과 대조했습니다. 그 원본 기록에는 대용량 입력의 해시도 있습니다.
- `service_snapshot/`에는 서비스 개발 저장소 커밋에서 가져온 Alert 관련 소스가 있습니다. DB·전체 백엔드에서 Alert를 발행하는 경로는 저장소에서 확인할 수 있습니다. [서비스 원본 커밋](https://github.com/dh0728/money_laundry/tree/e803583f0433cbafb9ddf57ad1e7d1a665726696/backend/api-server/worker/alerts)
- 이 ZIP만으로 가상 원장 검증과 `python predict.py`가 실행됩니다. **전체 실험을 처음부터 다시 학습**하려면 별도 원본 거래 CSV, 원장 배열(`tmp_ledger`), 사건 라벨·분할·묶음 자료, 원래 경로 구성과 학습용 GPU가 필요합니다. 데이터 경로와 단계는 [실험 공통 설정](experiment/results/묶음단위_가_세종류뺌_꼬리포함_20261116/code/f_lib.py)과 [11월 16일 결과 보고서](experiment/results/묶음단위_가_세종류뺌_꼬리포함_20261116/보고_가_세종류뺌_꼬리포함_20261116.md)에 있습니다.
