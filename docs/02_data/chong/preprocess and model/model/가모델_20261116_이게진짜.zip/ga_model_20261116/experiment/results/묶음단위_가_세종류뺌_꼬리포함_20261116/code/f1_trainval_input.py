"""[1 · train · val 입력] train · val 원장(날 0 ~ 74)에서 세 종류(무패턴 · BIPARTITE · STACK) 거래를 지우고, 11-12 와 같은 규칙(2홉 · 100일 · 200건)으로 주변 거래 입력을 다시 만듦.
2026-11-16 · 손은총 · Claude Code. CPU · 메모리 25 GiB 쯤 · 학습 · 추론 없음.
test 안 엶: 지우는 규칙을 train · val 에서 맞대려고 원본 CSV 를 읽되, 날 75 앞 줄만 남기고 나머지는 덩이마다 읽자마자 버림(f_lib.read_raw_rows).
넓히기 · 표시 = 11-16 h1_test_input.build_inputs(= 11-12 e1_build.py main 의 반복 · 두 번 줄 세우기 · 함수 그대로).
출력: data/뺀_원장줄_trainval.npy(tmp_ledger 줄 번호) · data/입력/*.npy · data/묶음표.parquet · data/1_입력_요약.json · tables/1_입력_크기와_구성.csv · logs/f1_trainval_input.log
쓰는 법: python3 code/f1_trainval_input.py"""
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
import f_lib as F  # noqa: E402

TY = ['FAN-OUT', 'FAN-IN', 'CYCLE', 'SC-GA', 'GA-SC', 'RANDOM']


def q(a):
    a = np.asarray(a, np.float64); return dict(가운데=float(np.median(a)), 평균=round(float(a.mean()), 1), p90=float(np.percentile(a, 90)), 최대=float(a.max()))


def main():
    assert not (F.OUT / 'data/입력').exists(), '입력이 이미 있음 → 다시 만들지 않음'
    log = F.logger(F.OUT / 'logs/f1_trainval_input.log'); H1 = F.h1mod(); C = H1.C
    meta = json.loads((F.LED / 'meta.json').read_text()); base = int(meta['base_min']); NA = int(meta['n_acct'])
    tmin, tsid, tdid, tlap, tlab = (np.load(F.LED / f'{n}.npy') for n in ('minute', 'sid', 'did', 'lap', 'lab')); N = len(tmin)
    NR, (rid, m, sk, dk, lap, lab) = F.read_raw_rows(base, 0, F.TV_END, log)
    order, uk = F.match_tmp_ledger(m, sk, dk, lap, lab, tmin, tsid, tdid, tlap, tlab, NA); led_rid = rid[order]; del rid, m, sk, dk, lap, lab, order, uk
    log(f'점검 1 통과: 원본 날 0 ~ 74 줄 = tmp_ledger(줄마다 · 차례 train → val) · 원장 {N:,}줄')
    # ── 지우는 규칙 ──
    pl = pd.read_parquet(F.PLAB); six, three = F.six_and_three(pl); is6 = F.in_sorted(led_rid, six); is3 = F.in_sorted(led_rid, three)
    assert not (is6 & (tlab == 0)).any() and not (is3 & (tlab == 0)).any(), 'Patterns 줄인데 원본 세탁 표시가 0 → 멈춤'
    rem = (tlab == 1) & ~is6
    TV = pd.read_parquet(F.SPL / 'data/행_trainval.parquet', columns=['eid', 'att', 'y9', '구간', 'lpos', 'minute'])
    assert np.array_equal(led_rid[TV['lpos'].to_numpy()], TV['eid'].to_numpy()), '행_trainval 의 eid · lpos 가 원장과 다름 → 멈춤'
    nop = np.zeros(N, bool); nop[TV.loc[TV['y9'] == 8, 'lpos'].to_numpy()] = True; t6 = np.zeros(N, bool); t6[TV.loc[TV['y9'].isin(C.KS), 'lpos'].to_numpy()] = True
    assert np.array_equal(rem, nop | is3), '점검 2: 지울 줄 ≠ 무패턴(행_trainval y9 = 8) + BIPARTITE · STACK 줄 → 멈춤'
    assert not (nop & is3).any() and not (t6 & ~is6).any(), '점검 2: 종류가 겹침 → 멈춤'
    extra = is6 & (tlab == 1) & ~t6; ea = set(pl.set_index('edge_id').loc[led_rid[extra], 'attempt_id'].tolist()); U = pd.read_parquet(F.OLD / 'data/단위.parquet')
    assert not (ea & set(U['att'])), '점검 2: 행_trainval 에 없는 6유형 줄의 시도가 묶음에 있음 → 멈춤'
    S = dict(원장_줄=N, 세탁_줄=int((tlab == 1).sum()), 지운_줄=int(rem.sum()), 지운_무패턴=int(nop.sum()), 지운_BIPARTITE_STACK=int(is3.sum()), 남은_6유형_줄=int((is6 & (tlab == 1)).sum()),
             남은_6유형_줄_가운데_train_노이즈_시도=int(extra.sum()), 노이즈_시도=len(ea), 원본_전체_줄=int(NR))
    F.SEAL.mkdir(parents=True, exist_ok=True); (F.SEAL / 'f1_원장_개수_SEALED.json').write_text(json.dumps(S, ensure_ascii=False, indent=1), encoding='utf-8')   # test 시도의 앞쪽 줄이 섞인 수는 봉인에만
    S = {k: S[k] for k in ('원장_줄', '지운_줄', '지운_무패턴', '지운_BIPARTITE_STACK')}; log(f'점검 2 통과: 지울 줄 = 무패턴 + BIPARTITE · STACK · {json.dumps(S, ensure_ascii=False)}(그 밖의 수는 data/test_SEALED/f1_원장_개수_SEALED.json)')
    keep = ~rem; newpos = np.cumsum(keep).astype(np.int64) - 1
    fmin, fsid, fdid, flap, flab = tmin[keep], tsid[keep], tdid[keep], tlap[keep], tlab[keep]; f6 = is6[keep]
    assert np.array_equal(flab == 1, f6), '지운 뒤 원장의 세탁 거래가 6유형 줄과 다름 → 멈춤'
    (F.OUT / 'data').mkdir(exist_ok=True); np.save(F.OUT / 'data/뺀_원장줄_trainval.npy', np.flatnonzero(rem).astype(np.int64)); del tmin, tsid, tdid, tlap, tlab, is3, nop, led_rid
    # ── 묶음 · 입력 ──
    T6 = TV[TV['y9'].isin(C.KS)].copy(); assert keep[T6['lpos'].to_numpy()].all(); T6['lpos'] = newpos[T6['lpos'].to_numpy()]
    assert np.array_equal(fmin[T6['lpos'].to_numpy()].astype(np.int64), T6['minute'].to_numpy().astype(np.int64))
    U0 = pd.read_parquet(F.EXP / 'data/묶음표.parquet'); assert np.array_equal(U0['att'].to_numpy(), U['att'].to_numpy()) and np.array_equal(U0['날'].to_numpy(), U['날'].to_numpy())
    A, X = H1.build_inputs(U, T6[['att', 'minute', 'lpos']], fmin, fsid, fdid, flap, flab, NA, log)
    off = A['eoff']; NB = len(U); ne = np.diff(off); bid = np.repeat(np.arange(NB), ne); is_tr = (U['구간'] == 'train').to_numpy()
    assert (A['e_min'][is_tr[bid]] < F.VAL0).all(), 'train 입력에 val 기간 거래가 있음 → 멈춤'
    assert A['m_own'][off[:-1]].all() and not (A['m_own'] & ~A['m_laund']).any()   # 입력의 세탁 표시 = flab[줄] = 1 = 6유형 줄(위 assert) → 지운 세 종류는 입력에 없음
    log('점검 3 통과: 마감 뒤 거래 없음 · 씨앗이 맨 앞 · train 입력에 val 기간 거래 없음 · 입력의 세탁 거래 = 6유형 시도 거래뿐')
    d = F.OUT / 'data/입력'; d.mkdir(parents=True)
    for nm in F.ARR:
        np.save(d / f'{nm}.npy', A[nm])
    # ── 묶음표 · 구성 ──
    tr_acc = np.zeros(NA, bool); lp_tr = T6.loc[T6['구간'] == 'train', 'lpos'].to_numpy(); tr_acc[fsid[lp_tr]] = True; tr_acc[fdid[lp_tr]] = True
    n_in = X['n_in']; n = X['n']; seed_row = X['seed_row']; own = A['m_own']; lau = A['m_laund']; HP = A['e_hop']
    nl = np.add.reduceat(lau.astype(np.int64), off[:-1]); n1 = np.add.reduceat((HP == 1).astype(np.int64), off[:-1])
    U2 = U[['att', 'y9', '구간', '날', '나이', '끝', '거래수', '계좌수', 'y6', 'v6', '꼴']].copy(); U2['val_채점'] = U0['val_채점'].to_numpy(); U2['입력_거래'] = ne; U2['입력_계좌'] = A['nn']
    U2['입력_1홉_거래'] = n1; U2['입력_세탁표시_거래'] = nl; U2['입력에_든_시도거래'] = n_in; U2['씨앗계좌가_train시도에_나옴'] = tr_acc[fsid[seed_row]] | tr_acc[fdid[seed_row]]
    U2['옛_입력_거래'] = U0['입력_거래'].to_numpy(); U2['옛_입력에_든_시도거래'] = U0['입력에_든_시도거래'].to_numpy(); U2.to_parquet(F.OUT / 'data/묶음표.parquet', index=False)
    rows = []
    for seg, mm in (('train', is_tr), ('val(채점하는 2,127시도)', U2['val_채점'].to_numpy())):
        em = mm[bid]; ne_o = U2['옛_입력_거래'].to_numpy()[mm]; nin_o = U2['옛_입력에_든_시도거래'].to_numpy()[mm]
        rows.append({'구간': seg, '묶음': int(mm.sum()), **{f'입력 거래 수 {k}': v for k, v in q(ne[mm]).items()}, '옛 입력 거래 수 가운데': float(np.median(ne_o)),
                     '입력 거래 수가 옛 입력과 같은 묶음 몫': round(float((ne[mm] == ne_o).mean()), 4),
                     '그 시도 거래가 입력에 다 든 묶음 몫': round(float((n_in[mm] == n[mm]).mean()), 4), '옛 입력에서 다 든 묶음 몫': round(float((nin_o == n[mm]).mean()), 4),
                     '입력 거래 가운데 그 시도 거래 몫': round(float(own[em].mean()), 5), '입력 거래 가운데 다른 6유형 시도 거래 몫': round(float((lau & ~own)[em].mean()), 5),
                     '입력 거래 가운데 정상 거래 몫': round(float((~lau)[em].mean()), 5), '씨앗 계좌가 train 시도에 나온 묶음 몫': round(float(U2['씨앗계좌가_train시도에_나옴'].to_numpy()[mm].mean()), 4)})
    t1 = pd.DataFrame(rows); (F.OUT / 'tables').mkdir(exist_ok=True); t1.to_csv(F.OUT / 'tables/1_입력_크기와_구성.csv', index=False, encoding='utf-8-sig'); log('입력 크기와 구성\n' + t1.T.to_string())
    out = dict(설정=dict(홉=2, 기간_일=100, 이웃_상한=200, 분_칸_비트=18), 원장=S, 묶음=NB, 입력_거래_합=int(len(HP)), train_입력_거래_합=int(ne[is_tr].sum()), val_입력_거래_합=int(ne[~is_tr].sum()),
               점검=dict(점검1='원본 날 0 ~ 74 줄 = tmp_ledger', 점검2='지울 줄 = 무패턴 + BIPARTITE · STACK(행_trainval · pattern_labels 와 맞음)', 점검3='마감 뒤 거래 0 · 씨앗 맨 앞 · train 입력에 val 기간 거래 0 · 입력의 세탁 거래 = 6유형뿐'))
    (F.OUT / 'data/1_입력_요약.json').write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8'); log(f'끝 · {json.dumps(out, ensure_ascii=False)}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
