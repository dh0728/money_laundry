"""[3 · val 채점] 새 (가)(세 종류를 지운 원장 · 다시 학습) 와 11-12 (가)(세 종류가 있는 원장)를 같은 val 묶음(76시도를 뺀 2,127시도)에서 채점 · 견줌.
2026-11-16 · 손은총 · Claude Code. CPU · 학습 없음 · test 안 엶.
채점 식 = 11-11 t1_test.py 의 score(6유형 macro 정밀도 / 재현율 · 씨앗 3개 평균 · 시도 단위 부트스트랩 2,000번 · 난수 20261008) · 판 차이 = 11-12 e4_score.py 의 panel_diff(같은 부트스트랩).
출력: tables/3_val_주표.csv · 3_val_유형별.csv · 3_val_차이.csv · 3_학습곡선.csv · data/3_val_결과.json · logs/f3_val_score.log
쓰는 법: python3 code/f3_val_score.py"""
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
import f_lib as F  # noqa: E402
sys.path.insert(0, str(F.EXP / 'code'))
import e4_score as E4  # noqa: E402  (load 은 안 씀 · panel_diff · S1 · S2 · C · T1 만 · main 은 돌지 않음)

C, T1, S1, S2 = E4.C, E4.T1, E4.S1, E4.S2
NEW, OLDP = '새 (가) · 세 종류 뺌', '11-12 (가) · 세 종류 있음'
KEEP = ('묶음', '시도', '모델', '규칙', '차이', '유형별')


def probs(root, va, keep):
    out = {}
    for s in F.SEEDS:
        Z = np.load(root / f'run/가/seed{s}/val확률.npz'); assert (Z['ix'] == va).all() and (Z['keep'] == keep).all(); out[s] = Z['P'][keep]
    return out


def curve(root, tag):
    rows = []
    for s in F.SEEDS:
        h = pd.read_csv(root / f'run/가/seed{s}/hist.csv', encoding='utf-8-sig'); i = int(h['고르기_점수'].idxmax()); j = json.loads((root / f'run/가/seed{s}/학습.json').read_text(encoding='utf-8'))
        rows.append({'판': tag, '씨앗': s, '고른 epoch': int(h.loc[i, 'epoch']), '고른 epoch: 학습 손실': round(float(h.loc[i, 'train_loss']), 4), '고른 epoch: val macro-AP': round(float(h.loc[i, '고르기_점수']), 4),
                     '고른 epoch: val 맞은 몫': round(float(h.loc[i, 'val_맞은몫']), 4), '마지막 epoch: val macro-AP': round(float(h['고르기_점수'].iloc[-1]), 4), '금액 평균': round(j['금액_평균'], 4),
                     '금액 표준편차': round(j['금액_표준편차'], 4), '학습 입력 거래': j['학습_입력_거래'], '학습 분': round(j['학습초'] / 60, 1)})
    return rows


def main():
    F.check_fixed(); assert all((F.OUT / f'run/state_DONE_가_s{s}').exists() for s in F.SEEDS), '씨앗 3개 학습이 다 끝나지 않음 → 멈춤'
    log = F.logger(F.OUT / 'logs/f3_val_score.log')
    U = pd.read_parquet(F.OUT / 'data/묶음표.parquet'); va = np.flatnonzero((U['구간'] != 'train').to_numpy()); keep = U['val_채점'].to_numpy()[va]; Uv = U.iloc[va][keep].reset_index(drop=True)
    rule, fb = T1.rule_table(); p_rule = Uv['꼴'].map(rule).fillna(fb).to_numpy(np.int64)
    PM = {NEW: probs(F.OUT, va, keep), OLDP: probs(F.EXP, va, keep)}
    seen = Uv['씨앗계좌가_train시도에_나옴'].to_numpy(); allin = (Uv['입력에_든_시도거래'] == Uv['거래수']).to_numpy(); same_n = (Uv['입력_거래'] == Uv['옛_입력_거래']).to_numpy()
    SPL = [('전체', np.ones(len(Uv), bool)), ('씨앗 계좌가 train 시도에 나온 묶음', seen), ('씨앗 계좌가 train 시도에 안 나온 묶음', ~seen),
           ('그 시도 거래가 새 입력에 다 든 묶음', allin), ('그 시도 거래가 새 입력에 다 들지 않은 묶음', ~allin), ('입력 거래 수가 옛 입력과 같은 묶음', same_n), ('입력 거래 수가 옛 입력과 다른 묶음', ~same_n)]
    out = dict(val=dict(시도=int(Uv['att'].nunique()), 묶음=len(Uv)), 나눔_몫={n: round(float(m.mean()), 4) for n, m in SPL}); mrows, trows, drows = [], [], []
    for snm, m in SPL:
        ix = np.flatnonzero(m)
        if len(ix) == 0:
            continue
        Us = Uv.iloc[ix].reset_index(drop=True); out[snm] = {}
        for pn, P in PM.items():
            R = T1.score(Us, {s: P[s][ix] for s in F.SEEDS}, p_rule[ix]); out[snm][pn] = {k: {kk: v[kk] for kk in KEEP} for k, v in R.items()}
            for k, v in R.items():
                mrows.append({'나눔': snm, '판': pn, '성적표': k, '묶음': v['묶음'], '시도': v['시도'], '정밀도': v['모델']['정밀도'], '정밀도 95%': str(v['모델']['정밀도_95']), '재현율': v['모델']['재현율'],
                              '재현율 95%': str(v['모델']['재현율_95']), '맞은 몫': v['모델']['맞은몫'], 'macro-AP': v['모델']['macroAP'], '정밀도 씨앗 SD': v['모델']['정밀도_SD'], '재현율 씨앗 SD': v['모델']['재현율_SD']})
                if snm == '전체':
                    trows += [{'판': pn, '성적표': k, '유형': t['유형'], '정답 수': t['정답수'], '정밀도': t['모델_정밀도'], '재현율': t['모델_재현율']} for t in v['유형별']]
        dd = E4.panel_diff(Us, {s: PM[NEW][s][ix] for s in F.SEEDS}, {s: PM[OLDP][s][ix] for s in F.SEEDS}); out[snm]['새 − 11-12'] = dd
        for k, v in dd.items():
            drows.append({'나눔': snm, '성적표': k, '정밀도 차(새 − 11-12)': v['정밀도'], '정밀도 95%': str(v['정밀도_95']), '재현율 차': v['재현율'], '재현율 95%': str(v['재현율_95']), '두 판이 같은 답을 낸 몫': v['같은답몫']})
        log(f"{snm}: 새 (1) {out[snm][NEW][S1]['모델']['정밀도']} / {out[snm][NEW][S1]['모델']['재현율']} · (2) {out[snm][NEW][S2]['모델']['정밀도']} / {out[snm][NEW][S2]['모델']['재현율']} | "
            f"11-12 (1) {out[snm][OLDP][S1]['모델']['정밀도']} / {out[snm][OLDP][S1]['모델']['재현율']} · (2) {out[snm][OLDP][S2]['모델']['정밀도']} / {out[snm][OLDP][S2]['모델']['재현율']} | 차 {json.dumps(dd, ensure_ascii=False)}")
    cv = pd.DataFrame(curve(F.OUT, NEW) + curve(F.EXP, OLDP)); out['학습곡선'] = cv.to_dict('records')
    pd.DataFrame(mrows).to_csv(F.OUT / 'tables/3_val_주표.csv', index=False, encoding='utf-8-sig'); pd.DataFrame(trows).to_csv(F.OUT / 'tables/3_val_유형별.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(drows).to_csv(F.OUT / 'tables/3_val_차이.csv', index=False, encoding='utf-8-sig'); cv.to_csv(F.OUT / 'tables/3_학습곡선.csv', index=False, encoding='utf-8-sig')
    (F.OUT / 'data/3_val_결과.json').write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8'); log('끝\n' + cv.to_string(index=False))
    return 0


if __name__ == '__main__':
    sys.exit(main())
