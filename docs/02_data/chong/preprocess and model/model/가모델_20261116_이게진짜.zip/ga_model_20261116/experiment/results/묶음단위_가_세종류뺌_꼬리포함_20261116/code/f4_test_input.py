"""[4 · test 입력] test 를 엶 — TEST_OPENED 한 줄 → 원장(train · val 원장 + 원본 날 75 ~ 끝 줄) → 세 종류 지움 → test 묶음(11-12 꼬리 포함 test 묶음과 같은지) → 주변 거래 입력.
2026-11-16 · 손은총 · Claude Code. CPU · 메모리 30 GiB 쯤. test 개수가 든 것은 data/test_SEALED/ 에만 씀(봉인 밖 data/4_test_입력_점검.json 에는 비율만).
test 시도 = 6유형 시도 가운데 원본 마지막 거래 날이 75(10-15) 이후인 시도(11-12 꼬리 포함 test 와 같은 규칙 · val 에서 꼬리로 이어지는 76시도가 옮겨 옴). 거래는 원본 끝(2023-01-12)까지.
묶음 만들기 = 11-11 t1_test.build · 넓히기 = 11-16 h1_test_input.build_inputs(= 11-12 e1_build 함수) · 원본 읽기 = f_lib.read_raw_rows(= h1 read_raw 와 같은 식).
쓰는 법: python3 code/f4_test_input.py --dry-val  → test 안 엶: 날 75 앞 줄만 읽어 같은 길로 val 시도의 묶음 · 입력을 만들고 11-11 val 묶음 · f1 의 val 입력과 같은지 봄(파일은 logs/f4_dry_val.log 만)
        python3 code/f4_test_input.py            → test 를 엶(한 번만 · data/test_SEALED/입력_test 가 있으면 안 돎)"""
import json
import os
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
import f_lib as F  # noqa: E402

COLS = ['att', 'y9', '날', '나이', '끝', '거래수', '계좌수', 'y6', 'v6', '꼴']


def rid_index(frid):
    """원본 줄 번호 → 지운 뒤 원장 줄 번호(없으면 -1)."""
    o = np.argsort(frid, kind='stable'); s = frid[o]; assert (np.diff(s) > 0).all(), '원본 줄 번호가 겹침 → 멈춤'

    def f(x):
        p = np.minimum(np.searchsorted(s, x), len(s) - 1); return np.where(s[p] == x, o[p], -1).astype(np.int64)
    return f


def build_P(pl6, atts, r2p, fmin, fsid, fdid, flap, only_in=False):
    """pattern_labels 6유형 줄 가운데 atts 시도의 줄 → t1_test.build 가 받는 꼴(att · y9 · minute · 날 · src · dst · lap · lpos = 원장 줄 번호)."""
    q = pl6[pl6['attempt_id'].isin(atts)]; pos = r2p(q['edge_id'].to_numpy(np.int64))
    if only_in:                                    # --dry-val: 날 75 앞 원장에 있는 줄만
        q, pos = q[pos >= 0], pos[pos >= 0]
    assert (pos >= 0).all(), '6유형 줄이 원장에 없음 → 멈춤'
    P = pd.DataFrame(dict(att=q['attempt_id'].to_numpy(np.int64), y9=q['pattern_type'].map({t: i for i, t in enumerate(F.CN9)}).to_numpy(np.int64), minute=fmin[pos].astype(np.int64),
                          src=fsid[pos], dst=fdid[pos], lap=flap[pos], lpos=pos))
    P['날'] = (P['minute'] // 1440).astype(np.int64); return P


def same_bundles(U, G, U0, G0):
    r = {c: bool(len(U) == len(U0[c]) and np.array_equal(U[c].to_numpy(), np.asarray(U0[c]))) for c in ('att', '날', 'y6', 'v6', '끝')}
    r.update({k: bool(np.array_equal(G[k], G0[k])) for k in ('eoff', 'nn', 'esrc', 'edst', 'efeat')}); return r


def sub_arrays(a, ix):
    """입력 배열에서 묶음 ix 만 뽑음(eoff 다시 셈)."""
    ne = np.diff(a['eoff']); ei = np.concatenate([np.arange(a['eoff'][i], a['eoff'][i + 1]) for i in ix]); out = {}
    for k, v in a.items():
        out[k] = np.r_[0, np.cumsum(ne[ix])].astype(np.int64) if k == 'eoff' else (v[ix] if len(v) == len(ne) else v[ei])
    return out


def ledger(full, log):
    """tmp_ledger(날 0 ~ 74) + (full 이면) 원본 날 75 ~ 끝 줄을 원본 차례로 이어 붙임 → 세 종류 지움. 돌려줌: 지운 뒤 원장 배열 · 원본 줄 번호 · 6유형 표시 · 계좌 수 · 덧(개수)."""
    meta = json.loads((F.LED / 'meta.json').read_text()); base = int(meta['base_min']); NA = int(meta['n_acct'])
    tmin, tsid, tdid, tlap, tlab = (np.load(F.LED / f'{n}.npy') for n in ('minute', 'sid', 'did', 'lap', 'lab')); N = len(tmin)
    NR, (rid, m, sk, dk, lap, lab) = F.read_raw_rows(base, -(1 << 40) if full else 0, (1 << 40) if full else F.TV_END, log)
    if full:
        assert len(m) == NR and int(m.min()) >= 0, '원본에 날 0 앞 줄이 있음 → 멈춤'
    tv = m < F.TV_END; order, uk = F.match_tmp_ledger(m[tv], sk[tv], dk[tv], lap[tv], lab[tv], tmin, tsid, tdid, tlap, tlab, NA); led_rid = rid[tv][order]; del order
    S = dict(원본_줄=int(NR), 날0_74_줄=N)
    if full:
        ie = np.flatnonzero(~tv); ke = np.unique(np.concatenate([sk[ie], dk[ie]])); newk = ke[~np.isin(ke, uk, assume_unique=True)]; KF = np.r_[uk, newk]; NAF = len(KF)

        def acct(k):
            p = np.minimum(np.searchsorted(uk, k), NA - 1); return np.where(uk[p] == k, p, NA + np.searchsorted(newk, k)).astype(np.int32)
        esid, edid = acct(sk[ie]), acct(dk[ie]); assert np.array_equal(KF[esid], sk[ie]) and np.array_equal(KF[edid], dk[ie]), '새 계좌 번호가 어긋남 → 멈춤'
        fmin = np.r_[tmin, m[ie].astype(np.int32)]; fsid = np.r_[tsid, esid]; fdid = np.r_[tdid, edid]; flap = np.r_[tlap, lap[ie]]; flab = np.r_[tlab, lab[ie]]; frid = np.r_[led_rid, rid[ie]]
        S.update(덧붙인_줄=int(len(ie)), 새_계좌=int(len(newk)), 마지막_날=int(fmin.max() // 1440)); del esid, edid, ke, KF
    else:
        fmin, fsid, fdid, flap, flab, frid, NAF = tmin, tsid, tdid, tlap, tlab, led_rid, NA
    del rid, m, sk, dk, lap, lab, tv
    assert int(fmin.max()) < (1 << 18), '분이 18비트를 넘음 → 멈춤'
    pl = pd.read_parquet(F.PLAB); six, three = F.six_and_three(pl); is6 = F.in_sorted(frid, six); is3 = F.in_sorted(frid, three)
    assert not (is6 & (flab == 0)).any() and not (is3 & (flab == 0)).any(), 'Patterns 줄인데 원본 세탁 표시가 0 → 멈춤'
    rem = (flab == 1) & ~is6
    assert np.array_equal(np.flatnonzero(rem[:N]), np.load(F.OUT / 'data/뺀_원장줄_trainval.npy')), '날 0 ~ 74 에서 지운 줄이 f1(학습 입력)과 다름 → 멈춤'
    tail = fmin >= (F.MAIN_END_DAY + 1) * 1440
    S.update(세탁_줄=int((flab == 1).sum()), 지운_줄=int(rem.sum()), 지운_BIPARTITE_STACK=int(is3.sum()), 지운_무패턴=int((rem & ~is3).sum()), 날97뒤_줄=int(tail.sum()),
             날97뒤_세탁_줄=int((tail & (flab == 1)).sum()), 날97뒤_지운_줄=int((tail & rem).sum()), 날75_96_지운_줄=int((rem & ~tail & (fmin >= F.TV_END)).sum()))
    keep = ~rem; L = dict(fmin=fmin[keep], fsid=fsid[keep], fdid=fdid[keep], flap=flap[keep], flab=flab[keep]); frid_k = frid[keep]; is6k = is6[keep]
    assert np.array_equal(L['flab'] == 1, is6k), '지운 뒤 원장의 세탁 거래가 6유형 줄과 다름 → 멈춤'
    return L, frid_k, NAF, pl, S


def main():
    dry = '--dry-val' in sys.argv
    H1 = F.h1mod(); C, T1 = H1.C, H1.T1; U11 = pd.read_parquet(F.OLD / 'data/단위.parquet'); tr_atts = set(U11.loc[U11['구간'] == 'train', 'att']); va_atts = set(U11.loc[U11['구간'] != 'train', 'att'])
    if dry:
        log = F.logger(F.OUT / 'logs/f4_dry_val.log'); log('[dry-val] test 안 엶 · 날 75 앞 줄만 · val 시도로 같은 길을 끝까지')
    else:
        F.check_fixed(); assert all((F.OUT / f'run/state_DONE_가_s{s}').exists() for s in F.SEEDS), '학습이 다 끝나지 않음 → 멈춤'
        assert json.loads((F.OUT / 'data/5_valcheck.json').read_text(encoding='utf-8'))['통과'], 'val 다시 내기 점검(f5 --valcheck)이 통과하지 않음 → 멈춤'
        assert (F.OUT / 'data/3_val_결과.json').exists(), 'val 채점(f3)이 아직 → 멈춤'
        assert not (F.SEAL / '입력_test').exists() and not (F.SEAL / 'state_DONE_test').exists(), 'test 입력 · 채점이 이미 있음 → 다시 돌지 않음'
        F.SEAL.mkdir(parents=True, exist_ok=True); log = F.logger(F.SEAL / 'f4_test_input.log'); want = F.PRE_SHA.read_text(encoding='utf-8').split()[0]
        with open(F.TOL, 'a', encoding='utf-8') as f:
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())} UTC] pid {os.getpid()} · (가) 판 · 세 종류(무패턴 · BIPARTITE · STACK) 지움 · 꼬리 포함 · train 부터 다시 학습한 판의 test 한 번"
                    f"(이사묶음 results/묶음단위_가_세종류뺌_꼬리포함_20261116/code/f4 · f5 · f6 · /data/shared/ibm-aml/HI-Large_Trans.csv 의 날 75 ~ 끝(2023-01-12) 줄을 train · val 원장 뒤에 이어 붙이고 세 종류를 지움 · "
                    f"입력자료/pattern_labels.parquet · 묶음단위_꼬리포함_test_20261112/data/test_SEALED/묶음_test_꼬리.npz · test_꼬리_확률.npz · 묶음단위_모델_20261111/data/test_SEALED/묶음_test.npz(견줌 · 읽기만)) · "
                    f"이유: 은총 님 11-16 지시('가' 모델 및 방식으로 bipartite · stack · 무패턴을 아예 삭제 · 트레인에도 벨리데이션에도 테스트에도 · 꼬리 기간 자르지 말고 train부터 test까지 돌려봐 · "
                    f"11-10 · 11-11 · 11-12 · 11-16 에 이어 다섯 번째 사용) · 쓰는 것: 묶음단위_가_세종류뺌_꼬리포함_20261116/data/test_SEALED/(입력 · 묶음표 · 확률 · 개수 · 기록) · "
                    f"tables/6_test_*.csv · data/6_test_결과.json · data/4_test_입력_점검.json(비율만) · test 개수는 data/test_SEALED/ · 채팅 답에만 · 사전기록 sha {want[:16]}… · "
                    f"기록 시각 {time.strftime('%Y-%m-%d %H:%M', time.gmtime(time.time() + 9 * 3600))} KST\n")
        log('TEST_OPENED.log 한 줄 적음 · test 를 엶')
    L, frid, NAF, pl, S = ledger(not dry, log); r2p = rid_index(frid); fmin, fsid, fdid, flap, flab = L['fmin'], L['fsid'], L['fdid'], L['flap'], L['flab']
    log(f'원장 · 세 종류 지움 끝(날 0 ~ 74 에서 지운 줄 = f1 과 같음){"" if dry else " · 개수는 봉인 기록에"}')
    pl6 = pl[pl['pattern_type'].isin(F.SIX)]
    if dry:
        atts = va_atts; P = build_P(pl6, atts, r2p, fmin, fsid, fdid, flap, only_in=True); U, G = T1.build(P)
        G0 = C.load_units(); assert np.array_equal(G0['att'], U11['att'].to_numpy()) and np.array_equal(G0['날'], U11['날'].to_numpy())
        vu = np.flatnonzero((U11['구간'] != 'train').to_numpy()); kv = U11['att'].to_numpy()[vu] * 1000 + U11['날'].to_numpy()[vu]; ku = U['att'].to_numpy() * 1000 + U['날'].to_numpy()
        o = np.argsort(kv); p = vu[o[np.searchsorted(kv[o], ku)]]; assert len(ku) == len(vu) and np.array_equal(U11['att'].to_numpy()[p] * 1000 + U11['날'].to_numpy()[p], ku), '[dry-val] 묶음 짝이 안 맞음'
        a0 = sub_arrays(dict(eoff=G0['eoff'], nn=G0['nn'], esrc=G0['esrc'], edst=G0['edst'], efeat=G0['efeat']), p)
        r = same_bundles(U, G, {'att': U11['att'].to_numpy()[p], '날': U11['날'].to_numpy()[p], 'y6': U11['y6'].to_numpy()[p], 'v6': U11['v6'].to_numpy()[p], '끝': U11['끝'].to_numpy()[p]}, a0)
        log(f'[dry-val] 묶음(pattern_labels 길) = 11-11 val 묶음: {r}'); assert all(r.values())
        A, X = H1.build_inputs(U, P[['att', 'minute', 'lpos']], fmin, fsid, fdid, flap, flab, NAF, log)
        a1 = sub_arrays(F.load_arrays(F.OUT / 'data/입력'), p); r2 = {k: bool(np.array_equal(A[k], a1[k])) for k in F.ARR}; log(f'[dry-val] 입력 = f1 의 val 입력: {r2}'); assert all(r2.values())
        log('[dry-val] 끝까지 돎 · 모두 같음'); return 0
    # ── test 시도 ──
    pos6 = r2p(pl6['edge_id'].to_numpy(np.int64)); assert (pos6 >= 0).all(), '6유형 줄이 원장에 없음 → 멈춤'
    last = pd.Series(fmin[pos6] // 1440, index=pl6['attempt_id'].to_numpy()).groupby(level=0).max(); atts = set(last.index[last >= 75].tolist())
    moved = atts & va_atts; ZT = np.load(F.TAILT / 'data/test_SEALED/묶음_test_꼬리.npz'); Z11 = np.load(F.OLD / 'data/test_SEALED/묶음_test.npz'); old_att = set(Z11['att'].tolist())
    assert not (atts & tr_atts), '점검 4: test 시도가 train 묶음에 있음 → 멈춤'
    assert moved == {a for a in va_atts if last[a] > F.MAIN_END_DAY} and len(moved) == 76, '점검 4: val 에서 옮겨 오는 시도가 꼬리로 이어지는 76시도와 다름 → 멈춤'
    assert old_att <= atts and atts == set(ZT['att'].tolist()), '점검 4: test 시도가 11-12 꼬리 포함 test 시도와 다름 → 멈춤'
    P = build_P(pl6, atts, r2p, fmin, fsid, fdid, flap); U, G = T1.build(P)
    r = same_bundles(U, G, {k: ZT[k] for k in ('att', '날', 'y6', 'v6', '끝')}, ZT); S['점검4_묶음'] = r; log(f'점검 4(test 묶음 = 11-12 꼬리 포함 test 묶음): {r}'); assert all(r.values()), '점검 4: test 묶음이 11-12 와 다름 → 멈춤'
    A, X = H1.build_inputs(U, P[['att', 'minute', 'lpos']], fmin, fsid, fdid, flap, flab, NAF, log); log('점검 5 통과(마감 뒤 거래 없음 · 씨앗 맨 앞 · 세탁 표시)')
    d = F.SEAL / '입력_test'; d.mkdir(parents=True)
    for nm in F.ARR:
        np.save(d / f'{nm}.npy', A[nm])
    # ── 묶음표 · 비율 ──
    trp = r2p(pl6.loc[pl6['attempt_id'].isin(tr_atts), 'edge_id'].to_numpy(np.int64)); trp = trp[trp >= 0]; tr_acc = np.zeros(NAF, bool); tr_acc[fsid[trp]] = True; tr_acc[fdid[trp]] = True
    off = A['eoff']; NB = len(U); ne = np.diff(off); own = A['m_own']; lau = A['m_laund']; n_in = X['n_in']; n = X['n']; seed_row = X['seed_row']; emin = A['e_min']; bid = np.repeat(np.arange(NB), ne)
    first = P.groupby('att')['날'].min(); U2 = U[COLS].copy(); U2['시도끝날'] = U2['att'].map(last).to_numpy(); U2['시도첫날'] = U2['att'].map(first).to_numpy(); U2['옛_test_시도'] = U2['att'].isin(old_att).to_numpy()
    U2['val_에서_옮겨옴'] = U2['att'].isin(moved).to_numpy(); U2['입력_거래'] = ne; U2['입력_계좌'] = A['nn']; U2['입력_세탁표시_거래'] = np.add.reduceat(lau.astype(np.int64), off[:-1]); U2['입력에_든_시도거래'] = n_in
    U2['씨앗계좌가_train시도에_나옴'] = tr_acc[fsid[seed_row]] | tr_acc[fdid[seed_row]]; U2.to_parquet(F.SEAL / '묶음표_test.parquet', index=False)
    tb = (U2['날'] > F.MAIN_END_DAY).to_numpy()
    pub = dict(점검=dict(점검1='통과(원본 날 0 ~ 74 줄 = tmp_ledger)', 점검2='통과(날 0 ~ 74 에서 지운 줄 = f1 · Patterns 줄의 세탁 표시 = 1)', 점검3='통과(지운 뒤 원장의 세탁 거래 = 6유형 줄뿐)',
                         점검4='통과(test 시도 · 묶음 = 11-12 꼬리 포함 test · train 과 겹침 없음 · val 에서 76시도)', 점검5='통과'),
               비율=dict(원장_줄_가운데_지운_몫=round(S['지운_줄'] / (len(frid) + S['지운_줄']), 5), 날97뒤_원장_줄_가운데_세탁_몫_지우기_전=round(S['날97뒤_세탁_줄'] / max(S['날97뒤_줄'], 1), 4),
                        날97뒤_원장_줄_가운데_세탁_몫_지운_뒤=round((S['날97뒤_세탁_줄'] - S['날97뒤_지운_줄']) / max(S['날97뒤_줄'] - S['날97뒤_지운_줄'], 1), 4),
                        날97뒤_묶음_몫=round(float(tb.mean()), 4), 날75앞_묶음_몫=round(float((U2['날'] < 75).mean()), 4), val_에서_옮겨온_시도의_묶음_몫=round(float(U2['val_에서_옮겨옴'].mean()), 4),
                        그_시도_거래가_입력에_든_몫_평균=round(float((n_in / n).mean()), 4), 다_든_묶음_몫=round(float((n_in == n).mean()), 4), 다_든_묶음_몫_날97뒤_묶음=round(float((n_in == n)[tb].mean()), 4) if tb.any() else None,
                        입력_가운데_그_시도_거래_몫=round(float(own.mean()), 5), 입력_가운데_다른_6유형_시도_거래_몫=round(float((lau & ~own).mean()), 5), 입력_가운데_정상_거래_몫=round(float((~lau).mean()), 5),
                        입력_가운데_정상_거래_몫_날97뒤_묶음=round(float((~lau)[tb[bid]].mean()), 5) if tb.any() else None, 입력_거래_가운데_날97뒤_거래_몫=round(float((emin >= (F.MAIN_END_DAY + 1) * 1440).mean()), 4),
                        씨앗_계좌가_train_시도에_나온_묶음_몫=round(float(U2['씨앗계좌가_train시도에_나옴'].mean()), 4)))
    S['test'] = dict(시도=len(atts), 옛_test_시도=len(old_att), val_에서_옮겨온_시도=len(moved), 묶음=NB, 입력_거래_합=int(len(own)), 입력_거래_가운데=float(np.median(ne)), 입력_거래_최대=int(ne.max()), 계좌_합=int(NAF))
    (F.SEAL / 'f4_결과_SEALED.json').write_text(json.dumps(dict(**S, 비율=pub['비율']), ensure_ascii=False, indent=1), encoding='utf-8')
    (F.OUT / 'data/4_test_입력_점검.json').write_text(json.dumps(pub, ensure_ascii=False, indent=1), encoding='utf-8'); log(f'끝 · {json.dumps(S, ensure_ascii=False)}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
