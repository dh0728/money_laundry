"""[5 · 확률] 새 (가) 가중치(씨앗 42 · 43 · 44 · val 로 고른 것 그대로)로 6칸 확률을 냄. GPU · 학습 없음. 2026-11-16 · 손은총 · Claude Code.
특징 · 추론 = 11-16 h_lib.features · as_data(= e3_train.py 52줄 식 · 금액 정규화는 학습.json 값) + f2_train.Net · predict.
쓰는 법: python3 code/f5_predict.py --valcheck → test 안 엶: val 묶음 전부를 이 길로 다시 내서 저장된 val 확률과 맞댐 → data/5_valcheck.json
        python3 code/f5_predict.py            → test 묶음(data/test_SEALED/입력_test) 확률 → data/test_SEALED/test확률.npz(한 번만)"""
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import torch  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
import f_lib as F  # noqa: E402
import f2_train as E  # noqa: E402  (Net · predict · Data 만 · main 은 돌지 않음)
sys.path.insert(0, str(F.GA16 / 'code'))
import h_lib as HL  # noqa: E402  (features · as_data 만 · g_lib 를 부르지 않음)


def run(a, ix, dev, log):
    out = {}
    for s in F.SEEDS:
        rd = F.OUT / f'run/가/seed{s}'; j = json.loads((rd / '학습.json').read_text(encoding='utf-8'))
        X = HL.features(a, j['금액_평균'], j['금액_표준편차'], a['m_own']); d = HL.as_data(E, a, X)
        model = E.Net().to(dev); model.load_state_dict(torch.load(rd / 'best.pt', map_location=dev)); out[s] = E.predict(model, d, ix, dev)
        log(f'씨앗 {s} 확률 냄(고른 epoch {j["고른_epoch"]})'); del X, d, model
    return out


def main():
    F.check_fixed(); assert all((F.OUT / f'run/state_DONE_가_s{s}').exists() for s in F.SEEDS), '학습이 다 끝나지 않음 → 멈춤'; dev = torch.device('cuda')
    if '--valcheck' in sys.argv:
        log = F.logger(F.OUT / 'logs/f5_valcheck.log'); a = F.load_arrays(F.OUT / 'data/입력'); U = pd.read_parquet(F.OUT / 'data/묶음표.parquet'); va = np.flatnonzero((U['구간'] != 'train').to_numpy())
        P = run(a, va, dev, log); res = {}
        for s in F.SEEDS:
            Z = np.load(F.OUT / f'run/가/seed{s}/val확률.npz'); assert (Z['ix'] == va).all()
            res[f'seed{s}'] = dict(확률_최대_차=float(np.abs(P[s] - Z['P']).max()), 답_같은_몫=float((P[s].argmax(1) == Z['P'].argmax(1)).mean()))
        res['통과'] = all(v['확률_최대_차'] < 1e-3 and v['답_같은_몫'] >= 0.999 for v in res.values()); (F.OUT / 'data/5_valcheck.json').write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding='utf-8')
        log(f'val 다시 내기: {json.dumps(res, ensure_ascii=False)}'); return 0 if res['통과'] else 1
    assert json.loads((F.OUT / 'data/5_valcheck.json').read_text(encoding='utf-8'))['통과'], 'val 다시 내기 점검이 통과하지 않음 → 멈춤'
    assert (F.SEAL / '입력_test').exists() and not (F.SEAL / 'state_DONE_test').exists() and not (F.SEAL / 'test확률.npz').exists(), 'test 입력이 없거나 확률 · 채점이 이미 있음 → 멈춤'
    log = F.logger(F.SEAL / 'f5_predict.log'); a = F.load_arrays(F.SEAL / '입력_test'); P = run(a, np.arange(len(a['eoff']) - 1), dev, log)
    np.savez_compressed(F.SEAL / 'test확률.npz', **{f'P_s{s}': P[s] for s in F.SEEDS}); log('끝')
    return 0


if __name__ == '__main__':
    sys.exit(main())
