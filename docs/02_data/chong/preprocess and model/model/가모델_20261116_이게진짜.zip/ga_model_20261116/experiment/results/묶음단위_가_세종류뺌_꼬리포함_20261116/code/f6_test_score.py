"""[6 · test 채점] 11-11 t1_test.py 의 score() 그대로(함수만) · 같은 test 묶음(꼬리 포함)의 11-11 첫 모델(11-12 꼬리 포함 test 때 낸 확률 · 봉인)과 견줌.
2026-11-16 · 손은총 · Claude Code. CPU · 학습 없음. 개수가 든 결과는 data/test_SEALED/ · 봉인 밖(tables/6_test_*.csv · data/6_test_결과.json)에는 비율만. 끝나면 state_DONE_test.
쓰는 법: python3 code/f6_test_score.py"""
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
import f_lib as F  # noqa: E402
sys.path.insert(0, str(F.OLD / 'code'))
import g_lib as C  # noqa: E402
import t1_test as T1  # noqa: E402  (score · rule_table 만 · main 은 돌리지 않음)

S1, S2 = '(1) 모든 묶음 · 보이는 대로', '(2) 끝난 시도 · 원래 유형'; NEW, M11 = '새 (가) · 세 종류 뺌 · 꼬리 포함', '11-11 첫 모델(그 시도 거래만 · 같은 test 묶음)'
KEEP = ('모델', '규칙', '차이'); ALLOWED = {75, 96, 97, 100, 200, 2000, 2127}   # 봉인 밖 파일에 나와도 되는 정수(날 번호 · 설정 · val 시도 수)


def subsets(U):
    yv = U['v6'].to_numpy(); yo = U['y6'].to_numpy(); end = U['끝'].to_numpy(); vis = U['att'].isin(set(U.loc[end & (yv == yo), 'att'])).to_numpy()
    return {S1: (np.ones(len(U), bool), yv), '(1) 가운데 덜 끝난 묶음': (~end, yv), '(1) 가운데 끝난 시도': (end, yv), S2: (end, yo),
            '(2) 가운데 끝까지 본 모양이 원래 유형과 같은 시도(곁)': (end & vis, yo), '(2) 가운데 끝까지 본 모양이 원래 유형과 다른 시도(곁)': (end & ~vis, yo)}


def diff(U, PA, PB):
    """앞 판 − 뒤 판(씨앗 3개 평균 · 시도 단위 부트스트랩 2,000번 · 11-16 h3_score.diff 와 같은 식)."""
    ua, ai = np.unique(U['att'].to_numpy(), return_inverse=True); cnt = C.boot_counts(len(ua)); out = {}
    q = lambda a: [round(float(v), 4) for v in np.percentile(a, [2.5, 97.5])]  # noqa: E731
    for nm, (m, y) in subsets(U).items():
        ix = np.flatnonzero(m)
        if len(ix) == 0:
            continue
        yy = y[ix]; W = cnt[:, ai[ix]].astype(np.float64); a = {s: PA[s][ix].argmax(1).astype(np.int64) for s in C.SEEDS}; b = {s: PB[s][ix].argmax(1).astype(np.int64) for s in C.SEEDS}
        pt = np.mean([C.macro(yy, a[s]) - C.macro(yy, b[s]) for s in C.SEEDS], 0); bd = np.stack([np.mean([C.macro(yy, a[s], w) - C.macro(yy, b[s], w) for s in C.SEEDS], 0) for w in W])
        out[nm] = dict(정밀도=round(float(pt[0]), 4), 정밀도_95=q(bd[:, 0]), 재현율=round(float(pt[1]), 4), 재현율_95=q(bd[:, 1]), 같은답몫=round(float(np.mean([(a[s] == b[s]).mean() for s in C.SEEDS])), 4))
    return out


def scan(obj, path=''):
    """봉인 밖에 쓸 값 가운데 50 이상 정수(개수일 수 있는 값)를 찾음."""
    bad = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            bad += scan(v, f'{path}/{k}')
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            bad += scan(v, f'{path}[{i}]')
    elif isinstance(obj, (int, np.integer)) and not isinstance(obj, bool) and obj >= 50 and int(obj) not in ALLOWED:
        bad.append(f'{path}={obj}')
    elif isinstance(obj, float) and obj.is_integer() and obj >= 50 and int(obj) not in ALLOWED:
        bad.append(f'{path}={obj}')
    return bad


def main():
    F.check_fixed(); assert not (F.SEAL / 'state_DONE_test').exists(), 'test 는 이미 한 번 채점함 → 다시 돌지 않음'; log = F.logger(F.SEAL / 'f6_test_score.log')
    U = pd.read_parquet(F.SEAL / '묶음표_test.parquet'); Z = np.load(F.SEAL / 'test확률.npz'); PM = {s: Z[f'P_s{s}'] for s in C.SEEDS}
    ZT = np.load(F.TAILT / 'data/test_SEALED/묶음_test_꼬리.npz'); assert np.array_equal(ZT['att'], U['att'].to_numpy()) and np.array_equal(ZT['날'], U['날'].to_numpy()), '11-12 묶음과 차례가 다름 → 멈춤'
    ZP = np.load(F.TAILT / 'data/test_SEALED/test_꼬리_확률.npz'); P11 = {s: ZP[f'P_가_s{s}'] for s in C.SEEDS}; assert all(len(PM[s]) == len(U) == len(P11[s]) for s in C.SEEDS)
    rule, fb = T1.rule_table(); p_rule = U['꼴'].map(rule).fillna(fb).to_numpy(np.int64)
    end = U['끝'].to_numpy(); tail_b = (U['날'] > F.MAIN_END_DAY).to_numpy(); tail_a = (U['시도끝날'] > F.MAIN_END_DAY).to_numpy(); in_old = U['옛_test_시도'].to_numpy()
    allin = (U['입력에_든_시도거래'] == U['거래수']).to_numpy(); seen = U['씨앗계좌가_train시도에_나옴'].to_numpy()
    GROUPS = [('가. 꼬리까지 넣은 test 전부', np.ones(len(U), bool), None), ('나. 옛 test 와 같은 시도만(거래는 원본 끝까지)', in_old, None), ('라. 마지막 거래가 11-05 까지인 시도', ~tail_a, None),
              ('마. 마지막 거래가 11-06 뒤인 시도', tail_a, None), ('바. 11-05 까지의 묶음만(곁 · 성적표 (1)만)', ~tail_b, (S1,)), ('사. 11-06 뒤의 묶음만(곁 · 성적표 (1)만)', tail_b, (S1,)),
              ('아. 그 시도 거래가 입력에 다 든 묶음', allin, None), ('자. 그 시도 거래가 입력에 다 들지 않은 묶음', ~allin, None),
              ('차. 씨앗 계좌가 train 시도에 나온 묶음', seen, None), ('카. 씨앗 계좌가 train 시도에 안 나온 묶음', ~seen, None)]
    R, D = {NEW: {}, M11: {}}, {}
    for g, m, only in GROUPS:
        ix = np.flatnonzero(m)
        if len(ix) == 0:
            continue
        Ug = U.iloc[ix].reset_index(drop=True)
        for pn, P in ((NEW, PM), (M11, P11)):
            res = T1.score(Ug, {s: P[s][ix] for s in C.SEEDS}, p_rule[ix]); R[pn][g] = {k: v for k, v in res.items() if only is None or k in only}
        if g[0] in '가나':
            D[g] = diff(Ug, {s: PM[s][ix] for s in C.SEEDS}, {s: P11[s][ix] for s in C.SEEDS})
    ref = json.loads((F.TAILT / 'data/2_test_꼬리_결과.json').read_text(encoding='utf-8'))['(가) 11-11 가중치 그대로']['가. 꼬리까지 넣은 test 전부']
    got = {k: (R[M11]['가. 꼬리까지 넣은 test 전부'][k]['모델']['정밀도'], R[M11]['가. 꼬리까지 넣은 test 전부'][k]['모델']['재현율']) for k in (S1, S2)}
    want = {k: (ref[k]['모델']['정밀도'], ref[k]['모델']['재현율']) for k in (S1, S2)}
    assert got == want, f'점검 6: 11-11 첫 모델을 다시 채점한 값 {got} 이 11-12 보고 값 {want} 과 다름 → 멈춤'
    log(f'점검 6 통과(11-11 첫 모델 다시 채점 = 11-12 꼬리 포함 test 보고 값 {want})')
    n = U['att'].nunique()
    info = dict(시도=int(n), 묶음=len(U), 꼴이_train_에_없는_묶음=int((~U['꼴'].isin(rule)).sum()), 끝난시도_모양이_원래유형과_같은_수=int((U.loc[end, 'v6'] == U.loc[end, 'y6']).sum()))
    (F.SEAL / '6_test_결과_SEALED.json').write_text(json.dumps(dict(자료=info, 성적표=R, 차이=D), ensure_ascii=False, indent=1), encoding='utf-8')
    # ── 봉인 밖: 비율만 ──
    pub = {pn: {g: {nm: dict({k: v[k] for k in KEEP}, 묶음_몫=round(v['묶음'] / len(U), 4), 유형별=[{k: t[k] for k in ('유형', '정답몫', '모델_정밀도', '모델_재현율', '규칙_정밀도', '규칙_재현율')} for t in v['유형별']])
                        for nm, v in res.items()} for g, res in RR.items()} for pn, RR in R.items()}
    pub['새 (가) − 11-11 첫 모델'] = D
    pub['자료_비율'] = dict(끝난시도_가운데_끝까지_본_모양이_원래유형과_같은_몫=round(info['끝난시도_모양이_원래유형과_같은_수'] / n, 4), 마지막_거래가_11_06_뒤인_시도_몫=round(float(U.loc[end, '시도끝날'].gt(F.MAIN_END_DAY).mean()), 4),
                         날97뒤_묶음_몫=round(float(tail_b.mean()), 4), 날75앞_묶음_몫=round(float((U['날'] < 75).mean()), 4), 꼴이_train_에_없는_묶음_몫=round(info['꼴이_train_에_없는_묶음'] / len(U), 4),
                         원래유형_시도_몫={t: round(float((U.loc[end, 'y6'] == i).mean()), 4) for i, t in enumerate(C.TY)}, val_에서_옮겨온_시도_몫=round(float(U.loc[end, 'val_에서_옮겨옴'].mean()), 4),
                         옛_test_시도_몫=round(float(U.loc[end, '옛_test_시도'].mean()), 4))
    mrows, trows, drows = [], [], []
    for pn in (NEW, M11):
        for g, res in pub[pn].items():
            for nm, v in res.items():
                m, r, d = v['모델'], v['규칙'], v['차이']
                mrows.append({'판': pn, '시도 묶음': g, '성적표': nm, '묶음 몫': v['묶음_몫'], '정밀도': m['정밀도'], '정밀도 95%': str(m['정밀도_95']), '재현율': m['재현율'], '재현율 95%': str(m['재현율_95']),
                              '맞은 몫': m['맞은몫'], 'macro-AP': m['macroAP'], '정밀도 씨앗 SD': m['정밀도_SD'], '재현율 씨앗 SD': m['재현율_SD']})
                if pn == NEW:
                    mrows.append({'판': '모양 규칙(학습 없음)', '시도 묶음': g, '성적표': nm, '묶음 몫': v['묶음_몫'], '정밀도': r['정밀도'], '정밀도 95%': str(r['정밀도_95']), '재현율': r['재현율'], '재현율 95%': str(r['재현율_95']), '맞은 몫': r['맞은몫']})
                    if g.startswith('가.'):
                        trows += [{'성적표': nm, '유형': t['유형'], '정답 가운데 몫': t['정답몫'], '새 (가) 정밀도': t['모델_정밀도'], '새 (가) 재현율': t['모델_재현율'],
                                   '11-11 정밀도': t11['모델_정밀도'], '11-11 재현율': t11['모델_재현율'], '규칙 정밀도': t['규칙_정밀도'], '규칙 재현율': t['규칙_재현율']} for t, t11 in zip(v['유형별'], pub[M11][g][nm]['유형별'])]
    for g, res in D.items():
        for nm, v in res.items():
            drows.append({'시도 묶음': g, '성적표': nm, '정밀도 차(새 (가) − 11-11)': v['정밀도'], '정밀도 95%': str(v['정밀도_95']), '재현율 차': v['재현율'], '재현율 95%': str(v['재현율_95']), '두 판이 같은 답을 낸 몫': v['같은답몫']})
    tabs = [pd.DataFrame(mrows), pd.DataFrame(trows), pd.DataFrame(drows)]; bad = scan(pub) + [f'표 {i}: {x}' for i, t in enumerate(tabs) for x in scan(t.select_dtypes('number').to_numpy().ravel().tolist())]
    assert not bad, f'봉인 밖에 쓸 값에 개수일 수 있는 정수가 있음 → 멈춤: {bad[:5]}'
    (F.OUT / 'tables').mkdir(exist_ok=True); tabs[0].to_csv(F.OUT / 'tables/6_test_주표.csv', index=False, encoding='utf-8-sig'); tabs[1].to_csv(F.OUT / 'tables/6_test_유형별.csv', index=False, encoding='utf-8-sig')
    tabs[2].to_csv(F.OUT / 'tables/6_test_차이.csv', index=False, encoding='utf-8-sig'); (F.OUT / 'data/6_test_결과.json').write_text(json.dumps(pub, ensure_ascii=False, indent=1), encoding='utf-8')
    (F.SEAL / 'state_DONE_test').write_text('done\n'); log('끝 · 표 · 결과 씀 · state_DONE_test')
    for g in ('가. 꼬리까지 넣은 test 전부', '나. 옛 test 와 같은 시도만(거래는 원본 끝까지)'):
        for k in (S1, S2):
            a, b, d = R[NEW][g][k]['모델'], R[M11][g][k]['모델'], D[g][k]
            log(f"{g} · {k}: 새 (가) {a['정밀도']:.4f} / {a['재현율']:.4f} [{a['정밀도_95'][0]:.4f}, {a['정밀도_95'][1]:.4f}] / [{a['재현율_95'][0]:.4f}, {a['재현율_95'][1]:.4f}] · 맞은 몫 {a['맞은몫']} | "
                f"11-11 {b['정밀도']:.4f} / {b['재현율']:.4f} | 차 {d['정밀도']:+.4f} {d['정밀도_95']} / {d['재현율']:+.4f} {d['재현율_95']}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
