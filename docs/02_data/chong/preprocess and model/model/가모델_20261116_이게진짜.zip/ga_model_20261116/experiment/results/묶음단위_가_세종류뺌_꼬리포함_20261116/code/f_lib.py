"""[(가) · 세 종류 뺌 · 꼬리 포함 · 공통] 2026-11-16 · 손은총 · Claude Code. 사전기록 = ../사전기록_가_세종류뺌_꼬리포함_20261116.md
세 종류 = 무패턴(원본 세탁 표시가 1 인데 Patterns 파일에 없는 거래) · BIPARTITE · STACK(Patterns 파일의 두 유형).
지우는 규칙(한 줄): 원본 세탁 표시가 1 이고, 6유형 시도의 Patterns 줄(pattern_labels.parquet 의 edge_id)이 아닌 거래를 원장에서 지움.
불러오기만 해서는 아무것도 읽지 않음(경로 · 함수만). g_lib 를 불러오지 않음(GPU 를 가리지 않음) · h1mod() 를 부르면 g_lib 가 불려 그 프로세스의 GPU 가 가려짐(CPU 코드에서만 부름)."""
import hashlib
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent; OUT = HERE.parent; RES = OUT.parent
EXP = RES / '묶음단위_주변거래_학습_20261112'          # 11-12 학습(옛 (가) · e1_build · e3_train)
OLD = RES / '묶음단위_모델_20261111'                  # 11-11(g_lib · t1_test · 단위.parquet)
SPL = RES / '끝난날나눔_실험_20261106'                 # 행_trainval.parquet
TAILT = RES / '묶음단위_꼬리포함_test_20261112'        # 11-12 꼬리 포함 test(견줌 · 봉인 파일은 test 를 연 뒤에만 읽음)
GA16 = RES / '묶음단위_주변거래_test_가_20261116'      # 11-16 (가) test 코드(h1 의 hexkey · build_inputs)
LED = RES / 'R_사건학습_20261103/data/tmp_ledger'; RAW = Path('/data/shared/ibm-aml/HI-Large_Trans.csv')
PLAB = RES.parent / '입력자료/pattern_labels.parquet'
SEAL = OUT / 'data/test_SEALED'; SEEDS = (42, 43, 44); PANEL = '가'; NF = 8
PRE = OUT / '사전기록_가_세종류뺌_꼬리포함_20261116.md'; PRE_SHA = OUT / 'data/사전기록_sha256.txt'; CODE_SHA = OUT / 'data/코드_sha256_고정시.txt'
TOL = Path.home() / 'workspace/TEST_OPENED.log'
ARR = ('eoff', 'nn', 'esrc', 'edst', 'e_lap', 'e_min', 'e_hop', 'm_own', 'm_laund', 'seed_u', 'seed_v', 'cut', 'seed_min')
SIX = ('FAN-OUT', 'FAN-IN', 'CYCLE', 'SCATTER-GATHER', 'GATHER-SCATTER', 'RANDOM'); THREE_P = ('BIPARTITE', 'STACK')
CN9 = ['FAN-OUT', 'FAN-IN', 'CYCLE', 'SCATTER-GATHER', 'GATHER-SCATTER', 'BIPARTITE', 'STACK', 'RANDOM']   # y9 차례(11-12 k_lib.py 와 같음)
TV_END = 75 * 1440; VAL0 = 58 * 1440; MAIN_END_DAY = 96                                                  # 날 75 = 10-15 · 날 58 = 09-28 · 날 96 = 11-05(08-01 = 날 0)


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def logger(path):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True); t0 = time.time()

    def log(m):
        s = f'[{time.strftime("%H:%M:%S", time.gmtime(time.time() + 9 * 3600))} KST · {time.time() - t0:7.1f}초] {m}'; print(s, flush=True)
        with open(path, 'a', encoding='utf-8') as f:
            f.write(s + '\n')
    return log


def check_fixed():
    """사전기록 · 코드가 고정 때와 같은지(학습 · test 단계마다 부름)."""
    assert PRE.exists() and PRE_SHA.exists() and CODE_SHA.exists(), '사전기록 · 코드 고정이 안 됨 → 멈춤'
    assert sha(PRE) == PRE_SHA.read_text(encoding='utf-8').split()[0], '사전기록 sha256 이 고정 때와 다름 → 멈춤'
    for ln in CODE_SHA.read_text(encoding='utf-8').splitlines():
        h, p = ln.split(maxsplit=1); assert sha(RES / p) == h, f'고정 때와 다른 코드 → 멈춤: {p}'


def load_arrays(d):
    return {n: np.load(Path(d) / f'{n}.npy') for n in ARR}


def h1mod():
    """11-16 h1_test_input.py 를 모듈로 부름(main 은 돌지 않음): hexkey · build_inputs(= e1_build 의 넓히기 함수 · B1.SH = 18). g_lib 를 부르므로 GPU 가 가려짐."""
    p = str(GA16 / 'code')
    if p not in sys.path:
        sys.path.insert(0, p)
    import h1_test_input as H1  # noqa: E402
    assert Path(H1.__file__).resolve() == GA16 / 'code/h1_test_input.py' and H1.B1.SH == 18
    return H1


def read_raw_rows(base, lo, hi, log):
    """h1_test_input.read_raw(= 17_SALT_R read_transactions)와 같은 식으로 원본 CSV 를 읽되, 분이 [lo, hi) 인 줄만 남김(그 밖의 줄은 덩이마다 바로 버림).
    돌려줌: 원본 줄 번호(머리줄 뺀 0부터 · eid · edge_id 와 같은 번호) · 분(2022-08-01 0시부터) · 보낸 / 받는 계좌 열쇠 · lap = ln(1 + 낸 금액) · 세탁 표시."""
    import pyarrow as pa
    import pyarrow.compute as pc
    import pyarrow.csv as pv
    H1 = h1mod()
    with open(RAW, 'rb') as f:
        first = f.readline().decode('utf-8', 'replace').rstrip('\r\n')
    ncol = len(first.split(',')); assert ncol >= 11; header = not first[:4].isdigit(); names = [f'c{i}' for i in range(ncol)]
    ro = pv.ReadOptions(column_names=names, skip_rows=1 if header else 0, block_size=1 << 26)
    co = pv.ConvertOptions(include_columns=['c0', 'c1', 'c2', 'c3', 'c4', 'c7', 'c10'], column_types={c: pa.string() for c in names}, strings_can_be_null=False)
    out = {k: [] for k in ('rid', 'm', 'sk', 'dk', 'lap', 'lab')}; n0 = 0
    for b in pv.open_csv(RAW, read_options=ro, convert_options=co):
        ts = pc.strptime(b.column('c0'), format='%Y/%m/%d %H:%M', unit='s'); m = ts.cast(pa.int64()).to_numpy(zero_copy_only=False) // 60 - base
        keep = (m >= lo) & (m < hi); ix = np.flatnonzero(keep)
        if len(ix):
            bb = b.filter(pa.array(keep)); fb = bb.column('c1').cast(pa.int64()).to_numpy(zero_copy_only=False); tb = bb.column('c3').cast(pa.int64()).to_numpy(zero_copy_only=False)
            assert (fb >= 0).all() and (fb < (1 << 23)).all() and (tb >= 0).all() and (tb < (1 << 23)).all()
            out['rid'].append(n0 + ix.astype(np.int64)); out['m'].append(m[ix]); out['sk'].append((fb << 40) | H1.hexkey(bb.column('c2'))); out['dk'].append((tb << 40) | H1.hexkey(bb.column('c4')))
            out['lap'].append(np.log1p(bb.column('c7').cast(pa.float64()).to_numpy(zero_copy_only=False)).astype(np.float32)); out['lab'].append(bb.column('c10').cast(pa.int8()).to_numpy(zero_copy_only=False))
        n0 += b.num_rows
    log(f'원본 읽기 끝 · 머리줄 {"있음" if header else "없음"} · 분 [{lo}, {hi}) 줄만 남김')
    return n0, tuple(np.concatenate(out[k]) for k in ('rid', 'm', 'sk', 'dk', 'lap', 'lab'))


def match_tmp_ledger(m, sk, dk, lap, lab, tmin, tsid, tdid, tlap, tlab, NA):
    """날 0 ~ 74 원본 줄(원본 차례)을 tmp_ledger 와 줄마다 맞댐. tmp_ledger 차례 = train(날 0 ~ 57) 줄을 원본 차례로 → val(58 ~ 74) 줄을 원본 차례로(11-16 h1 점검 2).
    돌려줌: order(원장 줄 → 날 0 ~ 74 원본 줄 자리) · uk(계좌 열쇠 · 원장 계좌 번호 = 이 배열의 자리)."""
    assert len(m) == len(tmin), '날 0 ~ 74 줄 수가 tmp_ledger 와 다름 → 멈춤'
    uk = np.unique(np.concatenate([sk, dk])); assert len(uk) == NA, '계좌 수가 tmp_ledger 와 다름 → 멈춤'
    order = np.r_[np.flatnonzero(m < VAL0), np.flatnonzero(m >= VAL0)]
    ok = (np.array_equal(m[order].astype(np.int32), tmin) and np.array_equal(lap[order], tlap) and np.array_equal(lab[order], tlab)
          and np.array_equal(np.searchsorted(uk, sk[order]).astype(np.int32), tsid) and np.array_equal(np.searchsorted(uk, dk[order]).astype(np.int32), tdid))
    assert ok, '원본 날 0 ~ 74 줄이 tmp_ledger 와 줄마다 맞지 않음 → 멈춤'
    return order, uk


def six_and_three(pl):
    """pattern_labels → (6유형 시도 줄의 원본 줄 번호 · BIPARTITE · STACK 줄의 원본 줄 번호) · 둘 다 정렬됨."""
    assert set(pl['pattern_type'].unique()) == set(CN9) and pl['edge_id'].is_unique
    return np.sort(pl.loc[pl['pattern_type'].isin(SIX), 'edge_id'].to_numpy(np.int64)), np.sort(pl.loc[pl['pattern_type'].isin(THREE_P), 'edge_id'].to_numpy(np.int64))


def in_sorted(x, s):
    """x 의 값마다 정렬된 s 에 있는지(np.isin 과 같은 답 · 큰 x 에서 빠름)."""
    p = np.minimum(np.searchsorted(s, x), len(s) - 1); return s[p] == x
