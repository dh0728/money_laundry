#!/bin/bash
# 사전기록 3절 2: (가) 판 씨앗 42 · 43 · 44 를 GPU 한 장에서 함께 학습(프로세스마다 CPU 1스레드). 하나라도 실패하면 run/state_STOP 에 까닭.
# 2026-11-16 · 손은총 · Claude Code. 쓰는 법: tmux new -d -s ga_three "bash code/run_train.sh"
cd /tmp || exit 1
export PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
W="$(cd "$(dirname "$0")/.." && pwd)"; PY=/home/eunchong/workspace/.venv-exp/bin/python
mkdir -p "$W/run" "$W/logs"; pids=(); seeds=()
for s in 42 43 44; do
  [ -f "$W/run/state_DONE_가_s$s" ] && { echo "이미 끝남 $s"; continue; }
  "$PY" "$W/code/f2_train.py" 가 "$s" > "$W/logs/f2_가_s${s}_화면.txt" 2>&1 & pids+=($!); seeds+=("$s")
done
rc=0
for i in "${!pids[@]}"; do
  wait "${pids[$i]}" || { echo "실패: 씨앗 ${seeds[$i]}" >> "$W/run/state_STOP"; rc=1; }
done
[ $rc -eq 0 ] && echo done > "$W/run/state_DONE_train"
exit $rc
