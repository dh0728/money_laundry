"""[묶음 단위 유형분류 · 1단계 묶음 만들기] 2026-11-11 · Claude Code(세션 fe691014). 학습 · 추론 없음.
정의 한 장 2절 그대로: 단위 = (시도, 그 시도에 거래가 있는 날) · 묶음 = 그 시도의 거래 가운데 그날 마감 앞 것 전부(14일로 안 자름) · 정답 = 보이는 모양(V).
읽는 것(읽기만): 끝난날나눔_실험_20261106/data/행_trainval.parquet(train · val 배정 패턴 행 · sha256 확인) · R_사건학습_20261103/data/tmp_ledger 의 minute · sid · did · lap(그 행의 lpos 줄만).
  - train 배정 노이즈 796시도는 이 파일에 '없음'으로 빠져 있음(결정 6) · val 배정 노이즈는 들어 있음.
  - test_SEALED · test 원장 · 나눔.parquet · pos_attempt.npz 는 열지 않음.
화살표 열 3개: 금액 lap = ln(1 + Amount Paid) · 묶음 첫 거래부터 지난 날 ln(1 + 일) · 묶음 마지막 거래까지 남은 날 ln(1 + 일). 달력 날 · 계좌 번호 · 은행 번호는 넣지 않음.
출력: data/묶음.npz · data/단위.parquet · data/1_자료_요약.json · tables/1_정답칸_분포.csv · logs/g1_data.log
"""
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import g_lib as C  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

log = C.logger(C.OUTD / 'logs/g1_data.log')


def main():
    log('시작'); h = hashlib.sha256(C.ROWS.read_bytes()).hexdigest(); assert h == C.ROWS_SHA, '행_trainval sha256 다름 → 멈춤'
    T = pd.read_parquet(C.ROWS); assert len(T) == 103978 and set(T['구간'].unique()) == {'train', 'val'}
    P = T[T['y9'] < 8].copy(); assert set(P['y9'].unique()) == set(C.KS)
    mi = np.load(C.LED / 'minute.npy', mmap_mode='r'); si = np.load(C.LED / 'sid.npy', mmap_mode='r'); di = np.load(C.LED / 'did.npy', mmap_mode='r'); la = np.load(C.LED / 'lap.npy', mmap_mode='r')
    lp = P['lpos'].to_numpy(); o = np.argsort(lp)
    for nm, arr in (('m2', mi), ('src', si), ('dst', di), ('lap', la)):
        v = np.empty(len(lp), arr.dtype); v[o] = np.asarray(arr[lp[o]]); P[nm] = v
    assert (P['m2'].to_numpy().astype(np.int64) == P['minute'].to_numpy()).all(), '원장 분 ≠ 행 분'
    assert int(P['minute'].max()) < 75 * 1440 and int(P['날'].max()) <= 74, 'test 기간 줄이 섞임 → 멈춤'
    assert P.groupby('att')['구간'].nunique().max() == 1 and P.groupby('att')['y9'].nunique().max() == 1
    P = P.sort_values(['att', 'minute', 'lpos'], kind='stable').reset_index(drop=True)
    U, esrc, edst, efeat, eoff, nn = [], [], [], [], [0], []
    for a, g in P.groupby('att', sort=False):
        k = int(g['y9'].iloc[0]); seg = g['구간'].iloc[0]; s = g['src'].to_numpy(); d = g['dst'].to_numpy(); ts = g['minute'].to_numpy().astype(np.int64); day = g['날'].to_numpy().astype(int); lap = g['lap'].to_numpy().astype(np.float64)
        assert (np.diff(ts) >= 0).all() and (np.diff(day) >= 0).all() and (day == ts // 1440).all()
        orgs = sorted(set(s[ts == ts.min()].tolist())); f0, fl = int(day.min()), int(day.max())
        nz_va = bool(g['노이즈표시_val1029'].any()); nz_tr = bool(g['노이즈표시_train1029'].any())
        for D in np.unique(day):
            n = int((day <= D).sum()); assert (day[:n] <= D).all() and int(ts[:n].max()) < (int(D) + 1) * 1440          # 마감 앞 거래만
            ss, dd = s[:n].tolist(), d[:n].tolist(); f = C.flags(ss, dd, orgs); v = C.label_v(k, f, n)
            loc = {}
            for x in ss + dd:
                if x not in loc:
                    loc[x] = len(loc)
            esrc.extend(loc[x] for x in ss); edst.extend(loc[x] for x in dd)
            tf = np.log1p((ts[:n] - ts[0]) / 1440.0); tl = np.log1p((ts[n - 1] - ts[:n]) / 1440.0)
            efeat.append(np.stack([lap[:n], tf, tl], 1)); eoff.append(eoff[-1] + n); nn.append(len(loc))
            U.append(dict(att=int(a), y9=k, 구간=seg, 날=int(D), 나이=int(D) - f0, 끝=bool(D == fl), 거래수=n, 계좌수=len(loc), V9=v, y6=C.Y9_TO_6[k], v6=C.Y9_TO_6[v], 꼴=C.pat(f, n),
                          노이즈표시_val1029=nz_va, 노이즈표시_train1029=nz_tr))
    U = pd.DataFrame(U); U['단위'] = np.arange(len(U)); out = {}
    for seg in ('train', 'val'):
        q = U[U['구간'] == seg]; e = C.EXPECT[seg]; got = dict(시도=int(q['att'].nunique()), 단위=len(q), 행=int(q[q['끝']]['거래수'].sum()))
        assert got == e, f'{seg} 수가 기대와 다름 → 멈춤: {got} vs {e}'; out[seg] = got
    vt = U[U['구간'] == 'train']['v6'].map(dict(enumerate(C.TY))).value_counts().to_dict()
    assert vt == C.EXPECT_V_TRAIN, f'train 정답 칸 분포가 정의 한 장과 다름 → 멈춤: {vt}'
    assert not (U[U['구간'] == 'train']['노이즈표시_train1029']).any(), 'train 에 노이즈 표시 시도가 들어 있음 → 멈춤'
    rows = []
    for seg in ('train', 'val'):
        for nm, m in (('모든 묶음', np.ones(len(U), bool)), ('끝난 시도(마지막 날 묶음)', U['끝'].to_numpy()), ('덜 끝난 묶음', ~U['끝'].to_numpy())):
            q = U[(U['구간'] == seg) & m]; r = {'구간': seg, '묶음': nm, '수': len(q), '시도': int(q['att'].nunique())}
            for i, t in enumerate(C.TY):
                r[f'정답 {t}'] = int((q['v6'] == i).sum())
            for i, t in enumerate(C.TY):
                r[f'원본 {t}'] = int((q['y6'] == i).sum())
            r['정답 = 원본 유형인 몫'] = round(float((q['v6'] == q['y6']).mean()), 4); rows.append(r)
    pd.DataFrame(rows).to_csv(C.OUTD / 'tables/1_정답칸_분포.csv', index=False, encoding='utf-8-sig')
    E = np.concatenate(efeat).astype(np.float32)
    np.savez_compressed(C.OUTD / 'data/묶음.npz', eoff=np.array(eoff, np.int64), nn=np.array(nn, np.int32), esrc=np.array(esrc, np.int32), edst=np.array(edst, np.int32), efeat=E,
                        att=U['att'].to_numpy(np.int64), y6=U['y6'].to_numpy(np.int64), v6=U['v6'].to_numpy(np.int64), is_train=(U['구간'] == 'train').to_numpy(), 끝=U['끝'].to_numpy(), 날=U['날'].to_numpy(np.int32),
                        nz_va=U['노이즈표시_val1029'].to_numpy())
    U.to_parquet(C.OUTD / 'data/단위.parquet', index=False)
    out.update(화살표=int(len(E)), 한묶음_거래수_최대=int(U['거래수'].max()), 한묶음_계좌수_최대=int(U['계좌수'].max()), 행_trainval_sha256=h,
               val_노이즈표시_val1029_시도=int(U[(U['구간'] == 'val') & U['노이즈표시_val1029']]['att'].nunique()), val_꼴_가운데_train_에_없는_것=sorted(set(U[U['구간'] == 'val']['꼴']) - set(U[U['구간'] == 'train']['꼴'])))
    (C.OUTD / 'data/1_자료_요약.json').write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8'); log(f'끝 · {json.dumps(out, ensure_ascii=False)}')


if __name__ == '__main__':
    sys.exit(main())
