"""[묶음 단위 유형분류 · 공통] 2026-11-11 · Claude Code(세션 fe691014). 정의 = RES/묶음단위_정의_20261111/정의_묶음단위_유형분류_20261111.md.
- 조건(flags) · 정답(V) 은 RES/묶음단위_정의_20261111/code/c1_train_counts.py 와 같은 글자(그쪽은 b1_count.py:45-103 에서 옮긴 것).
- 모델 BundleGNN = 묶음 안의 계좌를 점 · 거래를 화살표로 둔 작은 방향 그래프를 통째로 받아 6칸을 답함(결정 11 · 새로 짠 것).
- 채점 약속 _pr = RES/타당성점검_20261026/code/s6_score.py:25-27 과 같은 식(답이 하나도 없는 칸의 정밀도는 0).
- 부트스트랩 = RES/정화실험_20261026/code/p3_score.py:45-49 BJ 와 같은 식(시도를 단위로 다시 뽑음 · 2,000번 · 난수 20261008).
GPU 안 씀 · test 안 엶.
"""
import os
import time
from collections import defaultdict
from pathlib import Path

for _v in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[_v] = '2'
os.environ['CUDA_VISIBLE_DEVICES'] = ''
import numpy as np

HERE = Path(__file__).resolve().parent; OUTD = HERE.parent; RES = OUTD.parent
EXP = RES / '끝난날나눔_실험_20261106'; LED = RES / 'R_사건학습_20261103/data/tmp_ledger'; DEF = RES / '묶음단위_정의_20261111'
ROWS = EXP / 'data/행_trainval.parquet'; ROWS_SHA = '58a51db0250193d974f3cbd515aeb9e48302e90649ac25667dc192ae1bd4050e'
KS = [0, 1, 2, 3, 4, 7]; TY = ['FAN-OUT', 'FAN-IN', 'CYCLE', 'SC-GA', 'GA-SC', 'RANDOM']; K = 6
Y9_TO_6 = {0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 7: 5}
SEEDS = (42, 43, 44); EPOCHS = 100; BATCH = 512; CLIP = 5.0; LR = 0.001; HID = 64; LAYERS = 3; DROP = 0.1
NB, BSEED = 2000, 20261008
EXPECT = {'train': dict(시도=3214, 단위=19414, 행=22536), 'val': dict(시도=2203, 단위=13892, 행=16245)}
EXPECT_V_TRAIN = {'FAN-OUT': 5311, 'FAN-IN': 3169, 'CYCLE': 763, 'SC-GA': 2421, 'GA-SC': 354, 'RANDOM': 7396}   # 정의 한 장 4-3절 · T9
T0 = time.time()


def logger(path):
    def log(t):
        s = f'[{time.strftime("%H:%M:%S", time.gmtime(time.time() + 9 * 3600))} KST · {time.time() - T0:6.1f}초] {t}'
        print(s, flush=True)
        with open(path, 'a', encoding='utf-8') as f:
            f.write(s + '\n')
    return log


# ── 조건 · 정답(c1_train_counts.py 와 같은 글자) ──────────────────────────
def closed_dir(s, d, orgs):
    adj = defaultdict(set)
    for u, w in zip(s, d):
        if u != w:
            adj[u].add(w)
    for o in orgs:
        seen, st = set(), [x for x in adj[o] if x != o]
        while st:
            x = st.pop()
            if x == o:
                return True
            if x in seen:
                continue
            seen.add(x); st.extend(adj[x])
    return False


def flags(s, d, orgs):
    ins, outs = defaultdict(set), defaultdict(set)
    for u, w in zip(s, d):
        ins[w].add(u); outs[u].add(w)
    fo = any(len(v) >= 2 for v in outs.values())
    fi = any(len(v) >= 2 for v in ins.values())
    gs = any(len(ins[c]) >= 2 and len(outs[c]) >= 2 for c in ins if c in outs)
    recv = set(ins); sg = any(len(ins[x] & recv) >= 2 for x in ins)
    return dict(fo=fo, fi=fi, sg=sg, gs=gs, cy=closed_dir(s, d, orgs))


def b2(k, f, n):
    if k == 0:
        return 0 if f['fo'] else -1
    if k == 1:
        return 1 if f['fi'] else -1
    if k == 3:
        return 3 if f['sg'] else (0 if f['fo'] else -1)
    if k == 4:
        return 4 if f['gs'] else (1 if f['fi'] else -1)
    if k == 2:
        return 2 if f['cy'] else (7 if n >= 2 else -1)
    return 7 if n >= 2 else -1


def label_v(k, f, n):
    """정의 한 장 2-3절: 제 유형의 단계 → 미달 가운데 고리만 닫힌 것은 CYCLE(결정 12) → 그 밖의 미달은 RANDOM(결정 9). 돌려주는 값은 y9 번호."""
    v = b2(k, f, n)
    if v != -1:
        return v
    if f['cy'] and not (f['fo'] or f['fi'] or f['sg'] or f['gs']):
        return 2
    return 7


def pat(f, n):
    if n == 1:
        return '1건'
    return '+'.join(c.upper() for c in ('fo', 'fi', 'sg', 'gs', 'cy') if f[c]) or '조건 없음(2건 이상)'


# ── 채점 ─────────────────────────────────────────────────────────────
def _pr(cm):
    tp = np.diag(cm); pc, rc = cm.sum(0), cm.sum(1)
    return np.where(pc > 0, tp / np.maximum(pc, 1e-12), 0.0), np.where(rc > 0, tp / np.maximum(rc, 1e-12), 0.0)


def cmat(y, p, w=None):
    return np.bincount(y * K + p, weights=w, minlength=K * K).reshape(K, K)


def macro(y, p, w=None):
    pr, rc = _pr(cmat(y, p, w)); return np.array([pr.mean(), rc.mean()])


def boot_counts(n_unit):
    rng = np.random.default_rng(BSEED)
    return np.stack([np.bincount(rng.integers(0, n_unit, n_unit), minlength=n_unit) for _ in range(NB)]).astype(np.int16)


# ── 묶음 자료 · 묶음 만들기 ───────────────────────────────────────────
def load_units():
    Z = np.load(OUTD / 'data/묶음.npz', allow_pickle=False); return {k: Z[k] for k in Z.files}


class Batcher:
    """단위 번호 묶음 → (점 수 합, 화살표 보낸 점, 받는 점, 화살표 열, 점이 속한 묶음 번호)."""

    def __init__(self, G, mu, sd):
        import torch
        self.t = torch; self.eoff = G['eoff'].astype(np.int64); self.nn = G['nn'].astype(np.int64)
        self.es = G['esrc'].astype(np.int64); self.ed = G['edst'].astype(np.int64)
        ef = G['efeat'].astype(np.float32).copy(); ef[:, 0] = (ef[:, 0] - mu) / sd; self.ef = ef

    def __call__(self, b):
        t = self.t; b = np.asarray(b, np.int64); ne = self.eoff[b + 1] - self.eoff[b]; nb = self.nn[b]
        noff = np.concatenate([[0], np.cumsum(nb)[:-1]]); start = np.concatenate([[0], np.cumsum(ne)[:-1]])
        idx = np.repeat(self.eoff[b] - start, ne) + np.arange(int(ne.sum())); shift = np.repeat(noff, ne)
        return (int(nb.sum()), t.from_numpy(self.es[idx] + shift), t.from_numpy(self.ed[idx] + shift), t.from_numpy(self.ef[idx]),
                t.from_numpy(np.repeat(np.arange(len(b)), nb)), len(b))


def build_model(n_edge_feat):
    import torch
    import torch.nn as nn

    class BundleGNN(nn.Module):
        def __init__(self):
            super().__init__()
            self.h0 = nn.Parameter(torch.zeros(HID)); nn.init.normal_(self.h0, std=0.1)
            self.enc = nn.Sequential(nn.Linear(n_edge_feat, HID), nn.ReLU(), nn.Linear(HID, HID))
            self.f_in = nn.ModuleList([nn.Sequential(nn.Linear(2 * HID, HID), nn.ReLU()) for _ in range(LAYERS)])
            self.f_out = nn.ModuleList([nn.Sequential(nn.Linear(2 * HID, HID), nn.ReLU()) for _ in range(LAYERS)])
            self.upd = nn.ModuleList([nn.Sequential(nn.Linear(3 * HID, HID), nn.ReLU(), nn.Linear(HID, HID)) for _ in range(LAYERS)])
            self.norm = nn.ModuleList([nn.LayerNorm(HID) for _ in range(LAYERS)])
            self.drop = nn.Dropout(DROP)
            self.head = nn.Sequential(nn.Linear(3 * HID, HID), nn.ReLU(), nn.Dropout(DROP), nn.Linear(HID, K))

        def forward(self, n_node, src, dst, ef, nb, n_graph):
            h = self.h0.unsqueeze(0).expand(n_node, HID); e = self.enc(ef)
            for l in range(LAYERS):
                m_in = torch.zeros(n_node, HID, dtype=h.dtype).index_add_(0, dst, self.f_in[l](torch.cat([h[src], e], 1)))     # 들어오는 화살표: 보낸 쪽 상태 + 거래
                m_out = torch.zeros(n_node, HID, dtype=h.dtype).index_add_(0, src, self.f_out[l](torch.cat([h[dst], e], 1)))   # 나가는 화살표: 받는 쪽 상태 + 거래
                h = self.norm[l](h + self.drop(self.upd[l](torch.cat([h, m_in, m_out], 1))))
            cnt = torch.zeros(n_graph, dtype=h.dtype).index_add_(0, nb, torch.ones(n_node, dtype=h.dtype)).clamp_(min=1).unsqueeze(1)
            g_sum = torch.zeros(n_graph, HID, dtype=h.dtype).index_add_(0, nb, h)
            g_max = torch.full((n_graph, HID), -1e9, dtype=h.dtype).scatter_reduce(0, nb.unsqueeze(1).expand(-1, HID), h, 'amax', include_self=True)
            return self.head(torch.cat([g_sum, g_sum / cnt, g_max], 1))

    return BundleGNN()


def predict(model, batcher, ix, bs=4096):
    import torch
    model.eval(); out = []
    with torch.no_grad():
        for s in range(0, len(ix), bs):
            out.append(torch.softmax(model(*batcher(ix[s:s + bs])), 1).numpy())
    return np.concatenate(out).astype(np.float32)
