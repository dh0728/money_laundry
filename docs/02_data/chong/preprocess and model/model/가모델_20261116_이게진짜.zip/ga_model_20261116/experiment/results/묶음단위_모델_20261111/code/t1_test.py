"""[묶음 단위 유형분류 · test 한 번] 2026-11-11 · Claude Code(세션 fe691014). 재학습 없음 · CPU · 스레드 2.
지시: 은총 님 11-11 "test도 한 번 돌려봐줘"(앞서 "마지막 test로 한 번 보는 거"). 사전기록_test_묶음단위_모델_20261111.md 그대로.
쓰는 법: python3 code/t1_test.py --val-check   → test 를 열지 않음. 같은 함수로 val 묶음을 다시 만들어 2 · 3단계 결과와 같은지 봄(화면에만).
        python3 code/t1_test.py               → test 를 엶(먼저 /workspace/Final_preprocess/TEST_OPENED.log 한 줄) · 한 번만 돎(data/test_SEALED/state_DONE_test 가 있으면 안 돎).
test 에서 읽는 것(읽기만): RES/끝난날나눔_실험_20261106/data/test_SEALED/행_test.parquet(11-10 에 만든 test 배정 행 · sha256 확인 · 패턴 행만 씀) ·
  RES/R_마감_test날짜별_20261104/data/test_SEALED/L_{minute,sid,did,lap}.npy(11-04 test 원장 · 그 행의 줄만).
모델 = run/seed{42,43,44}/best.pt(val 로 고른 것 그대로) · 금액 정규화 = 학습.json 의 값 · 모양 규칙 = train 묶음에서 만든 표 · 채점 식 = g3_score.py 와 같음.
test 개수가 든 것(묶음 · 답 · 표 · 기록)은 data/test_SEALED/ 에만 씀. 그 밖(tables/5_test_*.csv · data/5_test_결과.json)에는 비율만.
"""
import hashlib
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import g_lib as C  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import torch  # noqa: E402
from sklearn.metrics import average_precision_score  # noqa: E402

torch.set_num_threads(2); torch.use_deterministic_algorithms(True)
SEALX = C.RES / '끝난날나눔_실험_20261106/data/test_SEALED'; SEAL11 = C.RES / 'R_마감_test날짜별_20261104/data/test_SEALED'; SEAL = C.OUTD / 'data/test_SEALED'
TOL = Path('/workspace/Final_preprocess/TEST_OPENED.log'); PRE = C.OUTD / '사전기록_test_묶음단위_모델_20261111.md'; PRE_SHA = C.OUTD / 'data/사전기록_test_sha256.txt'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def build(P):
    """g1_data.py 의 반복과 같은 식: P(att · y9 · minute · 날 · src · dst · lap · lpos) → 단위 표 · 묶음 배열."""
    P = P.sort_values(['att', 'minute', 'lpos'], kind='stable').reset_index(drop=True); U, esrc, edst, efeat, eoff, nn = [], [], [], [], [0], []
    for a, g in P.groupby('att', sort=False):
        k = int(g['y9'].iloc[0]); s = g['src'].to_numpy(); d = g['dst'].to_numpy(); ts = g['minute'].to_numpy().astype(np.int64); day = g['날'].to_numpy().astype(int); lap = g['lap'].to_numpy().astype(np.float64)
        assert (np.diff(ts) >= 0).all() and (np.diff(day) >= 0).all() and (day == ts // 1440).all()
        orgs = sorted(set(s[ts == ts.min()].tolist())); f0, fl = int(day.min()), int(day.max())
        for D in np.unique(day):
            n = int((day <= D).sum()); assert (day[:n] <= D).all() and int(ts[:n].max()) < (int(D) + 1) * 1440
            ss, dd = s[:n].tolist(), d[:n].tolist(); f = C.flags(ss, dd, orgs); v = C.label_v(k, f, n); loc = {}
            for x in ss + dd:
                if x not in loc:
                    loc[x] = len(loc)
            esrc.extend(loc[x] for x in ss); edst.extend(loc[x] for x in dd)
            efeat.append(np.stack([lap[:n], np.log1p((ts[:n] - ts[0]) / 1440.0), np.log1p((ts[n - 1] - ts[:n]) / 1440.0)], 1)); eoff.append(eoff[-1] + n); nn.append(len(loc))
            U.append(dict(att=int(a), y9=k, 날=int(D), 나이=int(D) - f0, 끝=bool(D == fl), 거래수=n, 계좌수=len(loc), y6=C.Y9_TO_6[k], v6=C.Y9_TO_6[v], 꼴=C.pat(f, n)))
    U = pd.DataFrame(U)
    return U, dict(eoff=np.array(eoff, np.int64), nn=np.array(nn, np.int32), esrc=np.array(esrc, np.int32), edst=np.array(edst, np.int32), efeat=np.concatenate(efeat).astype(np.float32))


def rule_table():
    Ut = pd.read_parquet(C.OUTD / 'data/단위.parquet'); Ut = Ut[Ut['구간'] == 'train']
    ct = pd.crosstab(Ut['꼴'], Ut['v6']).reindex(columns=range(C.K), fill_value=0); return ct.idxmax(axis=1).to_dict(), int(np.bincount(Ut['v6'].to_numpy(), minlength=C.K).argmax())


def predict_all(G):
    PM = {}
    for s in C.SEEDS:
        j = json.loads((C.OUTD / f'run/seed{s}/학습.json').read_text(encoding='utf-8')); model = C.build_model(G['efeat'].shape[1]); model.load_state_dict(torch.load(C.OUTD / f'run/seed{s}/best.pt'))
        PM[s] = C.predict(model, C.Batcher(G, j['금액_평균'], j['금액_표준편차']), np.arange(len(G['nn'])))
    return PM


def score(U, PM, p_rule):
    """g3_score.py 와 같은 식. 돌려주는 것: 성적표 이름 → 값(개수 포함). 파일에 쓸 때 개수를 뺄지는 부르는 쪽이 정함."""
    pm = {s: PM[s].argmax(1).astype(np.int64) for s in C.SEEDS}; yv = U['v6'].to_numpy(); yo = U['y6'].to_numpy(); end = U['끝'].to_numpy(); ua, ai = np.unique(U['att'].to_numpy(), return_inverse=True); cnt = C.boot_counts(len(ua))
    vis_att = set(U.loc[end & (yv == yo), 'att']); vis = U['att'].isin(vis_att).to_numpy()
    SH = {'(1) 모든 묶음 · 보이는 대로': (np.ones(len(U), bool), yv), '(1) 가운데 덜 끝난 묶음': (~end, yv), '(1) 가운데 끝난 시도': (end, yv), '(2) 끝난 시도 · 원래 유형': (end, yo),
          '(2) 가운데 끝까지 본 모양이 원래 유형과 같은 시도(곁)': (end & vis, yo), '(2) 가운데 끝까지 본 모양이 원래 유형과 다른 시도(곁)': (end & ~vis, yo)}
    q = lambda a: [round(float(v), 4) for v in np.percentile(a, [2.5, 97.5])]  # noqa: E731
    out = {}
    for nm, (m, y) in SH.items():
        ix = np.flatnonzero(m); yy = y[ix]; W = cnt[:, ai[ix]].astype(np.float64)
        pt_m = np.stack([C.macro(yy, pm[s][ix]) for s in C.SEEDS]); pt_r = C.macro(yy, p_rule[ix])
        bm = np.stack([np.mean([C.macro(yy, pm[s][ix], w) for s in C.SEEDS], 0) for w in W]); br = np.stack([C.macro(yy, p_rule[ix], w) for w in W]); bd = bm - br
        prs = [C._pr(C.cmat(yy, pm[s][ix])) for s in C.SEEDS]; prr = C._pr(C.cmat(yy, p_rule[ix])); cmm = np.mean([C.cmat(yy, pm[s][ix]) for s in C.SEEDS], 0); cmr = C.cmat(yy, p_rule[ix])
        ap = [float(np.mean([average_precision_score(yy == c, PM[s][ix][:, c]) for c in range(C.K) if (yy == c).any()])) for s in C.SEEDS]
        out[nm] = dict(묶음=len(ix), 시도=int(len(np.unique(ai[ix]))), 몫=round(len(ix) / max(int(m.sum() and len(U)), 1), 4),
                       모델=dict(정밀도=round(float(pt_m[:, 0].mean()), 4), 정밀도_SD=round(float(pt_m[:, 0].std(ddof=1)), 4), 정밀도_95=q(bm[:, 0]), 재현율=round(float(pt_m[:, 1].mean()), 4), 재현율_SD=round(float(pt_m[:, 1].std(ddof=1)), 4), 재현율_95=q(bm[:, 1]),
                               맞은몫=round(float(np.mean([(pm[s][ix] == yy).mean() for s in C.SEEDS])), 4), macroAP=round(float(np.mean(ap)), 4), 씨앗별=[[round(float(a), 4), round(float(b), 4)] for a, b in pt_m]),
                       규칙=dict(정밀도=round(float(pt_r[0]), 4), 정밀도_95=q(br[:, 0]), 재현율=round(float(pt_r[1]), 4), 재현율_95=q(br[:, 1]), 맞은몫=round(float((p_rule[ix] == yy).mean()), 4)),
                       차이=dict(정밀도=round(float(pt_m[:, 0].mean() - pt_r[0]), 4), 정밀도_95=q(bd[:, 0]), 재현율=round(float(pt_m[:, 1].mean() - pt_r[1]), 4), 재현율_95=q(bd[:, 1]), 같은답몫=round(float(np.mean([(pm[s][ix] == p_rule[ix]).mean() for s in C.SEEDS])), 4)),
                       유형별=[dict(유형=t, 정답수=int((yy == i).sum()), 정답몫=round(float((yy == i).mean()), 4), 모델_정밀도=round(float(np.mean([p[0][i] for p in prs])), 4), 모델_재현율=round(float(np.mean([p[1][i] for p in prs])), 4),
                                  규칙_정밀도=round(float(prr[0][i]), 4), 규칙_재현율=round(float(prr[1][i]), 4)) for i, t in enumerate(C.TY)],
                       혼동_모델=cmm.tolist(), 혼동_규칙=cmr.tolist())
    return out


def val_check():
    print('[val-check] test 를 열지 않음 · val 묶음을 이 파일의 함수로 다시 만들어 2 · 3단계와 견줌')
    T = pd.read_parquet(C.ROWS); P = T[(T['y9'] < 8) & (T['구간'] == 'val')].copy(); lp = P['lpos'].to_numpy(); o = np.argsort(lp)
    for nm, f in (('m2', 'minute'), ('src', 'sid'), ('dst', 'did'), ('lap', 'lap')):
        arr = np.load(C.LED / f'{f}.npy', mmap_mode='r'); v = np.empty(len(lp), arr.dtype); v[o] = np.asarray(arr[lp[o]]); P[nm] = v
    assert (P['m2'].to_numpy().astype(np.int64) == P['minute'].to_numpy()).all()
    U, G = build(P); G0 = C.load_units(); va = np.flatnonzero(~G0['is_train']); ei = np.concatenate([np.arange(G0['eoff'][u], G0['eoff'][u + 1]) for u in va])   # 1단계 묶음에서 val 단위는 train 단위 사이에 끼어 있음(시도 번호 차례)
    assert len(U) == len(va) and (U['att'].to_numpy() == G0['att'][va]).all() and (U['날'].to_numpy() == G0['날'][va]).all() and (U['v6'].to_numpy() == G0['v6'][va]).all() and (U['y6'].to_numpy() == G0['y6'][va]).all()
    assert np.array_equal(G['esrc'], G0['esrc'][ei]) and np.array_equal(G['edst'], G0['edst'][ei]) and np.array_equal(G['efeat'], G0['efeat'][ei]) and np.array_equal(G['nn'], G0['nn'][va])
    print('  묶음 배열 · 정답이 1단계 val 묶음과 비트까지 같음 · 묶음', len(U))
    PM = predict_all(G)
    for s in C.SEEDS:
        Z = np.load(C.OUTD / f'run/seed{s}/val확률.npz'); d = float(np.abs(Z['P'] - PM[s]).max()); assert d < 1e-6 and (Z['P'].argmax(1) == PM[s].argmax(1)).all(), d
    rule, fb = rule_table(); p_rule = U['꼴'].map(rule).fillna(fb).to_numpy(np.int64); R = score(U, PM, p_rule); ref = json.loads((C.OUTD / 'data/3_결과.json').read_text(encoding='utf-8'))
    for a, b in (('(1) 모든 묶음 · 보이는 대로', '(1) 모든 묶음 · 보이는 대로'), ('(2) 끝난 시도 · 원래 유형', '(2) 끝난 시도 · 원본 유형')):
        got = (R[a]['모델']['정밀도'], R[a]['모델']['재현율'], R[a]['규칙']['정밀도'], R[a]['규칙']['재현율']); want = (ref[b]['모델']['정밀도'], ref[b]['모델']['재현율'], ref[b]['규칙']['정밀도'], ref[b]['규칙']['재현율'])
        assert got == want, (got, want); print(f'  {a}: 모델 {got[0]} / {got[1]} · 규칙 {got[2]} / {got[3]} = 3단계 값과 같음')
    x = R['(2) 가운데 끝까지 본 모양이 원래 유형과 같은 시도(곁)']; z = R['(2) 가운데 끝까지 본 모양이 원래 유형과 다른 시도(곁)']
    print(f'  곁(val): 모양이 원래 유형과 같은 시도 {x["시도"]} · 모델 맞은 몫 {x["모델"]["맞은몫"]} / 다른 시도 {z["시도"]} · 모델 맞은 몫 {z["모델"]["맞은몫"]}'); print('[val-check] 통과')


def main():
    if '--val-check' in sys.argv:
        return val_check()
    assert not (SEAL / 'state_DONE_test').exists(), 'test 채점은 이미 한 번 끝남 → 다시 돌지 않음'
    want = PRE_SHA.read_text(encoding='utf-8').split()[0]; assert sha(PRE) == want, 'test 사전기록 sha256 이 고정 때와 다름 → 멈춤'
    for ln in (C.OUTD / 'data/test_고정시_sha256.txt').read_text(encoding='utf-8').splitlines():
        h, p = ln.split(maxsplit=1); assert sha(p) == h, f'고정 때와 다른 파일 → 멈춤: {p}'
    SEAL.mkdir(parents=True, exist_ok=True); log = C.logger(SEAL / 't1_test.log')
    with open(TOL, 'a', encoding='utf-8') as f:
        f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())} UTC] pid {os.getpid()} · 묶음 단위 유형분류 첫 판 test 한 번(묶음단위_모델_20261111/code/t1_test.py · 끝난날나눔_실험_20261106/data/test_SEALED/행_test.parquet 의 패턴 행 · "
                f"11-04 test 원장 L_minute · L_sid · L_did · L_lap 의 그 행 줄) · 이유: 은총 님 11-11 지시(test도 한 번 돌려봐줘 · 재학습 없음 · 11-10 에 이어 두 번째 사용) · 쓰는 것: 묶음단위_모델_20261111/data/test_SEALED/(묶음 · 답 · 개수 표 · 기록) · "
                f"tables/5_test_*.csv · data/5_test_결과.json(비율만) · test 개수는 data/test_SEALED/ · 채팅 답에만 · test 사전기록 sha {want[:16]}… · 기록 시각 {time.strftime('%Y-%m-%d %H:%M', time.gmtime(time.time() + 9 * 3600))} KST\n")
    log('TEST_OPENED.log 한 줄 적음 · test 를 엶')
    src = SEALX / '행_test.parquet'; assert sha(src) == (SEALX / '행_test_sha256.txt').read_text(encoding='utf-8').split()[0], '행_test.parquet sha256 이 11-10 기록과 다름 → 멈춤'
    T = pd.read_parquet(src); P = T[T['y9'] != 8].copy(); assert set(P['y9'].unique()) <= set(C.KS) and (P['시도끝날'] >= 75).all() and (P['시도끝날'] <= 96).all() and P.groupby('att')['y9'].nunique().max() == 1
    G0 = C.load_units(); assert not (set(P['att']) & set(G0['att'])), 'test 시도가 train · val 묶음에 있음 → 멈춤'
    tp = P['tp'].to_numpy(np.int64); o = np.argsort(tp)
    for nm, f in (('m2', 'minute'), ('src', 'sid'), ('dst', 'did'), ('lap', 'lap')):
        arr = np.load(SEAL11 / f'L_{f}.npy', mmap_mode='r'); v = np.empty(len(tp), arr.dtype); v[o] = np.asarray(arr[tp[o]]); P[nm] = v
    assert (P['m2'].to_numpy().astype(np.int64) == P['minute'].to_numpy()).all(), 'test 원장 분 ≠ 행 분 → 멈춤'
    assert int(P['minute'].max()) < 97 * 1440; P['lpos'] = tp
    U, G = build(P); PM = predict_all(G); rule, fb = rule_table(); miss = int((~U['꼴'].isin(rule)).sum()); p_rule = U['꼴'].map(rule).fillna(fb).to_numpy(np.int64)
    np.savez_compressed(SEAL / '묶음_test.npz', **G, att=U['att'].to_numpy(np.int64), y6=U['y6'].to_numpy(np.int64), v6=U['v6'].to_numpy(np.int64), 끝=U['끝'].to_numpy(), 날=U['날'].to_numpy(np.int32))
    np.savez_compressed(SEAL / 'test확률.npz', **{f'P_s{s}': PM[s] for s in C.SEEDS})
    D = U.copy(); D['답_규칙'] = p_rule
    for s in C.SEEDS:
        D[f'답_모델_s{s}'] = PM[s].argmax(1)
    D.to_parquet(SEAL / 'test_묶음별_답.parquet', index=False)
    R = score(U, PM, p_rule); end = U['끝'].to_numpy()
    R['자료'] = dict(시도=int(U['att'].nunique()), 묶음=len(U), 행=int(U.loc[end, '거래수'].sum()), 꼴이_train_에_없는_묶음=miss, 정답칸_묶음={t: int((U['v6'] == i).sum()) for i, t in enumerate(C.TY)}, 원래유형_시도={t: int((U.loc[end, 'y6'] == i).sum()) for i, t in enumerate(C.TY)},
                   끝난시도_모양이_원래유형과_같은_수=int((U.loc[end, 'v6'] == U.loc[end, 'y6']).sum()), 날75앞_묶음=int((U['날'] < 75).sum()))
    (SEAL / '5_test_결과_SEALED.json').write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding='utf-8')
    # ── 봉인 밖: 비율만 ──
    pub, mrows, trows, crows = {}, [], [], []
    for nm, v in R.items():
        if nm == '자료':
            continue
        pub[nm] = {k: v[k] for k in ('모델', '규칙', '차이')}; m, r, d = v['모델'], v['규칙'], v['차이']
        mrows.append({'성적표': nm, '판': '모델(씨앗 3개 평균)', '정밀도': m['정밀도'], '정밀도 씨앗 SD': m['정밀도_SD'], '정밀도 95%': str(m['정밀도_95']), '재현율': m['재현율'], '재현율 씨앗 SD': m['재현율_SD'], '재현율 95%': str(m['재현율_95']), '맞은 몫': m['맞은몫'], 'macro-AP': m['macroAP']})
        mrows.append({'성적표': nm, '판': '모양 규칙', '정밀도': r['정밀도'], '정밀도 95%': str(r['정밀도_95']), '재현율': r['재현율'], '재현율 95%': str(r['재현율_95']), '맞은 몫': r['맞은몫']})
        mrows.append({'성적표': nm, '판': '모델 − 규칙', '정밀도': d['정밀도'], '정밀도 95%': str(d['정밀도_95']), '재현율': d['재현율'], '재현율 95%': str(d['재현율_95']), '맞은 몫': d['같은답몫']})
        for t in v['유형별']:
            trows.append({'성적표': nm, '유형': t['유형'], '정답 가운데 몫': t['정답몫'], '모델 정밀도': t['모델_정밀도'], '모델 재현율': t['모델_재현율'], '규칙 정밀도': t['규칙_정밀도'], '규칙 재현율': t['규칙_재현율']})
        cm = np.array(v['혼동_모델']); rs = cm.sum(1, keepdims=True)
        for i, t in enumerate(C.TY):
            crows.append({'성적표': nm, '판': '모델(씨앗 평균)', '정답': t, **{f'답 {u} 몫': (round(float(cm[i, j] / rs[i, 0]), 4) if rs[i, 0] > 0 else None) for j, u in enumerate(C.TY)}})
    e2 = R['(2) 끝난 시도 · 원래 유형']; pub['자료_비율'] = dict(끝난시도_가운데_모양이_원래유형과_같은_몫=round(R['자료']['끝난시도_모양이_원래유형과_같은_수'] / R['자료']['시도'], 4), 꼴이_train_에_없는_묶음_몫=round(miss / len(U), 4), 덜끝난_묶음_몫=round(float((~end).mean()), 4),
                           날75앞_묶음_몫=round(R['자료']['날75앞_묶음'] / len(U), 4), 원래유형_시도_몫={t: round(v / R['자료']['시도'], 4) for t, v in R['자료']['원래유형_시도'].items()}); assert e2['시도'] == R['자료']['시도']
    for name, rows in (('5_test_주표', mrows), ('5_test_유형별', trows), ('5_test_혼동행렬_비율', crows)):
        pd.DataFrame(rows).to_csv(C.OUTD / f'tables/{name}.csv', index=False, encoding='utf-8-sig')
    (C.OUTD / 'data/5_test_결과.json').write_text(json.dumps(pub, ensure_ascii=False, indent=1), encoding='utf-8'); (SEAL / 'state_DONE_test').write_text('done\n')
    log(f'끝 · 자료 {json.dumps(R["자료"], ensure_ascii=False)}')
    for nm, v in R.items():
        if nm != '자료':
            log(f'{nm}: 묶음 {v["묶음"]:,} · 시도 {v["시도"]:,} · 모델 {v["모델"]["정밀도"]} / {v["모델"]["재현율"]}(95% {v["모델"]["정밀도_95"]} / {v["모델"]["재현율_95"]}) · 맞은 몫 {v["모델"]["맞은몫"]} · 규칙 {v["규칙"]["정밀도"]} / {v["규칙"]["재현율"]}')


if __name__ == '__main__':
    sys.exit(main())
