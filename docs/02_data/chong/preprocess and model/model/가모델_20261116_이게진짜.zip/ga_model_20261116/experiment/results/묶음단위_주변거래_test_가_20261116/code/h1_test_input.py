"""[(가) 판 test · 1] test 를 엶 — TEST_OPENED 한 줄 → 원장 덧붙이기(점검 2 · 3) → test 묶음(11-11 과 같은지 · 점검 4) → 주변 거래 입력(11-12 규칙 · 점검 5).
CPU · 메모리 20 GiB 쯤. test 개수가 든 것은 data/test_SEALED/ 에만 씀(봉인 밖 data/h1_점검.json 에는 비율만).
쓰는 법: python3 code/h1_test_input.py"""
import json
import os
import sys
import time
from pathlib import Path

sys.dont_write_bytecode = True
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import pyarrow as pa  # noqa: E402
import pyarrow.compute as pc  # noqa: E402
import pyarrow.csv as pv  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parent))
import h_lib as H  # noqa: E402
sys.path.insert(0, str(H.EXP / 'code'))
import e1_build as B1  # noqa: E402  (build_index · take · expand · localize 만 · main 은 돌지 않음)
sys.path.insert(0, str(H.OLD / 'code'))
import g_lib as C  # noqa: E402
import t1_test as T1  # noqa: E402  (build 함수만 · test 채점 main 은 돌리지 않음)

B1.SH = 18   # 사전기록 1절: 날 91 뒤 분이 2^17 을 넘음 → 분 칸 18비트(줄 세우는 차례 · 고르는 거래는 같음)
COLS = ['att', 'y9', '날', '나이', '끝', '거래수', '계좌수', 'y6', 'v6', '꼴']
LUT = np.full(256, 255, np.uint8)
for _i, _c in enumerate(b'0123456789ABCDEF'):
    LUT[_c] = _i
LUT[ord(' ')] = 254


def hexkey(arr):
    """17_SALT_R_모델원본_한파일.py 의 hexkey 와 같은 식: 16진 계좌 번호(1 ~ 10자) → int64."""
    n = len(arr)
    assert pc.max(pc.utf8_length(arr)).as_py() <= 10
    p = pc.utf8_rpad(arr, width=10, padding=' ').combine_chunks() if isinstance(arr, pa.ChunkedArray) else pc.utf8_rpad(arr, width=10, padding=' ')
    offs = np.frombuffer(p.buffers()[1], np.int32)[p.offset: p.offset + n + 1]
    assert (np.diff(offs) == 10).all()
    raw = np.frombuffer(p.buffers()[2], np.uint8)[offs[0]: offs[0] + 10 * n].reshape(n, 10)
    nib = LUT[raw]; assert (nib != 255).all(), '16진이 아닌 계좌 번호'
    v = np.zeros(n, np.int64)
    for i in range(10):
        c = nib[:, i]; ok = c != 254
        v = np.where(ok, v * 16 + c, v)
    return v


def read_raw(path, base, log):
    """17_SALT_R_모델원본_한파일.py 의 read_transactions 와 같은 식 · 줄 차례 그대로 · 분은 base(2022-08-01 0시)부터."""
    with open(path, 'rb') as f:
        first = f.readline().decode('utf-8', 'replace').rstrip('\r\n')
    ncol = len(first.split(',')); assert ncol >= 11; header = not first[:4].isdigit(); names = [f'c{i}' for i in range(ncol)]
    ro = pv.ReadOptions(column_names=names, skip_rows=1 if header else 0, block_size=1 << 26)
    co = pv.ConvertOptions(include_columns=['c0', 'c1', 'c2', 'c3', 'c4', 'c7', 'c10'], column_types={c: pa.string() for c in names}, strings_can_be_null=False)
    mins, sks, dks, laps, labs = [], [], [], [], []
    for b in pv.open_csv(path, read_options=ro, convert_options=co):
        ts = pc.strptime(b.column('c0'), format='%Y/%m/%d %H:%M', unit='s'); mins.append(ts.cast(pa.int64()).to_numpy(zero_copy_only=False) // 60 - base)
        fb = b.column('c1').cast(pa.int64()).to_numpy(zero_copy_only=False); tb = b.column('c3').cast(pa.int64()).to_numpy(zero_copy_only=False)
        assert (fb >= 0).all() and (fb < (1 << 23)).all() and (tb >= 0).all() and (tb < (1 << 23)).all()
        sks.append((fb << 40) | hexkey(b.column('c2'))); dks.append((tb << 40) | hexkey(b.column('c4')))
        laps.append(np.log1p(b.column('c7').cast(pa.float64()).to_numpy(zero_copy_only=False)).astype(np.float32)); labs.append(b.column('c10').cast(pa.int8()).to_numpy(zero_copy_only=False))
    log(f'원본 읽기 끝 · 머리줄 {"있음" if header else "없음"}')
    return np.concatenate(mins), np.concatenate(sks), np.concatenate(dks), np.concatenate(laps), np.concatenate(labs)


def build_inputs(U, P, fmin, fsid, fdid, flap, flab, NAF, log=print):
    """e1_build.py main 의 반복과 같은 식. U = 묶음(att · 날 · 거래수) · P = 그 시도들의 행(att · minute · lpos) · f* = 원장.
    돌려줌: 입력 배열 13개(H.ARR) · 덧(n_in = 입력에 든 그 시도 거래 · n = 그날까지 그 시도 거래 · seed_row). 점검 5 를 여기서 함."""
    Ps = P.sort_values(['att', 'minute', 'lpos'], kind='stable').reset_index(drop=True); LP = Ps['lpos'].to_numpy().astype(np.int64)
    st_of = Ps.groupby('att', sort=False).apply(lambda g: int(g.index[0])); n_att = Ps.groupby('att', sort=False).size()
    st = U['att'].map(st_of).to_numpy(); n = U['거래수'].to_numpy(); NB = len(U); seed_row = LP[st + n - 1]; cut = (U['날'].to_numpy().astype(np.int64) + 1) * 1440
    assert (fmin[seed_row] // 1440 == U['날'].to_numpy()).all() and (n <= U['att'].map(n_att).to_numpy()).all(), '씨앗이 그날의 거래가 아님 → 멈춤'
    m0 = np.zeros(NAF, bool); m0[fsid[seed_row]] = True; m0[fdid[seed_row]] = True; key, row = B1.build_index(fsid, fdid, fmin, m0)
    m1 = m0.copy()
    for b in range(NB):
        _, _, fr = B1.expand(key, row, fsid, fdid, int(seed_row[b]), int(cut[b]), 1, B1.W_DAYS, B1.K); m1[fr] = True
    del key, row; key, row = B1.build_index(fsid, fdid, fmin, m1); log('줄 세우기 끝 · 넓히기 시작')
    R, HP, off, nn, es, ed, s_u, s_v = [], [], [0], [], [], [], [], []
    for b in range(NB):
        r, hp, _ = B1.expand(key, row, fsid, fdid, int(seed_row[b]), int(cut[b]), B1.H, B1.W_DAYS, B1.K); k_, a_, d_, u_, v_ = B1.localize(fsid, fdid, r, fsid[seed_row[b]], fdid[seed_row[b]])
        R.append(r); HP.append(hp); off.append(off[-1] + len(r)); nn.append(k_); es.append(a_); ed.append(d_); s_u.append(u_); s_v.append(v_)
    del key, row; R = np.concatenate(R); HP = np.concatenate(HP); off = np.array(off, np.int64); es = np.concatenate(es); ed = np.concatenate(ed); NE = len(R); emin = fmin[R]
    bid = np.repeat(np.arange(NB), np.diff(off))
    assert (emin < cut[bid]).all() and (R[off[:-1]] == seed_row).all() and (HP[off[:-1]] == 0).all(), '점검 5: 마감 뒤 거래 · 씨앗 자리 → 멈춤'
    m_laund = flab[R] == 1; m_own = np.zeros(NE, bool); n_in = np.zeros(NB, np.int32)
    for b in range(NB):
        a, c = off[b], off[b + 1]; mm = np.isin(R[a:c], LP[st[b]:st[b] + n[b]]); m_own[a:c] = mm; n_in[b] = mm.sum()
    assert m_own[off[:-1]].all() and m_laund[m_own].all(), '점검 5: 씨앗 · 세탁 표시 → 멈춤'
    A = dict(eoff=off, nn=np.array(nn, np.int32), esrc=es, edst=ed, e_lap=flap[R].astype(np.float32), e_min=emin.astype(np.int32), e_hop=HP, m_own=m_own, m_laund=m_laund,
             seed_u=np.array(s_u, np.int32), seed_v=np.array(s_v, np.int32), cut=cut, seed_min=fmin[seed_row].astype(np.int32))
    return A, dict(n_in=n_in, n=n, seed_row=seed_row)


def main():
    H.check_fixed(); H.SEAL.mkdir(parents=True, exist_ok=True)
    assert not (H.SEAL / 'state_DONE_test').exists(), 'test 는 이미 한 번 채점함 → 다시 돌지 않음'
    assert not (H.SEAL / '입력_test').exists(), 'test 입력이 이미 있음 → 다시 만들지 않음'
    log = H.logger(H.SEAL / 'h1_test_input.log'); want = H.PRE_SHA.read_text(encoding='utf-8').split()[0]
    with open(H.TOL, 'a', encoding='utf-8') as f:
        f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())} UTC] pid {os.getpid()} · 주변 거래 (가) 판 test 한 번(이사묶음 results/묶음단위_주변거래_test_가_20261116/code/h1 · h2 · h3 · "
                f"/data/shared/ibm-aml/HI-Large_Trans.csv 의 날 75 ~ 96 줄을 train · val 원장 뒤에 이어 붙임(꼬리는 안 씀) · 끝난날나눔_실험_20261106/data/test_SEALED/행_test.parquet · "
                f"묶음단위_모델_20261111/data/test_SEALED/test_묶음별_답.parquet · 묶음_test.npz · test확률.npz(견줌 · 읽기만)) · 이유: 은총 님 11-16 지시(일단 test 돌려보자 '가'로 · 재학습 없음 · "
                f"주 기간 · 11-10 · 11-11 · 11-12 에 이어 네 번째 사용) · 쓰는 것: 묶음단위_주변거래_test_가_20261116/data/test_SEALED/(원장 덧붙임 · 입력 · 확률 · 개수 · 기록) · "
                f"tables/1_test_*.csv · data/1_test_결과.json · data/h1_점검.json(비율만) · test 개수는 data/test_SEALED/ · 채팅 답에만 · 사전기록 sha {want[:16]}… · "
                f"기록 시각 {time.strftime('%Y-%m-%d %H:%M', time.gmtime(time.time() + 9 * 3600))} KST\n")
    log('TEST_OPENED.log 한 줄 적음 · test 를 엶'); S = {}
    # ── 원장: train · val 원장 그대로 + 날 75 ~ 96 줄 ──
    meta = json.loads((H.LED / 'meta.json').read_text()); base = int(meta['base_min']); NA = int(meta['n_acct'])
    tmin = np.load(H.LED / 'minute.npy'); tsid = np.load(H.LED / 'sid.npy'); tdid = np.load(H.LED / 'did.npy'); tlap = np.load(H.LED / 'lap.npy'); tlab = np.load(H.LED / 'lab.npy'); N = len(tmin)
    m, sk, dk, lap, lab = read_raw(H.RAW, base, log); NR = len(m)
    tv = (m >= 0) & (m < 75 * 1440); te = (m >= 75 * 1440) & (m < 97 * 1440)
    assert int(tv.sum()) == N, '점검 2: 날 0 ~ 74 줄 수가 tmp_ledger 와 다름 → 멈춤'
    uk = np.unique(np.concatenate([sk[tv], dk[tv]])); assert len(uk) == NA, '점검 2: 계좌 수가 다름 → 멈춤'

    def same(order):
        return bool(np.array_equal(m[order].astype(np.int32), tmin) and np.array_equal(lap[order], tlap) and np.array_equal(lab[order], tlab)
                    and np.array_equal(np.searchsorted(uk, sk[order]).astype(np.int32), tsid) and np.array_equal(np.searchsorted(uk, dk[order]).astype(np.int32), tdid))
    order = np.flatnonzero(tv); how = '원본 차례'
    if not same(order):
        order = np.r_[np.flatnonzero(tv & (m < 58 * 1440)), np.flatnonzero(tv & (m >= 58 * 1440))]; how = 'train(날 0 ~ 57) → val(58 ~ 74)'
        assert same(order), '점검 2: 원본 날 0 ~ 74 줄이 tmp_ledger 와 줄마다 맞지 않음 → 멈춤'
    log(f'점검 2 통과 · 차례 = {how}')
    raw2full = np.full(NR, -1, np.int64); raw2full[order] = np.arange(N, dtype=np.int64); ie = np.flatnonzero(te); NT = len(ie); raw2full[ie] = N + np.arange(NT, dtype=np.int64); del order, tv, te
    ke = np.unique(np.concatenate([sk[ie], dk[ie]])); newk = ke[~np.isin(ke, uk, assume_unique=True)]; KF = np.r_[uk, newk]; NAF = len(KF)

    def acct(k):
        p = np.minimum(np.searchsorted(uk, k), NA - 1); hit = uk[p] == k
        return np.where(hit, p, NA + np.searchsorted(newk, k)).astype(np.int32)
    esid, edid = acct(sk[ie]), acct(dk[ie]); assert np.array_equal(KF[esid], sk[ie]) and np.array_equal(KF[edid], dk[ie]), '새 계좌 번호가 어긋남 → 멈춤'
    fmin = np.r_[tmin, m[ie].astype(np.int32)]; fsid = np.r_[tsid, esid]; fdid = np.r_[tdid, edid]; flap = np.r_[tlap, lap[ie]]; flab = np.r_[tlab, lab[ie]]
    assert int(fmin.max()) < 97 * 1440 and int(fmin[N:].min()) >= 75 * 1440
    d = H.SEAL / '원장_덧붙임'; d.mkdir(parents=True, exist_ok=True)
    for nm, arr in (('minute', fmin[N:]), ('sid', fsid[N:]), ('did', fdid[N:]), ('lap', flap[N:]), ('lab', flab[N:])):
        np.save(d / f'{nm}.npy', arr)
    S['원장'] = dict(train_val_줄=N, 덧붙인_줄=NT, 계좌_train_val=NA, 새_계좌=int(len(newk)), 원본_줄=NR, 차례=how)
    del m, sk, dk, lap, lab, ke, esid, edid, tmin, tsid, tdid, tlap, tlab
    TV = pd.read_parquet(H.SPL / 'data/행_trainval.parquet', columns=['eid', 'lpos', 'y9', '구간'])
    assert np.array_equal(raw2full[TV['eid'].to_numpy()], TV['lpos'].to_numpy().astype(np.int64)), '점검 3: eid → 새 원장 줄 번호가 lpos 와 다름 → 멈춤'
    log('점검 3 통과(eid = 원본 줄 번호)')
    # ── test 묶음(11-11 과 같은 식) ──
    src = H.SPL / 'data/test_SEALED/행_test.parquet'
    assert H.sha(src) == (H.SPL / 'data/test_SEALED/행_test_sha256.txt').read_text(encoding='utf-8').split()[0], '행_test.parquet sha256 이 11-10 기록과 다름 → 멈춤'
    T = pd.read_parquet(src); P = T[T['y9'] != 8].copy()
    assert set(P['y9'].unique()) <= set(C.KS) and (P['시도끝날'] >= 75).all() and (P['시도끝날'] <= 96).all() and P.groupby('att')['y9'].nunique().max() == 1
    G0 = C.load_units(); assert not (set(P['att']) & set(G0['att'])), 'test 시도가 train · val 묶음에 있음 → 멈춤'
    pos = raw2full[P['eid'].to_numpy()]; del raw2full
    assert (pos >= 0).all() and np.array_equal(fmin[pos].astype(np.int64), P['minute'].to_numpy().astype(np.int64)), 'test 행 → 새 원장 줄이 어긋남 → 멈춤'
    P['src'] = fsid[pos]; P['dst'] = fdid[pos]; P['lap'] = flap[pos]; P['lpos'] = pos; assert int(P['minute'].max()) < 97 * 1440
    U, G = T1.build(P)
    U11 = pd.read_parquet(H.OLD / 'data/test_SEALED/test_묶음별_답.parquet')
    same_u = len(U) == len(U11) and all(np.array_equal(U[c].to_numpy(), U11[c].to_numpy()) for c in COLS)
    Z11 = np.load(H.OLD / 'data/test_SEALED/묶음_test.npz'); same_g = {k: bool(np.array_equal(G[k], Z11[k])) for k in ('eoff', 'nn', 'esrc', 'edst', 'efeat')}
    S['점검4'] = dict(묶음표_같음=bool(same_u), 배열_같음=same_g)
    assert same_u and all(same_g.values()), f'점검 4: test 묶음이 11-11 과 다름 → 멈춤 · 묶음표 {same_u} · 배열 {same_g}'
    log('점검 4 통과(11-11 test 묶음과 같음)')
    # ── 입력(e1_build.py main 의 반복과 같은 식 · test 묶음만) ──
    A, X = build_inputs(U, P, fmin, fsid, fdid, flap, flab, NAF, log); log('점검 5 통과')
    d = H.SEAL / '입력_test'; d.mkdir(parents=True, exist_ok=True)
    for nm in H.ARR:
        np.save(d / f'{nm}.npy', A[nm])
    # ── 묶음표 · 통계(e1_build.py 와 같은 칸) ──
    TVp = TV[TV['y9'] < 8]; lp_tr = TVp.loc[TVp['구간'] == 'train', 'lpos'].to_numpy().astype(np.int64)
    tr_acc = np.zeros(NAF, bool); tr_acc[fsid[lp_tr]] = True; tr_acc[fdid[lp_tr]] = True
    off = A['eoff']; HP = A['e_hop']; m_laund = A['m_laund']; n_in = X['n_in']; n = X['n']; seed_row = X['seed_row']; NB = len(U); NE = len(HP); emin = A['e_min']
    ne = np.diff(off); n1 = np.add.reduceat((HP == 1).astype(np.int64), off[:-1]); nl = np.add.reduceat(m_laund.astype(np.int64), off[:-1])
    U2 = U[COLS].copy(); U2['입력_거래'] = ne; U2['입력_계좌'] = A['nn']; U2['입력_1홉_거래'] = n1; U2['입력_세탁표시_거래'] = nl; U2['입력에_든_시도거래'] = n_in
    U2['씨앗계좌가_train시도에_나옴'] = tr_acc[fsid[seed_row]] | tr_acc[fdid[seed_row]]; U2.to_parquet(H.SEAL / '묶음표_test.parquet', index=False)
    S['test'] = dict(시도=int(U['att'].nunique()), 묶음=NB, 입력_거래_합=int(NE), 입력_거래_가운데=float(np.median(ne)), 입력_거래_평균=round(float(ne.mean()), 1), 입력_거래_최대=int(ne.max()))
    pub = dict(점검=dict(점검2=f'통과 · 차례 = {how}', 점검3='통과', 점검4='통과(11-11 test 묶음과 같음)', 점검5='통과'),
               비율=dict(그_시도_거래가_입력에_든_몫_평균=round(float((n_in / n).mean()), 4), 다_든_묶음_몫=round(float((n_in == n).mean()), 4),
                        입력_가운데_세탁표시_거래_몫_평균=round(float((nl / ne).mean()), 4), 입력_가운데_정상거래_몫=round(float(1 - m_laund.mean()), 4),
                        세탁표시_가운데_그_시도_거래_몫_평균=round(float((n_in / nl).mean()), 4), 씨앗_계좌가_train_시도에_나온_묶음_몫=round(float(U2['씨앗계좌가_train시도에_나옴'].mean()), 4),
                        날75앞에_시작한_시도의_묶음이_보는_train_val_기간_거래_몫=round(float((emin < 75 * 1440).mean()), 4)))
    (H.SEAL / 'h1_결과_SEALED.json').write_text(json.dumps(dict(**S, 비율=pub['비율']), ensure_ascii=False, indent=1), encoding='utf-8')
    (H.OUT / 'data/h1_점검.json').write_text(json.dumps(pub, ensure_ascii=False, indent=1), encoding='utf-8')
    log(f'끝 · {json.dumps(S, ensure_ascii=False)}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
