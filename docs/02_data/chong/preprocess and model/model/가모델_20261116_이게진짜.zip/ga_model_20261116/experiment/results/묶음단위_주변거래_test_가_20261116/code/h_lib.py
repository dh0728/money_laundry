"""[주변 거래 (가) 판 test · 공통] 2026-11-16 · 손은총 · Claude Code. 사전기록 = ../사전기록_주변거래_test_가_20261116.md
불러오기만 해서는 아무것도 읽지 않습니다(경로 · 함수만). GPU 를 가리지 않습니다(g_lib 를 불러오지 않음)."""
import hashlib
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent; OUT = HERE.parent; RES = OUT.parent
EXP = RES / '묶음단위_주변거래_학습_20261112'; OLD = RES / '묶음단위_모델_20261111'; SPL = RES / '끝난날나눔_실험_20261106'
LED = RES / 'R_사건학습_20261103/data/tmp_ledger'; RAW = Path('/data/shared/ibm-aml/HI-Large_Trans.csv')
SEAL = OUT / 'data/test_SEALED'; SEEDS = (42, 43, 44); PANEL = '가'; NF = 8
PRE = OUT / '사전기록_주변거래_test_가_20261116.md'; PRE_SHA = OUT / 'data/사전기록_sha256.txt'; CODE_SHA = OUT / 'data/코드_sha256_고정시.txt'
TOL = Path.home() / 'workspace/TEST_OPENED.log'
ARR = ('eoff', 'nn', 'esrc', 'edst', 'e_lap', 'e_min', 'e_hop', 'm_own', 'm_laund', 'seed_u', 'seed_v', 'cut', 'seed_min')


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def logger(path):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True); t0 = time.time()

    def log(m):
        s = f'[{time.strftime("%H:%M:%S", time.gmtime(time.time() + 9 * 3600))} KST · {time.time() - t0:7.1f}초] {m}'; print(s, flush=True)
        with open(path, 'a', encoding='utf-8') as f:
            f.write(s + '\n')
    return log


def check_fixed():
    """사전기록 · 코드가 고정 때와 같은지(test 를 열기 전마다 부름)."""
    assert PRE.exists() and PRE_SHA.exists() and CODE_SHA.exists(), '사전기록 · 코드 고정이 안 됨 → 멈춤'
    assert sha(PRE) == PRE_SHA.read_text(encoding='utf-8').split()[0], '사전기록 sha256 이 고정 때와 다름 → 멈춤'
    for ln in CODE_SHA.read_text(encoding='utf-8').splitlines():
        h, p = ln.split(maxsplit=1); assert sha(OUT / p) == h, f'고정 때와 다른 코드 → 멈춤: {p}'


def load_arrays(d):
    return {n: np.load(Path(d) / f'{n}.npy') for n in ARR}


def features(a, mu, sd, mark):
    """e3_train.py 52줄(Data.set_norm)과 같은 식 · 금액 정규화는 학습 때 값(학습.json) 그대로."""
    ne = np.diff(a['eoff']); t = a['e_min'].astype(np.int64); ts = np.repeat(a['seed_min'].astype(np.int64), ne); c = np.repeat(a['cut'].astype(np.int64), ne); hop = a['e_hop']
    F = np.empty((len(t), NF), np.float32)
    F[:, 0] = (a['e_lap'] - mu) / sd; F[:, 1] = np.log1p(np.maximum(ts - t, 0) / 1440.0); F[:, 2] = np.log1p((c - t) / 1440.0); F[:, 3] = t > ts
    F[:, 4] = hop == 1; F[:, 5] = hop == 2; F[:, 6] = hop == 0; F[:, 7] = mark
    return F


def as_data(E, a, F):
    """e3_train.Data 와 같은 칸을 가진 객체(predict · chunks · batch 가 쓰는 칸만)."""
    d = object.__new__(E.Data); d.eoff = a['eoff']; d.nn = a['nn'].astype(np.int64); d.es = a['esrc']; d.ed = a['edst']
    d.su = a['seed_u'].astype(np.int64); d.sv = a['seed_v'].astype(np.int64); d.ne = np.diff(d.eoff); d.F = F
    return d
