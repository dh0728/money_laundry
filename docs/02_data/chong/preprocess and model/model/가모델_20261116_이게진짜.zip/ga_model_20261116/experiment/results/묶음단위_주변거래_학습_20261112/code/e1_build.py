"""[주변 거래를 붙인 입력 만들기] 2026-11-12 · Claude Code(세션 fb5c8e61). 학습 · 추론 없음 · CPU. train · val 원장만(날 0 ~ 74) · test 안 엶.
지시: 은총 님 11-12 "시작값은 2홉, 100일, 200건 … 세 판을 다 돌려줘 … 무패턴은 빼줘 … 오늘 그냥 바로 돌려주면 돼". 설계 = ../묶음단위_주변거래_설계_20261112/설계안_주변거래_학습_20261112.md 3절.
단위 = (시도, 거래가 있는 날 D) · 판정 시각 = D 의 마감(11-11 정의 그대로). 씨앗 = 그 시도의 그날까지 마지막 거래 한 건.
넓히기(정답을 보지 않음): 씨앗의 두 계좌에서 출발 → 한 홉마다, 새로 닿은 계좌마다 '마감 앞 최근 K건(보낸 것 · 받은 것 합쳐서) · 최근 W일'의 거래를 넣음 → H홉.
  H = 2 · W = 100일 · K = 200. train · val 원장은 75일치라 100일은 '자료에 있는 과거 전부'와 같음.
  build_index · take · expand 는 원장의 분 · 보낸 계좌 · 받는 계좌와 씨앗 줄 번호 · 마감 시각만 받음. 세탁 표시(lab) · 시도 번호 · 유형은 넓히기가 끝난 뒤에 표시 열을 만들 때만 읽음.
출력: data/입력/*.npy(주변을 붙인 입력) · data/입력_깨끗/*.npy(견줌용: 그 시도의 거래만) · data/묶음표.parquet · data/1_입력_요약.json · tables/1_*.csv · logs/e1_build.log
"""
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent; OUT = HERE.parent; RES = OUT.parent
LED = RES / 'R_사건학습_20261103/data/tmp_ledger'; ROWS = RES / '끝난날나눔_실험_20261106/data/행_trainval.parquet'; OLD = RES / '묶음단위_모델_20261111'
H, W_DAYS, K = 2, 100, 200; SH = 17; TY = ['FAN-OUT', 'FAN-IN', 'CYCLE', 'SC-GA', 'GA-SC', 'RANDOM']; T0 = time.time()


def log(m):
    s = f'[{time.strftime("%H:%M:%S", time.gmtime(time.time() + 9 * 3600))} KST · {time.time() - T0:6.1f}초] {m}'; print(s, flush=True)
    with open(OUT / 'logs/e1_build.log', 'a', encoding='utf-8') as f:
        f.write(s + '\n')


def anon():
    for ln in open('/sys/fs/cgroup/memory.stat'):
        if ln.startswith('anon '):
            return round(int(ln.split()[1]) / 2**30, 2)


# ───────── 넓히기(정답을 받지 않는 함수들) ─────────
def build_index(sid, did, minute, acc_mask):
    """acc_mask 가 참인 계좌의 거래를 (계좌, 분) 차례로 줄 세움 → (열쇠, 원장 줄 번호)."""
    rs = np.flatnonzero(acc_mask[sid]); rd = np.flatnonzero(acc_mask[did] & (sid != did))
    key = np.r_[(sid[rs].astype(np.int64) << SH) | minute[rs], (did[rd].astype(np.int64) << SH) | minute[rd]]; row = np.r_[rs, rd].astype(np.int32)
    o = np.argsort(key, kind='stable'); return key[o], row[o]


def take(key, row, accts, c, lo_t, k):
    """계좌마다 분이 [lo_t, c) 인 거래 가운데 최근 k건의 원장 줄 번호."""
    a = accts.astype(np.int64) << SH; hi = np.searchsorted(key, a | c); lo = np.maximum(np.searchsorted(key, a | lo_t), hi - k)
    return [row[x:y] for x, y in zip(lo, hi)]


def expand(key, row, sid, did, seed_row, c, hops, w_days, k):
    """씨앗 줄에서 hops 홉까지. 돌려주는 것: 줄 번호(씨앗이 맨 앞) · 줄마다 홉(0 = 씨앗) · 마지막 홉에서 새로 닿은 계좌."""
    lo_t = max(c - w_days * 1440, 0); fr = np.unique(np.array([sid[seed_row], did[seed_row]])); seen = fr; have = np.array([seed_row], np.int32); rows = [have]; hp = [np.zeros(1, np.int8)]
    for h in range(1, hops + 1):
        if len(fr) == 0:
            break
        r = np.unique(np.concatenate(take(key, row, fr, c, lo_t, k))); r = r[~np.isin(r, have)]
        rows.append(r); hp.append(np.full(len(r), h, np.int8)); have = np.r_[have, r]
        ac = np.unique(np.r_[sid[r], did[r]]); fr = ac[~np.isin(ac, seen)]; seen = np.r_[seen, fr]
    return np.concatenate(rows), np.concatenate(hp), fr


def localize(sid, did, rows, su, sv):
    ac = np.unique(np.r_[sid[rows], did[rows]]); return len(ac), np.searchsorted(ac, sid[rows]).astype(np.int32), np.searchsorted(ac, did[rows]).astype(np.int32), int(np.searchsorted(ac, su)), int(np.searchsorted(ac, sv))


def q(a):
    a = np.asarray(a, np.float64); return dict(가운데=float(np.median(a)), 평균=round(float(a.mean()), 1), p90=float(np.percentile(a, 90)), p99=float(np.percentile(a, 99)), 최대=float(a.max()))


def main():
    meta = json.loads((LED / 'meta.json').read_text()); NA = meta['n_acct']
    minute = np.load(LED / 'minute.npy'); sid = np.load(LED / 'sid.npy'); did = np.load(LED / 'did.npy'); NL = len(minute); assert int(minute.max()) < 75 * 1440
    T = pd.read_parquet(ROWS); P = T[T['y9'] < 8].copy(); P = P.sort_values(['att', 'minute', 'lpos'], kind='stable').reset_index(drop=True); LP = P['lpos'].to_numpy().astype(np.int32); assert (minute[LP] == P['minute'].to_numpy()).all()
    U = pd.read_parquet(OLD / 'data/단위.parquet'); st_of = P.groupby('att', sort=False).apply(lambda g: int(g.index[0])); n_att = P.groupby('att', sort=False).size()
    st = U['att'].map(st_of).to_numpy(); n = U['거래수'].to_numpy(); NB = len(U); seed_row = LP[st + n - 1]; cut = (U['날'].to_numpy().astype(np.int64) + 1) * 1440
    assert (minute[seed_row] // 1440 == U['날'].to_numpy()).all() and (n <= U['att'].map(n_att).to_numpy()).all(), '씨앗이 그날의 거래가 아님 → 멈춤'
    log(f'원장 {NL:,}줄 · 묶음 {NB:,} · H {H} · W {W_DAYS}일 · K {K} · anon {anon()} GiB')
    # ── 1차: 씨앗 계좌만으로 줄 세워 1홉에서 닿는 계좌를 모음 → 2차: 그 계좌들까지 줄 세워 끝까지 ──
    m0 = np.zeros(NA, bool); m0[sid[seed_row]] = True; m0[did[seed_row]] = True; key, row = build_index(sid, did, minute, m0); log(f'1차 줄 세우기 · 씨앗 계좌 {int(m0.sum()):,} · 거래 {len(key):,} · anon {anon()} GiB')
    m1 = m0.copy()
    for b in range(NB):
        _, _, fr = expand(key, row, sid, did, int(seed_row[b]), int(cut[b]), 1, W_DAYS, K); m1[fr] = True
    del key, row; key, row = build_index(sid, did, minute, m1); log(f'2차 줄 세우기 · 계좌 {int(m1.sum()):,} · 거래 {len(key):,} · anon {anon()} GiB')
    R, HP, off, nn, es, ed, s_u, s_v = [], [], [0], [], [], [], [], []
    for b in range(NB):
        r, hp, _ = expand(key, row, sid, did, int(seed_row[b]), int(cut[b]), H, W_DAYS, K); k_, a_, d_, u_, v_ = localize(sid, did, r, sid[seed_row[b]], did[seed_row[b]])
        R.append(r); HP.append(hp); off.append(off[-1] + len(r)); nn.append(k_); es.append(a_); ed.append(d_); s_u.append(u_); s_v.append(v_)
        if b % 5000 == 0:
            log(f'넓히기 {b:,} / {NB:,} · anon {anon()} GiB')
    del key, row; R = np.concatenate(R); HP = np.concatenate(HP); off = np.array(off, np.int64); es = np.concatenate(es); ed = np.concatenate(ed); NE = len(R)
    emin = minute[R]; log(f'넓히기 끝 · 입력 거래 {NE:,} · anon {anon()} GiB')
    # ── 점검: 미래 · 나눔 ──
    bid = np.repeat(np.arange(NB), np.diff(off)); assert (emin < cut[bid]).all(), '마감 뒤 거래가 들어 있음 → 멈춤'
    is_tr = (U['구간'] == 'train').to_numpy(); assert (emin[is_tr[bid]] < 58 * 1440).all(), 'train 입력에 val 기간 거래가 있음 → 멈춤'; assert (R[off[:-1]] == seed_row).all() and (HP[off[:-1]] == 0).all()
    # ── 여기부터 정답을 읽음(표시 열 · 통계) ──
    lab = np.load(LED / 'lab.npy'); lap = np.load(LED / 'lap.npy'); m_laund = lab[R] == 1; m_own = np.zeros(NE, bool); n_in = np.zeros(NB, np.int32)
    for b in range(NB):
        a, c = off[b], off[b + 1]; m = np.isin(R[a:c], LP[st[b]:st[b] + n[b]]); m_own[a:c] = m; n_in[b] = m.sum()
    assert m_own[off[:-1]].all() and m_laund[m_own].all()
    d = OUT / 'data/입력'; d.mkdir(parents=True, exist_ok=True)
    for nm, arr in (('eoff', off), ('nn', np.array(nn, np.int32)), ('esrc', es), ('edst', ed), ('e_lap', lap[R].astype(np.float32)), ('e_min', emin.astype(np.int32)), ('e_hop', HP), ('m_own', m_own), ('m_laund', m_laund),
                    ('seed_u', np.array(s_u, np.int32)), ('seed_v', np.array(s_v, np.int32)), ('cut', cut), ('seed_min', minute[seed_row].astype(np.int32))):
        np.save(d / f'{nm}.npy', arr)
    # ── 견줌용: 그 시도의 거래만(11-11 묶음과 같은 거래) · 같은 꼴의 배열 ──
    R2, HP2, off2, nn2, es2, ed2, u2, v2 = [], [], [0], [], [], [], [], []
    for b in range(NB):
        r = LP[st[b]:st[b] + n[b]][::-1].copy(); su, sv = sid[r[0]], did[r[0]]; touch = (sid[r] == su) | (did[r] == su) | (sid[r] == sv) | (did[r] == sv); hp = np.where(touch, 1, 2).astype(np.int8); hp[0] = 0
        k_, a_, d_, u_, v_ = localize(sid, did, r, su, sv); R2.append(r); HP2.append(hp); off2.append(off2[-1] + len(r)); nn2.append(k_); es2.append(a_); ed2.append(d_); u2.append(u_); v2.append(v_)
    R2 = np.concatenate(R2); d2 = OUT / 'data/입력_깨끗'; d2.mkdir(parents=True, exist_ok=True)
    for nm, arr in (('eoff', np.array(off2, np.int64)), ('nn', np.array(nn2, np.int32)), ('esrc', np.concatenate(es2)), ('edst', np.concatenate(ed2)), ('e_lap', lap[R2].astype(np.float32)), ('e_min', minute[R2].astype(np.int32)), ('e_hop', np.concatenate(HP2)),
                    ('m_own', np.ones(len(R2), bool)), ('m_laund', np.ones(len(R2), bool)), ('seed_u', np.array(u2, np.int32)), ('seed_v', np.array(v2, np.int32)), ('cut', cut), ('seed_min', minute[seed_row].astype(np.int32))):
        np.save(d2 / f'{nm}.npy', arr)
    # ── 묶음표 · 통계 ──
    tr_acc = np.zeros(NA, bool); ptr = (P['구간'] == 'train').to_numpy(); tr_acc[sid[LP[ptr]]] = True; tr_acc[did[LP[ptr]]] = True
    Pt = P.copy(); Pt['src'] = sid[LP]; Pt['dst'] = did[LP]; cut76 = set()
    try:
        cut76 = set(json.loads((RES / '묶음단위_꼬리포함_test_20261112/data/0_valcheck.json').read_text(encoding='utf-8')).get('_', []))
    except Exception:
        pass
    V = np.load(RES / '묶음단위_꼬리포함_test_20261112/run_newval/seed42/val확률.npz'); keep_val = np.ones(NB, bool); keep_val[V['ix'][~V['keep']]] = False; assert int((~keep_val).sum()) == 96 and not is_tr[V['ix']].any()
    ne = np.diff(off); n1 = np.add.reduceat((HP == 1).astype(np.int64), off[:-1]); nl = np.add.reduceat(m_laund.astype(np.int64), off[:-1])
    U2 = U[['att', 'y9', '구간', '날', '나이', '끝', '거래수', '계좌수', 'y6', 'v6', '꼴']].copy(); U2['val_채점'] = keep_val & ~is_tr; U2['입력_거래'] = ne; U2['입력_계좌'] = np.array(nn); U2['입력_1홉_거래'] = n1; U2['입력_세탁표시_거래'] = nl; U2['입력에_든_시도거래'] = n_in
    U2['씨앗계좌가_train시도에_나옴'] = tr_acc[sid[seed_row]] | tr_acc[did[seed_row]]; U2.to_parquet(OUT / 'data/묶음표.parquet', index=False)
    rows = []
    for seg, m in (('train', is_tr), ('val(채점하는 2,127시도)', U2['val_채점'].to_numpy())):
        for nm, mm in [('전체', m), ('끝난 시도의 묶음만', m & U['끝'].to_numpy())] + [(t, m & (U['y6'] == i).to_numpy()) for i, t in enumerate(TY)]:
            rows.append({'구간': seg, '묶음': nm, '수': int(mm.sum()), '그 시도 거래가 입력에 든 몫(평균)': round(float((n_in[mm] / n[mm]).mean()), 4), '다 든 묶음 몫': round(float((n_in[mm] == n[mm]).mean()), 4), **{f'입력 거래 수 {k_}': v_ for k_, v_ in q(ne[mm]).items()},
                         '입력 계좌 수(가운데)': float(np.median(np.array(nn)[mm])), '입력 가운데 그 시도 거래 몫(평균)': round(float((n_in[mm] / ne[mm]).mean()), 4), '입력 가운데 세탁 표시 거래 몫(평균)': round(float((nl[mm] / ne[mm]).mean()), 4),
                         '세탁 표시 거래 가운데 그 시도 거래 몫(평균)': round(float((n_in[mm] / nl[mm]).mean()), 4), '씨앗 계좌가 train 시도에 나온 묶음 몫': round(float(U2['씨앗계좌가_train시도에_나옴'].to_numpy()[mm].mean()), 4)})
    t1 = pd.DataFrame(rows); t1.to_csv(OUT / 'tables/1_입력_크기와_들어온_몫.csv', index=False, encoding='utf-8-sig'); log('입력 크기와 들어온 몫\n' + t1.to_string(index=False))
    out = dict(설정=dict(홉=H, 기간_일=W_DAYS, 이웃_상한=K), 묶음=NB, 입력_거래_합=int(NE), train_입력_거래_합=int(ne[is_tr].sum()), val_입력_거래_합=int(ne[~is_tr].sum()), 깨끗한_입력_거래_합=int(len(R2)),
               점검=dict(마감_뒤_거래=0, train_입력의_val_기간_거래=0, 씨앗이_맨_앞=True), 넓히기_함수가_받는_것='원장의 분 · 보낸 계좌 · 받는 계좌 · 씨앗 줄 번호 · 마감 시각 · H · W · K(세탁 표시 · 시도 번호 · 유형은 받지 않음)')
    (OUT / 'data/1_입력_요약.json').write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8'); log(f'끝 · {json.dumps(out, ensure_ascii=False)} · anon {anon()} GiB')


if __name__ == '__main__':
    sys.exit(main())
