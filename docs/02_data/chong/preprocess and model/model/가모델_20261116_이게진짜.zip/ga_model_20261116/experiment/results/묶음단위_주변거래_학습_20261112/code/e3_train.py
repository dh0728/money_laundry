"""[주변 거래를 붙인 입력으로 학습] 2026-11-12 · Claude Code(세션 fb5c8e61). GPU(여유 4 GiB 쯤 · 한 번에 한 판) · test 안 읽음.
쓰는 법: python3 code/e3_train.py <판> <씨앗> [--dry]
판: 가 = 그 시도의 거래에 표시(천장) · 나 = 주변의 세탁 거래 전부에 표시(이진 완벽 가정) · 다 = 씨앗 한 건만 표시(누수 없는 바닥)
    깨끗 = 그 시도의 거래만(11-11 과 같은 거래 · 새 코드가 제대로 도는지 보는 견줌) · 주변만 = 다 에서 그 시도의 거래를 뺌(점검 5) · 섞음 = 다 에서 train 정답을 섞음(점검 6)
11-11 학습(g2_train.py)과 같게 둔 것: 숨은 크기 64 · 3층 · 들어오는 / 나가는 화살표 메시지 · 드롭아웃 0.1 · Adam 0.001 · 묶음 512마다 한 걸음 · 기울기 자르기 5 · 교차 엔트로피(묶음마다 한 표)
  · 100 epoch · epoch 차례 default_rng([씨앗, epoch]).permutation · 정답 = 그날 보이는 모양(v6) · val 묶음의 6칸 macro-AP 가 가장 높은 epoch 의 가중치.
바꾼 것: 입력(주변 거래) · 거래 열 8개(금액 · 씨앗 거래보다 며칠 앞인지 · 마감까지 며칠인지 · 씨앗 뒤인지 · 1홉 · 2홉 · 씨앗 · 표시) · 읽기 = [씨앗 보낸 계좌 · 씨앗 받는 계좌 · 평균 · 최댓값]
  · 고르는 val = 76시도를 뺀 2,127시도 · GPU 메모리에 맞춰 512 묶음을 작은 덩이로 나눠 기울기를 모음(걸음은 512 묶음마다 한 번 · 값은 같음) · GPU 라 실행마다 끝자리가 조금 다를 수 있음.
출력: run/<판>/seed<씨앗>/best.pt · hist.csv · 학습.json · val확률.npz · run/state_DONE_<판>_s<씨앗> · logs/e3_<판>_s<씨앗>.log
"""
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import average_precision_score

HERE = Path(__file__).resolve().parent; OUT = HERE.parent
NK = 6; HID = 64; LAYERS = 3; DROP = 0.1; EPOCHS = 100; BATCH = 512; CLIP = 5.0; LR = 0.001; NF = 8
EB_TRAIN = int(__import__('os').environ.get('EB_TRAIN', 220_000)); EB_EVAL = int(__import__('os').environ.get('EB_EVAL', 500_000))
PANELS = {'가': ('입력', 'own'), '나': ('입력', 'laund'), '다': ('입력', 'seed'), '깨끗': ('입력_깨끗', 'own'), '주변만': ('입력', 'seed'), '섞음': ('입력', 'seed')}
T0 = time.time(); torch.set_num_threads(1)


def logger(path):
    def log(t):
        s = f'[{time.strftime("%H:%M:%S", time.gmtime(time.time() + 9 * 3600))} KST · {time.time() - T0:7.1f}초] {t}'; print(s, flush=True)
        with open(path, 'a', encoding='utf-8') as f:
            f.write(s + '\n')
    return log


class Data:
    def __init__(self, folder, mark, drop_own):
        d = OUT / 'data' / folder; L = lambda n: np.load(d / f'{n}.npy')  # noqa: E731
        self.eoff = L('eoff'); self.nn = L('nn').astype(np.int64); es, ed, lap, mn, hop, own, lau = L('esrc'), L('edst'), L('e_lap'), L('e_min'), L('e_hop'), L('m_own'), L('m_laund')
        self.su = L('seed_u').astype(np.int64); self.sv = L('seed_v').astype(np.int64); self.cut = L('cut').astype(np.int64); self.smin = L('seed_min').astype(np.int64); mk = {'own': own, 'laund': lau, 'seed': hop == 0}[mark]
        if drop_own:                                           # 점검 5: 그 시도의 거래(씨앗 포함)를 입력에서 뺌 · 계좌(점)는 그대로
            keep = ~own; cnt = np.add.reduceat(keep.astype(np.int64), self.eoff[:-1]); self.eoff = np.r_[0, np.cumsum(cnt)].astype(np.int64); es, ed, lap, mn, hop, mk = es[keep], ed[keep], lap[keep], mn[keep], hop[keep], mk[keep]
        self.es = es; self.ed = ed; self.lap = lap; self.mn = mn; self.hop = hop; self.mk = mk; self.ne = np.diff(self.eoff); self.F = None

    def set_norm(self, tr):
        m = np.zeros(len(self.ne), bool); m[tr] = True; em = np.repeat(m, self.ne); x = self.lap[em].astype(np.float64); self.mu, self.sd = float(x.mean()), float(x.std()); del em, x
        # 거래 열 8개를 한 번만 만들어 둠(값은 묶음마다 만들 때와 같음)
        t = self.mn.astype(np.int64); ts = np.repeat(self.smin, self.ne); c = np.repeat(self.cut, self.ne); F_ = np.empty((len(t), NF), np.float32)
        F_[:, 0] = (self.lap - self.mu) / self.sd; F_[:, 1] = np.log1p(np.maximum(ts - t, 0) / 1440.0); F_[:, 2] = np.log1p((c - t) / 1440.0); F_[:, 3] = t > ts; F_[:, 4] = self.hop == 1; F_[:, 5] = self.hop == 2; F_[:, 6] = self.hop == 0; F_[:, 7] = self.mk
        self.F = F_; del self.lap, self.mn, self.hop, self.mk; return self.mu, self.sd

    def batch(self, b, dev):
        b = np.asarray(b, np.int64); ne = self.ne[b]; nb = self.nn[b]; noff = np.concatenate([[0], np.cumsum(nb)[:-1]]); start = np.concatenate([[0], np.cumsum(ne)[:-1]])
        idx = np.repeat(self.eoff[b] - start, ne) + np.arange(int(ne.sum())); sh = np.repeat(noff, ne); ef = self.F[idx]
        tt = lambda a: torch.from_numpy(a).to(dev, non_blocking=True)  # noqa: E731
        return int(nb.sum()), tt(self.es[idx] + sh), tt(self.ed[idx] + sh), tt(ef), tt(np.repeat(np.arange(len(b)), nb)), len(b), tt(self.su[b] + noff), tt(self.sv[b] + noff)

    def chunks(self, b, budget):
        out, cur, s = [], [], 0
        for i in b:
            e = int(self.ne[i])
            if cur and s + e > budget:
                out.append(cur); cur, s = [], 0
            cur.append(i); s += e
        if cur:
            out.append(cur)
        return out


class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.h0 = nn.Parameter(torch.zeros(HID)); nn.init.normal_(self.h0, std=0.1)
        self.enc = nn.Sequential(nn.Linear(NF, HID), nn.ReLU(), nn.Linear(HID, HID))
        self.f_in = nn.ModuleList([nn.Sequential(nn.Linear(2 * HID, HID), nn.ReLU()) for _ in range(LAYERS)])
        self.f_out = nn.ModuleList([nn.Sequential(nn.Linear(2 * HID, HID), nn.ReLU()) for _ in range(LAYERS)])
        self.upd = nn.ModuleList([nn.Sequential(nn.Linear(3 * HID, HID), nn.ReLU(), nn.Linear(HID, HID)) for _ in range(LAYERS)])
        self.norm = nn.ModuleList([nn.LayerNorm(HID) for _ in range(LAYERS)]); self.drop = nn.Dropout(DROP)
        self.head = nn.Sequential(nn.Linear(4 * HID, HID), nn.ReLU(), nn.Dropout(DROP), nn.Linear(HID, NK))

    def forward(self, n_node, src, dst, ef, gid, n_graph, su, sv):
        h = self.h0.unsqueeze(0).expand(n_node, HID); e = self.enc(ef)
        for l in range(LAYERS):
            m_in = torch.zeros(n_node, HID, dtype=h.dtype, device=h.device).index_add_(0, dst, self.f_in[l](torch.cat([h[src], e], 1)))
            m_out = torch.zeros(n_node, HID, dtype=h.dtype, device=h.device).index_add_(0, src, self.f_out[l](torch.cat([h[dst], e], 1)))
            h = self.norm[l](h + self.drop(self.upd[l](torch.cat([h, m_in, m_out], 1))))
        cnt = torch.zeros(n_graph, dtype=h.dtype, device=h.device).index_add_(0, gid, torch.ones(n_node, dtype=h.dtype, device=h.device)).clamp_(min=1).unsqueeze(1)
        g_mean = torch.zeros(n_graph, HID, dtype=h.dtype, device=h.device).index_add_(0, gid, h) / cnt
        g_max = torch.full((n_graph, HID), -1e9, dtype=h.dtype, device=h.device).scatter_reduce(0, gid.unsqueeze(1).expand(-1, HID), h, 'amax', include_self=True)
        return self.head(torch.cat([h[su], h[sv], g_mean, g_max], 1))


def predict(model, D, ix, dev):
    model.eval(); out = np.zeros((len(ix), NK), np.float32); order = np.argsort(D.ne[ix], kind='stable'); pos = 0
    with torch.no_grad():
        for ch in D.chunks(ix[order], EB_EVAL):
            p = torch.softmax(model(*D.batch(ch, dev)), 1).float().cpu().numpy(); out[order[pos:pos + len(ch)]] = p; pos += len(ch)
    return out


def mAP(P, yy):
    return float(np.mean([average_precision_score(yy == c, P[:, c]) for c in range(NK) if (yy == c).any()]))


def main():
    panel, seed = sys.argv[1], int(sys.argv[2]); dry = '--dry' in sys.argv; folder, mark = PANELS[panel]; tag = f'{panel}_s{seed}' + ('_dry' if dry else ''); log = logger(OUT / f'logs/e3_{tag}.log')
    if not dry:
        doc = OUT / '사전기록_주변거래_학습_20261112.md'; pre = OUT / 'data/사전기록_sha256.txt'; assert pre.exists() and doc.exists(), '사전기록이 고정되지 않음 → 시작 안 함'
        assert hashlib.sha256(doc.read_bytes()).hexdigest() == pre.read_text(encoding='utf-8').split()[0], '사전기록 sha256 다름 → 시작 안 함'
        assert not (OUT / f'run/state_DONE_{panel}_s{seed}').exists(), '이미 끝난 판 · 씨앗'
    dev = torch.device('cuda'); U = pd.read_parquet(OUT / 'data/묶음표.parquet'); y = U['v6'].to_numpy().astype(np.int64).copy(); is_tr = (U['구간'] == 'train').to_numpy(); tr = np.flatnonzero(is_tr); va = np.flatnonzero(~is_tr); keep = U['val_채점'].to_numpy()[va]
    if panel == '섞음':
        y[tr] = y[tr][np.random.default_rng(20261112).permutation(len(tr))]
    D = Data(folder, mark, drop_own=(panel == '주변만')); mu, sd = D.set_norm(tr); torch.manual_seed(seed); np.random.seed(seed); model = Net().to(dev); params = [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.Adam(params, lr=LR); yt = torch.from_numpy(y).to(dev); epochs = 1 if dry else EPOCHS; torch.cuda.reset_peak_memory_stats()
    log(f'시작 · 판 {panel} · 씨앗 {seed} · {"DRY 1 epoch" if dry else "본 학습"} · 학습 묶음 {len(tr):,}(거래 {int(D.ne[tr].sum()):,}) · 고르기 묶음 {int(keep.sum()):,} · 금액 평균 {mu:.4f} · 표준편차 {sd:.4f} · 매개변수 {sum(p.numel() for p in params):,} · test 안 읽음')
    best, best_ep, best_state, hist, t0 = -1.0, 0, None, [], time.time()
    for ep in range(epochs):
        model.train(); order = np.random.default_rng([seed, ep]).permutation(len(tr)); ls, ok, te = 0.0, 0, time.time()
        for s in range(0, len(order), BATCH):
            b = tr[order[s:s + BATCH]]; opt.zero_grad(set_to_none=True)
            for ch in D.chunks(b, EB_TRAIN):
                lg = model(*D.batch(ch, dev)); t_ = yt[torch.as_tensor(ch, device=dev)]; loss = F.cross_entropy(lg, t_, reduction='sum') / len(b); assert torch.isfinite(loss); loss.backward()
                ls += float(loss.detach()) * len(b); ok += int((lg.argmax(1) == t_).sum())
            torch.nn.utils.clip_grad_norm_(params, CLIP, error_if_nonfinite=True); opt.step()
        t_tr = time.time() - te; Pv = predict(model, D, va, dev); sc = mAP(Pv[keep], y[va][keep]); acc = float((Pv[keep].argmax(1) == y[va][keep]).mean())
        hist.append(dict(epoch=ep + 1, train_loss=ls / len(order), train_맞은몫_학습중=ok / len(order), 고르기_점수=sc, val_맞은몫=acc, 초=round(time.time() - te, 1)))
        if sc > best:
            best, best_ep = sc, ep + 1; best_state = {kk: v.detach().clone() for kk, v in model.state_dict().items()}; best_P = Pv
        if ep < 3 or (ep + 1) % 10 == 0:
            log(f'ep{ep + 1}/{epochs} · 학습 손실 {ls / len(order):.4f} · 학습 중 맞은 몫 {ok / len(order):.4f} · val macro-AP {sc:.4f} · val 맞은 몫 {acc:.4f}(최고 ep{best_ep} {best:.4f}) · 학습 {t_tr:.0f}초 + 채점 {time.time() - te - t_tr:.0f}초 · GPU 최대 {torch.cuda.max_memory_allocated() / 2**30:.2f}(잡아 둔 것 {torch.cuda.max_memory_reserved() / 2**30:.2f}) GiB')
    out = OUT / ('run_dry' if dry else 'run') / panel / f'seed{seed}'; out.mkdir(parents=True, exist_ok=True); torch.save(best_state, out / 'best.pt'); np.savez_compressed(out / 'val확률.npz', ix=va, P=best_P, keep=keep)
    pd.DataFrame(hist).to_csv(out / 'hist.csv', index=False, encoding='utf-8-sig')
    (out / '학습.json').write_text(json.dumps(dict(판=panel, 씨앗=seed, dry=dry, 고른_epoch=best_ep, 고르기_점수=best, 금액_평균=mu, 금액_표준편차=sd, 학습묶음=int(len(tr)), 학습_입력_거래=int(D.ne[tr].sum()), 고르기묶음=int(keep.sum()),
                                               설정=dict(epochs=epochs, batch=BATCH, clip=CLIP, lr=LR, hid=HID, layers=LAYERS, drop=DROP, 거래열=NF, 덩이_거래_상한=EB_TRAIN), 학습초=round(time.time() - t0, 1), GPU_최대_GiB=round(torch.cuda.max_memory_allocated() / 2**30, 2)), ensure_ascii=False, indent=1), encoding='utf-8')
    if not dry:
        (OUT / f'run/state_DONE_{panel}_s{seed}').write_text('done\n')
    log(f'끝 · 고른 epoch {best_ep}(고르기 {best:.4f}) · {time.time() - t0:.0f}초')


if __name__ == '__main__':
    sys.exit(main())
