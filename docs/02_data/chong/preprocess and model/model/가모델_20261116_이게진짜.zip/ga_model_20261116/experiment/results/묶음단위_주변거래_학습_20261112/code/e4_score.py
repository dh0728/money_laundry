"""[주변 거래를 붙인 입력 · 채점] 2026-11-12 · Claude Code(세션 fb5c8e61). CPU · 학습 없음 · test 안 엶. 사전기록 4절.
쓰는 법: python3 code/e4_score.py            → 판이 다 끝난 뒤(씨앗 3개) · tables/4_*.csv · data/4_결과.json
        python3 code/e4_score.py --preview  → 지금까지 끝난 판 · 씨앗만 간단히(화면에만 · 구간 없음)
채점 식 = 11-11 t1_test.py 의 score(6유형 macro 정밀도 / 재현율 · 씨앗 3개 평균 · 시도 단위 부트스트랩 2,000번 · 난수 20261008). val = 76시도를 뺀 2,127시도.
"""
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent; OUT = HERE.parent; RES = OUT.parent; OLD = RES / '묶음단위_모델_20261111'
sys.path.insert(0, str(OLD / 'code'))
import g_lib as C  # noqa: E402
import t1_test as T1  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from sklearn.metrics import average_precision_score  # noqa: E402

assert Path(C.__file__).resolve() == OLD / 'code/g_lib.py' and Path(T1.__file__).resolve() == OLD / 'code/t1_test.py'
S1, S2 = '(1) 모든 묶음 · 보이는 대로', '(2) 끝난 시도 · 원래 유형'; P3 = ('가', '나', '다', '깨끗'); P1 = ('주변만', '섞음')
NAME = {'가': '(가) 그 시도 거래에 표시', '나': '(나) 세탁 거래에 표시', '다': '(다) 씨앗만 표시', '깨끗': '깨끗(그 시도 거래만 · 새 코드)', '주변만': '주변만(그 시도 거래를 뺌)', '섞음': '섞음(train 정답을 섞음)'}


def load():
    U = pd.read_parquet(OUT / 'data/묶음표.parquet'); va = np.flatnonzero((U['구간'] != 'train').to_numpy()); keep = U['val_채점'].to_numpy()[va]; Uv = U.iloc[va][keep].reset_index(drop=True)
    rule, fb = T1.rule_table(); p_rule = Uv['꼴'].map(rule).fillna(fb).to_numpy(np.int64); return U, va, keep, Uv, p_rule


def probs(pn, s, va, keep):
    f = OUT / f'run/{pn}/seed{s}/val확률.npz'
    if not (OUT / f'run/state_DONE_{pn}_s{s}').exists():
        return None
    Z = np.load(f); assert (Z['ix'] == va).all(); return Z['P'][keep]


def simple(Uv, P):
    end = Uv['끝'].to_numpy(); yv = Uv['v6'].to_numpy(); yo = Uv['y6'].to_numpy(); p = P.argmax(1).astype(np.int64); a = C.macro(yv, p); b = C.macro(yo[end], p[end])
    ap = float(np.mean([average_precision_score(yv == c, P[:, c]) for c in range(C.K) if (yv == c).any()]))
    return {S1: dict(정밀도=round(float(a[0]), 4), 재현율=round(float(a[1]), 4), 맞은몫=round(float((p == yv).mean()), 4), macroAP=round(ap, 4)), S2: dict(정밀도=round(float(b[0]), 4), 재현율=round(float(b[1]), 4), 맞은몫=round(float((p[end] == yo[end]).mean()), 4))}


def panel_diff(U, PMa, PMb):
    yv = U['v6'].to_numpy(); yo = U['y6'].to_numpy(); end = U['끝'].to_numpy(); ua, ai = np.unique(U['att'].to_numpy(), return_inverse=True); cnt = C.boot_counts(len(ua)); out = {}
    q = lambda a: [round(float(v), 4) for v in np.percentile(a, [2.5, 97.5])]  # noqa: E731
    for nm, (m, y) in {S1: (np.ones(len(U), bool), yv), S2: (end, yo)}.items():
        ix = np.flatnonzero(m); yy = y[ix]; W = cnt[:, ai[ix]].astype(np.float64); a = {s: PMa[s][ix].argmax(1).astype(np.int64) for s in C.SEEDS}; b = {s: PMb[s][ix].argmax(1).astype(np.int64) for s in C.SEEDS}
        pt = np.mean([C.macro(yy, a[s]) - C.macro(yy, b[s]) for s in C.SEEDS], 0); bd = np.stack([np.mean([C.macro(yy, a[s], w) - C.macro(yy, b[s], w) for s in C.SEEDS], 0) for w in W])
        out[nm] = dict(정밀도=round(float(pt[0]), 4), 정밀도_95=q(bd[:, 0]), 재현율=round(float(pt[1]), 4), 재현율_95=q(bd[:, 1]), 같은답몫=round(float(np.mean([(a[s] == b[s]).mean() for s in C.SEEDS])), 4))
    return out


def curves():
    rows = []
    for pn in P3 + P1:
        for s in C.SEEDS:
            f = OUT / f'run/{pn}/seed{s}/hist.csv'
            if not (OUT / f'run/state_DONE_{pn}_s{s}').exists():
                continue
            h = pd.read_csv(f, encoding='utf-8-sig'); i = int(h['고르기_점수'].idxmax()); j = json.loads((OUT / f'run/{pn}/seed{s}/학습.json').read_text(encoding='utf-8'))
            rows.append({'판': NAME[pn], '씨앗': s, '고른 epoch': int(h.loc[i, 'epoch']), '고른 epoch: 학습 손실': round(float(h.loc[i, 'train_loss']), 4), '고른 epoch: 학습 중 맞은 몫': round(float(h.loc[i, 'train_맞은몫_학습중']), 4), '고른 epoch: val 맞은 몫': round(float(h.loc[i, 'val_맞은몫']), 4),
                         '고른 epoch: val macro-AP': round(float(h.loc[i, '고르기_점수']), 4), '마지막 epoch: 학습 중 맞은 몫': round(float(h['train_맞은몫_학습중'].iloc[-1]), 4), '마지막 epoch: val 맞은 몫': round(float(h['val_맞은몫'].iloc[-1]), 4),
                         '마지막 epoch: val macro-AP': round(float(h['고르기_점수'].iloc[-1]), 4), '학습 분': round(j['학습초'] / 60, 1)})
    return pd.DataFrame(rows)


def preview():
    U, va, keep, Uv, p_rule = load(); print(f'[preview] val 묶음 {len(Uv):,} · 시도 {Uv["att"].nunique():,}')
    for pn in P3 + P1:
        for s in C.SEEDS:
            P = probs(pn, s, va, keep)
            if P is not None:
                r = simple(Uv, P); print(f'{NAME[pn]} · 씨앗 {s}: (1) {r[S1]["정밀도"]} / {r[S1]["재현율"]} · 맞은 몫 {r[S1]["맞은몫"]} · macro-AP {r[S1]["macroAP"]} | (2) {r[S2]["정밀도"]} / {r[S2]["재현율"]} · 맞은 몫 {r[S2]["맞은몫"]}')
    c = curves(); print(c.to_string(index=False) if len(c) else '끝난 판 없음')


def main():
    if '--preview' in sys.argv:
        return preview()
    log = C.logger(OUT / 'logs/e4_score.log'); U, va, keep, Uv, p_rule = load(); PM = {pn: {s: probs(pn, s, va, keep) for s in C.SEEDS} for pn in P3}; assert all(v is not None for pn in P3 for v in PM[pn].values()), '씨앗 3개가 다 끝나지 않은 판이 있음'
    out = dict(val=dict(시도=int(Uv['att'].nunique()), 묶음=len(Uv))); mrows, trows, srows, drows = [], [], [], []
    seen = Uv['씨앗계좌가_train시도에_나옴'].to_numpy(); allin = (Uv['입력에_든_시도거래'] == Uv['거래수']).to_numpy()
    SPL = [('전체', np.ones(len(Uv), bool)), ('씨앗 계좌가 train 시도에 나온 묶음', seen), ('씨앗 계좌가 train 시도에 안 나온 묶음', ~seen), ('그 시도 거래가 입력에 다 든 묶음', allin), ('그 시도 거래가 입력에 다 들지 않은 묶음', ~allin)]
    for pn in P3:
        out[NAME[pn]] = {}
        for snm, m in SPL:
            ix = np.flatnonzero(m); R = T1.score(Uv.iloc[ix].reset_index(drop=True), {s: PM[pn][s][ix] for s in C.SEEDS}, p_rule[ix]); out[NAME[pn]][snm] = {k: {kk: v[kk] for kk in ('묶음', '시도', '모델', '규칙', '차이', '유형별')} for k, v in R.items()}
            for k, v in R.items():
                row = {'판': NAME[pn], '나눔': snm, '성적표': k, '묶음': v['묶음'], '시도': v['시도'], '정밀도': v['모델']['정밀도'], '정밀도 씨앗 SD': v['모델']['정밀도_SD'], '정밀도 95%': str(v['모델']['정밀도_95']), '재현율': v['모델']['재현율'], '재현율 씨앗 SD': v['모델']['재현율_SD'],
                       '재현율 95%': str(v['모델']['재현율_95']), '맞은 몫': v['모델']['맞은몫'], 'macro-AP': v['모델']['macroAP'], '모양 규칙(깨끗한 묶음) 정밀도': v['규칙']['정밀도'], '모양 규칙 재현율': v['규칙']['재현율']}
                (mrows if snm == '전체' else srows).append(row)
                if snm == '전체':
                    for t in v['유형별']:
                        trows.append({'판': NAME[pn], '성적표': k, '유형': t['유형'], '정답 수': t['정답수'], '정밀도': t['모델_정밀도'], '재현율': t['모델_재현율']})
            if snm == '전체':
                log(f'{NAME[pn]}: (1) {R[S1]["모델"]["정밀도"]} / {R[S1]["모델"]["재현율"]} · 맞은 몫 {R[S1]["모델"]["맞은몫"]} | (2) {R[S2]["모델"]["정밀도"]} / {R[S2]["모델"]["재현율"]} · 맞은 몫 {R[S2]["모델"]["맞은몫"]}')
    out['한_씨앗_판'] = {}
    for pn in P1:
        P = probs(pn, 42, va, keep)
        if P is not None:
            out['한_씨앗_판'][NAME[pn]] = simple(Uv, P); log(f'{NAME[pn]}(씨앗 42): {out["한_씨앗_판"][NAME[pn]]}')
    out['차이'] = {}
    for a, b in (('가', '다'), ('나', '다'), ('가', '나'), ('깨끗', '가')):
        dnm = f'{NAME[a]} − {NAME[b]}'; out['차이'][dnm] = panel_diff(Uv, PM[a], PM[b])
        for k, v in out['차이'][dnm].items():
            drows.append({'차이': dnm, '성적표': k, '정밀도 차': v['정밀도'], '정밀도 95%': str(v['정밀도_95']), '재현율 차': v['재현율'], '재현율 95%': str(v['재현율_95']), '두 판이 같은 답을 낸 몫': v['같은답몫']})
        log(f'{dnm}: {json.dumps(out["차이"][dnm], ensure_ascii=False)}')
    yv = Uv['v6'].to_numpy(); out['찍기_수준'] = dict(val_가장_많은_칸_몫=round(float(np.bincount(yv, minlength=C.K).max() / len(yv)), 4), 칸별_몫={t: round(float((yv == i).mean()), 4) for i, t in enumerate(C.TY)})
    out['나눔_몫'] = {snm: round(float(m.mean()), 4) for snm, m in SPL}
    c = curves(); c.to_csv(OUT / 'tables/4_학습곡선_요약.csv', index=False, encoding='utf-8-sig'); out['학습곡선_요약'] = c.to_dict('records')
    pd.DataFrame(mrows).to_csv(OUT / 'tables/4_주표.csv', index=False, encoding='utf-8-sig'); pd.DataFrame(trows).to_csv(OUT / 'tables/4_유형별.csv', index=False, encoding='utf-8-sig')
    pd.DataFrame(srows).to_csv(OUT / 'tables/4_나눠보기.csv', index=False, encoding='utf-8-sig'); pd.DataFrame(drows).to_csv(OUT / 'tables/4_판_차이.csv', index=False, encoding='utf-8-sig')
    (OUT / 'data/4_결과.json').write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding='utf-8'); log('끝')


if __name__ == '__main__':
    sys.exit(main())
