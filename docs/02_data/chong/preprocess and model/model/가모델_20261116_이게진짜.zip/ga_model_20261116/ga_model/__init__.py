from .inference import GaClassifier

__all__ = ["GaClassifier"]
