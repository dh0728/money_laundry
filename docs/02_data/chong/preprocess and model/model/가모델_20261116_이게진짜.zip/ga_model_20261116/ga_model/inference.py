"""Predict one case from its prepared transaction graph."""

import json
import math
from pathlib import Path

import numpy as np
import torch

from .model import Net, features


ROOT = Path(__file__).resolve().parent
LABELS = ("FAN-OUT", "FAN-IN", "CYCLE", "SC-GA", "GA-SC", "RANDOM")
SEEDS = (42, 43, 44)


def prepare_graph(graph, mean, std):
    """Convert the documented single-graph JSON to the original model inputs."""
    cutoff = graph["cutoff_minute"]
    rows = graph["transactions"]
    if type(cutoff) is not int or not isinstance(rows, list) or not rows:
        raise ValueError("An integer cutoff_minute and a nonempty transaction list are required.")

    account_ids = {}
    senders, receivers, minutes, amounts, hops, members = [], [], [], [], [], []
    for row in rows:
        sender, receiver = row["from_account"], row["to_account"]
        if not all(isinstance(value, str) and value for value in (sender, receiver)):
            raise ValueError("Account identifiers must be nonempty strings.")
        minute, amount = row["minute"], row["amount_paid"]
        if type(minute) is not int or not cutoff - 100 * 1440 <= minute < cutoff:
            raise ValueError("Each transaction must fall in the 100 days before cutoff_minute.")
        if type(amount) not in (int, float) or not math.isfinite(amount) or amount < 0:
            raise ValueError("amount_paid must be a finite, nonnegative number.")
        hop, member = row["hop"], row["in_alert"]
        if type(hop) is not int or hop not in (0, 1, 2) or type(member) is not bool:
            raise ValueError("hop must be 0, 1, or 2 and in_alert must be true or false.")
        senders.append(account_ids.setdefault(sender, len(account_ids)))
        receivers.append(account_ids.setdefault(receiver, len(account_ids)))
        minutes.append(minute)
        amounts.append(amount)
        hops.append(hop)
        members.append(member)

    if hops.count(0) != 1 or not members[hops.index(0)]:
        raise ValueError("Exactly one reference transaction with hop=0 and in_alert=true is required.")
    anchor = hops.index(0)
    n_rows = len(rows)
    arrays = {
        "eoff": np.array([0, n_rows]),
        "e_min": np.array(minutes, dtype=np.int64),
        "e_lap": np.log1p(np.array(amounts, dtype=np.float64)).astype(np.float32),
        "e_hop": np.array(hops),
        "cut": np.array([cutoff]),
        "seed_min": np.array([minutes[anchor]]),
    }
    attributes = features(arrays, mean, std, np.array(members, dtype=bool))
    src = torch.tensor(senders, dtype=torch.long)
    dst = torch.tensor(receivers, dtype=torch.long)
    n_accounts = len(account_ids)
    graph_ids = torch.zeros(n_accounts, dtype=torch.long)
    return (n_accounts, src, dst, torch.from_numpy(attributes), graph_ids, 1,
            src[anchor:anchor + 1], dst[anchor:anchor + 1])


class GaClassifier:
    """Load one checkpoint once, then call predict on prepared graphs."""

    def __init__(self, seed=42):
        if seed not in SEEDS:
            raise ValueError(f"Choose a checkpoint from {SEEDS}.")
        folder = ROOT / "weights" / f"seed{seed}"
        metadata = json.loads((folder / "학습.json").read_text(encoding="utf-8"))
        self.mean = metadata["금액_평균"]
        self.std = metadata["금액_표준편차"]
        self.seed = seed
        self.model = Net()
        self.model.load_state_dict(torch.load(folder / "best.pt", map_location="cpu", weights_only=True))
        self.model.eval()

    @torch.inference_mode()
    def predict(self, graph):
        inputs = prepare_graph(graph, self.mean, self.std)
        probabilities = self.model(*inputs).softmax(dim=1)[0]
        return {
            "model": f"ga-20261116-seed{self.seed}",
            "label": LABELS[probabilities.argmax().item()],
            "probabilities": dict(zip(LABELS, probabilities.tolist())),
        }
