"""Network and edge feature equations from the 2026-11-16 (가) experiment."""

import numpy as np
import torch
from torch import nn

NF = 8
NK = 6
HID = 64
LAYERS = 3
DROP = 0.1

def features(a, mu, sd, mark):
    """e3_train.py 52줄(Data.set_norm)과 같은 식 · 금액 정규화는 학습 때 값(학습.json) 그대로."""
    ne = np.diff(a['eoff'])
    t = a['e_min'].astype(np.int64)
    ts = np.repeat(a['seed_min'].astype(np.int64), ne)
    c = np.repeat(a['cut'].astype(np.int64), ne)
    hop = a['e_hop']
    F = np.empty((len(t), NF), np.float32)
    F[:, 0] = (a['e_lap'] - mu) / sd
    F[:, 1] = np.log1p(np.maximum(ts - t, 0) / 1440.0)
    F[:, 2] = np.log1p((c - t) / 1440.0)
    F[:, 3] = t > ts
    F[:, 4] = hop == 1
    F[:, 5] = hop == 2
    F[:, 6] = hop == 0
    F[:, 7] = mark
    return F

class Net(nn.Module):

    def __init__(self):
        super().__init__()
        self.h0 = nn.Parameter(torch.zeros(HID))
        nn.init.normal_(self.h0, std=0.1)
        self.enc = nn.Sequential(nn.Linear(NF, HID), nn.ReLU(), nn.Linear(HID, HID))
        self.f_in = nn.ModuleList([nn.Sequential(nn.Linear(2 * HID, HID), nn.ReLU()) for _ in range(LAYERS)])
        self.f_out = nn.ModuleList([nn.Sequential(nn.Linear(2 * HID, HID), nn.ReLU()) for _ in range(LAYERS)])
        self.upd = nn.ModuleList([nn.Sequential(nn.Linear(3 * HID, HID), nn.ReLU(), nn.Linear(HID, HID)) for _ in range(LAYERS)])
        self.norm = nn.ModuleList([nn.LayerNorm(HID) for _ in range(LAYERS)])
        self.drop = nn.Dropout(DROP)
        self.head = nn.Sequential(nn.Linear(4 * HID, HID), nn.ReLU(), nn.Dropout(DROP), nn.Linear(HID, NK))

    def forward(self, n_node, src, dst, ef, gid, n_graph, su, sv):
        h = self.h0.unsqueeze(0).expand(n_node, HID)
        e = self.enc(ef)
        for l in range(LAYERS):
            m_in = torch.zeros(n_node, HID, dtype=h.dtype, device=h.device).index_add_(0, dst, self.f_in[l](torch.cat([h[src], e], 1)))
            m_out = torch.zeros(n_node, HID, dtype=h.dtype, device=h.device).index_add_(0, src, self.f_out[l](torch.cat([h[dst], e], 1)))
            h = self.norm[l](h + self.drop(self.upd[l](torch.cat([h, m_in, m_out], 1))))
        cnt = torch.zeros(n_graph, dtype=h.dtype, device=h.device).index_add_(0, gid, torch.ones(n_node, dtype=h.dtype, device=h.device)).clamp_(min=1).unsqueeze(1)
        g_mean = torch.zeros(n_graph, HID, dtype=h.dtype, device=h.device).index_add_(0, gid, h) / cnt
        g_max = torch.full((n_graph, HID), -1000000000.0, dtype=h.dtype, device=h.device).scatter_reduce(0, gid.unsqueeze(1).expand(-1, HID), h, 'amax', include_self=True)
        return self.head(torch.cat([h[su], h[sv], g_mean, g_max], 1))
