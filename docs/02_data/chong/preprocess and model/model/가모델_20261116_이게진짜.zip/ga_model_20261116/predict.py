"""Predict one case from its prepared transaction graph."""
import argparse
import json
from pathlib import Path

import torch

from ga_model import GaClassifier
from ga_model.inference import SEEDS

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, nargs="?", default=ROOT / "example.json")
    parser.add_argument("--seed", type=int, choices=SEEDS, default=42)
    args = parser.parse_args()
    torch.set_num_threads(min(4, torch.get_num_threads()))
    graph = json.loads(args.input.read_text(encoding="utf-8"))
    print(json.dumps(GaClassifier(args.seed).predict(graph), indent=2))


if __name__ == "__main__":
    main()
