"""Run the archived research input builder and service Alert grouper on a tiny fictional ledger."""
from pathlib import Path
import sys

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "experiment/results"
sys.path.insert(0, str(RESULTS / "묶음단위_가_세종류뺌_꼬리포함_20261116/code"))
sys.path.insert(0, str(ROOT / "service_snapshot/backend/api-server/worker"))

import f_lib
from alerts.block_graph import BlockPolicy, build_block_graphs
from alerts.flow_graph import EdgeTable, FlowIndex
from alerts.seed_promotion import promote
from models.multi_fraudgt_hgb import spec

# Columns are transaction ID, minute, sender, receiver, USD, illustrative binary score,
# and synthetic attempt ID. Zero marks an ordinary transfer. All transactions here use USD.
ROWS = [
    (101, 540, 1, 2, 1000, .95,  1),
    (102, 550, 2, 3,  980, .001, 0),
    (103, 560, 3, 4,  960, .91,  1),
    (104, 565, 5, 6, 1000, .93,  0),
    (105, 570, 2, 7,   10, .001, 0),
    (106, 575, 4, 8,    7, .001, 2),
    (107, 1445, 8, 9,   5, .001, 0),
]
CUTOFF = 1440


def experiment(ledger):
    original = f_lib.h1mod()
    ledger = ledger.assign(lpos=np.arange(len(ledger)),
                           lap=np.log1p(ledger.usd).astype(np.float32),
                           날=ledger.minute // 1440)
    # Attempt 1 is labeled RANDOM in this toy dataset.
    case = ledger.loc[ledger.att.eq(1)].assign(y9=7)
    units, _ = original.T1.build(case)
    arrays, _ = original.build_inputs(
        units, case, ledger.minute.to_numpy(), ledger.src.to_numpy(), ledger.dst.to_numpy(),
        ledger.lap.to_numpy(), ledger.att.ne(0).to_numpy(),
        int(max(ledger.src.max(), ledger.dst.max())) + 1, log=lambda message: None)
    # Only for showing IDs: the fixture has a unique minute for each transaction.
    assert ledger.minute.is_unique
    ids = ledger.set_index("minute").loc[arrays["e_min"], "tx"].tolist()
    print("실험 원본이 선택한 거래")
    print("거래   홉   원장 세탁 표시   이 사건 소속(피처 8)")
    result = {}
    for tx, hop, laundered, own in zip(ids, arrays["e_hop"], arrays["m_laund"], arrays["m_own"]):
        result[tx] = (int(hop), int(laundered), int(own))
        print(f"{tx}    {hop}          {int(laundered)}                  {int(own)}")
    return result


def service(ledger):
    edges = EdgeTable()
    scores = {}
    for row in ledger.loc[ledger.minute.lt(CUTOFF)].sort_values("tx").itertuples():
        edges.append(row.tx, row.minute * 60_000_000, row.src, row.dst, row.usd * 1_000_000)
        scores[row.tx] = row.score
    seeds = {tx for tx, score in scores.items() if score >= spec.RECOMMENDED_THRESHOLD}
    added = promote(edges, scores, seeds, spec.ALERT_SEED_LOW, spec.ALERT_CHAIN_FLOOR)
    seeds.update(edges.tx_ids[pos] for pos in added)
    return build_block_graphs(FlowIndex(edges), seeds, BlockPolicy())


def main():
    ledger = pd.DataFrame(ROWS, columns=["tx", "minute", "src", "dst", "usd", "score", "att"])
    observed = experiment(ledger)
    assert observed == {103: (0, 1, 1), 102: (1, 0, 0), 106: (1, 1, 0),
                        101: (2, 1, 1), 105: (2, 0, 0)}
    result = service(ledger)
    graph, = result.graphs
    print(f"서비스 Alert 씨앗 {list(graph.seed_ids)}, 연결 거래 {list(graph.connection_ids)}")
    assert graph.seed_ids == (101, 103) and graph.connection_ids == (102,)
    assert any(w.kind == "PATH" and w.tx_ids == (101, 102, 103) for w in graph.witnesses)
    assert result.ungrouped_seed_ids == (104,)
    without_bridge = service(ledger.loc[ledger.tx.ne(102)])
    print(f"102번을 원장에서 빼고 다시 만든 Alert 수 · {len(without_bridge.graphs)}")
    assert not without_bridge.graphs
    print("확인 완료")


if __name__ == "__main__":
    main()
